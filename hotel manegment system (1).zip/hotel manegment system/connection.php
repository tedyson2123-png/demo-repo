<?php
// ── Load DB credentials from config/database.php ────────────
require_once __DIR__ . '/config/database.php';

// Connect without a database first so we can create it if missing
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);

if ($conn->connect_error) {
    die('<b>Database connection failed:</b> ' . htmlspecialchars($conn->connect_error) .
        '<br>Make sure XAMPP MySQL is running.');
}

$conn->set_charset('utf8mb4');

// ── Auto-setup: create DB + tables if they don't exist ───────
$conn->query("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db(DB_NAME);

// Check if the users table exists; if not, run full setup
$check = $conn->query("SHOW TABLES LIKE 'users'");
if ($check && $check->num_rows === 0) {
    // Tables are missing — redirect to setup page
    $setupUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
        . '://' . $_SERVER['HTTP_HOST']
        . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\') . '/setup.php';
    // If we're already on setup.php, don't redirect (avoid loop)
    if (basename($_SERVER['SCRIPT_FILENAME']) !== 'setup.php') {
        header("Location: $setupUrl");
        exit;
    }
}

// ── Session helper ───────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── Auth helpers ─────────────────────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function requireLogin(string $redirect = '../login.php'): void {
    if (!isLoggedIn()) {
        header("Location: $redirect");
        exit;
    }
}

function requireRole(string $role, string $redirect = '../login.php'): void {
    requireLogin($redirect);
    if ($_SESSION['role'] !== $role) {
        header("Location: $redirect");
        exit;
    }
}

function currentUser(): array {
    return [
        'id'        => $_SESSION['user_id']   ?? 0,
        'username'  => $_SESSION['username']  ?? '',
        'full_name' => $_SESSION['full_name'] ?? '',
        'role'      => $_SESSION['role']      ?? '',
        'email'     => $_SESSION['email']     ?? '',
    ];
}

function escape(mysqli $conn, $val): string {
    return $conn->real_escape_string(trim((string)$val));
}

function redirect(string $url): void {
    header("Location: $url");
    exit;
}

function flash(string $key, string $msg = ''): string {
    if ($msg !== '') {
        $_SESSION['flash'][$key] = $msg;
        return '';
    }
    $out = $_SESSION['flash'][$key] ?? '';
    unset($_SESSION['flash'][$key]);
    return $out;
}

// ── System log helper ────────────────────────────────────────
function writeLog(string $action, string $detail = ''): void {
    global $conn;
    $uid      = $_SESSION['user_id'] ?? null;
    $username = $conn->real_escape_string($_SESSION['username'] ?? 'guest');
    $action   = $conn->real_escape_string($action);
    $detail   = $conn->real_escape_string($detail);
    $ip       = $conn->real_escape_string($_SERVER['REMOTE_ADDR'] ?? '');
    $uidSQL   = $uid ? intval($uid) : 'NULL';
    // Silently ignore if table doesn't exist yet
    $conn->query(
        "INSERT INTO system_logs (user_id, username, action, detail, ip_address)
         VALUES ($uidSQL, '$username', '$action', '$detail', '$ip')"
    );
}
