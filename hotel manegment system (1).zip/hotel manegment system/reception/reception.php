<?php
require_once '../connection.php';
requireRole('reception', '../login.php');
$user = currentUser();

$success = $error = '';

// ── POST Actions ──────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = escape($conn, $_POST['action']);

    // ── Helper: insert a notification for a guest ─────────────
    $notifyGuest = function(int $uid, string $msg) use ($conn): void {
        $safeMsg = $conn->real_escape_string($msg);
        $conn->query("INSERT INTO notifications (user_id, message, is_read) VALUES ($uid, '$safeMsg', 0)");
    };

    // ── Check-in ──────────────────────────────────────────────
    if ($action === 'check_in') {
        $bid = intval($_POST['booking_id']);
        $b   = $conn->query("SELECT b.*, r.room_no FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=$bid AND b.status='confirmed'")->fetch_assoc();
        if ($b) {
            $conn->query("UPDATE bookings SET status='checked_in' WHERE id=$bid");
            $conn->query("UPDATE rooms SET status='booked' WHERE id={$b['room_id']}");
            $notifyGuest(
                (int)$b['user_id'],
                "✅ Check-in Reminder: You have successfully checked in to Room {$b['room_no']} (Booking #$bid). Enjoy your stay at Grand Lake Hotel!"
            );
            $success = 'Guest checked in successfully.';
        } else { $error = 'Booking not found or not in confirmed status.'; }

    // ── Check-out ─────────────────────────────────────────────
    } elseif ($action === 'check_out') {
        $bid = intval($_POST['booking_id']);
        $b   = $conn->query("SELECT b.*, r.room_no FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=$bid AND b.status='checked_in'")->fetch_assoc();
        if ($b) {
            $conn->query("UPDATE bookings SET status='checked_out' WHERE id=$bid");
            $conn->query("UPDATE rooms SET status='cleaning' WHERE id={$b['room_id']}");
            $notifyGuest(
                (int)$b['user_id'],
                "👋 Check-out Complete: You have checked out from Room {$b['room_no']} (Booking #$bid). Thank you for staying with us — we hope to see you again!"
            );
            $success = 'Guest checked out. Room queued for cleaning.';
        } else { $error = 'Booking not found or guest not checked in.'; }

    // ── Confirm reservation ───────────────────────────────────
    } elseif ($action === 'confirm_booking') {
        $bid = intval($_POST['booking_id']);
        $b   = $conn->query("SELECT b.*, r.room_no FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=$bid AND b.status='pending'")->fetch_assoc();
        if ($b) {
            $conn->query("UPDATE bookings SET status='confirmed' WHERE id=$bid");
            $notifyGuest(
                (int)$b['user_id'],
                "🎉 Booking Confirmation: Your booking #$bid for Room {$b['room_no']} has been confirmed! Check-in: {$b['check_in']} — Check-out: {$b['check_out']}. We look forward to welcoming you."
            );
            $success = 'Booking #'.$bid.' confirmed.';
        } else { $error = 'Booking not found or already processed.'; }

    // ── Cancel reservation ────────────────────────────────────
    } elseif ($action === 'cancel_booking') {
        $bid = intval($_POST['booking_id']);
        $b   = $conn->query("SELECT b.*, r.room_no FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.id=$bid AND b.status IN ('pending','confirmed')")->fetch_assoc();
        if ($b) {
            $conn->query("UPDATE bookings SET status='cancelled' WHERE id=$bid");
            $conn->query("UPDATE rooms SET status='available' WHERE id={$b['room_id']}");
            $notifyGuest(
                (int)$b['user_id'],
                "❌ Booking Cancelled: Your booking #$bid for Room {$b['room_no']} (Check-in: {$b['check_in']}) has been cancelled. Please contact reception if you have any questions."
            );
            $success = 'Booking #'.$bid.' cancelled and room released.';
        } else { $error = 'Cannot cancel this booking.'; }

    // ── Record payment ────────────────────────────────────────
    } elseif ($action === 'record_payment') {
        $bid    = intval($_POST['booking_id']);
        $amount = floatval($_POST['amount']);
        $method = escape($conn, $_POST['method']);
        if ($bid && $amount > 0) {
            $conn->query("INSERT INTO payments (booking_id, amount, method, status, paid_at)
                          VALUES ($bid, $amount, '$method', 'paid', NOW())");
            $success = 'Payment of ETB '.number_format($amount,2).' recorded.';
        } else { $error = 'Invalid payment data.'; }

    // ── Log guest communication ───────────────────────────────
    } elseif ($action === 'log_communication') {
        $uid  = intval($_POST['user_id']);
        $msg  = escape($conn, $_POST['message']);
        if ($uid && $msg) {
            $conn->query("INSERT INTO notifications (user_id, message, is_read)
                          VALUES ($uid, '$msg', 0)");
            $success = 'Communication logged and notification sent to guest.';
        } else { $error = 'Please fill in all fields.'; }
    }
}

// ── Stats ─────────────────────────────────────────────────────────────────────
$todayArrivals   = $conn->query("SELECT COUNT(*) c FROM bookings WHERE check_in=CURDATE()  AND status='confirmed'")->fetch_assoc()['c'];
$todayDepartures = $conn->query("SELECT COUNT(*) c FROM bookings WHERE check_out=CURDATE() AND status='checked_in'")->fetch_assoc()['c'];
$currentGuests   = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='checked_in'")->fetch_assoc()['c'];
$pendingConf     = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='pending'")->fetch_assoc()['c'];
$availableRooms  = $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='available'")->fetch_assoc()['c'];
$totalRooms      = $conn->query("SELECT COUNT(*) c FROM rooms")->fetch_assoc()['c'];

// ── Active bookings (check-in / check-out panel) ──────────────────────────────
$activeBookings = $conn->query(
    "SELECT b.*, u.full_name, u.phone, u.email, r.room_no, r.type, r.floor, r.price
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms r ON r.id=b.room_id
     WHERE b.status IN ('pending','confirmed','checked_in')
     ORDER BY b.check_in ASC"
);

// ── Today arrivals ────────────────────────────────────────────────────────────
$arrivalsToday = $conn->query(
    "SELECT b.*, u.full_name, u.phone, r.room_no, r.type, r.floor
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms r ON r.id=b.room_id
     WHERE b.check_in=CURDATE() AND b.status='confirmed'
     ORDER BY b.id ASC"
);

// ── Today departures ──────────────────────────────────────────────────────────
$departuresToday = $conn->query(
    "SELECT b.*, u.full_name, u.phone, r.room_no, r.type, r.floor
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms r ON r.id=b.room_id
     WHERE b.check_out=CURDATE() AND b.status='checked_in'
     ORDER BY b.id ASC"
);

// ── Room status overview ──────────────────────────────────────────────────────
$allRooms = $conn->query(
    "SELECT r.*, 
            (SELECT b.id FROM bookings b WHERE b.room_id=r.id AND b.status='checked_in' LIMIT 1) AS active_booking_id,
            (SELECT u.full_name FROM bookings b JOIN users u ON u.id=b.user_id WHERE b.room_id=r.id AND b.status='checked_in' LIMIT 1) AS current_guest,
            (SELECT b.check_out FROM bookings b WHERE b.room_id=r.id AND b.status='checked_in' LIMIT 1) AS checkout_date
     FROM rooms r
     ORDER BY r.floor ASC, r.room_no ASC"
);

// ── Payments list ─────────────────────────────────────────────────────────────
$payments = $conn->query(
    "SELECT p.*, b.check_in, b.check_out, u.full_name, r.room_no
     FROM payments p
     JOIN bookings b ON b.id=p.booking_id
     JOIN users u ON u.id=b.user_id
     JOIN rooms r ON r.id=b.room_id
     ORDER BY p.created_at DESC
     LIMIT 50"
);

// ── Guest list for communication dropdown ─────────────────────────────────────
$guestList = $conn->query(
    "SELECT DISTINCT u.id, u.full_name, u.email
     FROM users u
     JOIN bookings b ON b.user_id=u.id
     WHERE b.status IN ('confirmed','checked_in')
     ORDER BY u.full_name ASC"
);

// ── Recent notifications / communications ─────────────────────────────────────
$communications = $conn->query(
    "SELECT n.*, u.full_name
     FROM notifications n
     JOIN users u ON u.id=n.user_id
     ORDER BY n.created_at DESC
     LIMIT 30"
);

// ── Daily report data ─────────────────────────────────────────────────────────
$reportDate      = isset($_GET['report_date']) ? escape($conn, $_GET['report_date']) : date('Y-m-d');
$rptArrivals     = $conn->query("SELECT COUNT(*) c FROM bookings WHERE check_in='$reportDate'")->fetch_assoc()['c'];
$rptDepartures   = $conn->query("SELECT COUNT(*) c FROM bookings WHERE check_out='$reportDate'")->fetch_assoc()['c'];
$rptRevenue      = $conn->query("SELECT COALESCE(SUM(p.amount),0) s FROM payments p JOIN bookings b ON b.id=p.booking_id WHERE DATE(p.paid_at)='$reportDate'")->fetch_assoc()['s'];
$rptNewBookings  = $conn->query("SELECT COUNT(*) c FROM bookings WHERE DATE(created_at)='$reportDate'")->fetch_assoc()['c'];
$rptCancelled    = $conn->query("SELECT COUNT(*) c FROM bookings WHERE DATE(created_at)='$reportDate' AND status='cancelled'")->fetch_assoc()['c'];
$rptOccupancy    = $totalRooms > 0 ? round(($currentGuests / $totalRooms) * 100) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Reception — Grand Lake Hotel</title>
  <link rel="stylesheet" href="reception.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<!-- ══════════════════════════════════════════════════════════
     SIDEBAR
══════════════════════════════════════════════════════════ -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div>
      <div class="brand-name">Grand Lake Hotel</div>
      <div class="brand-role">Reception Desk</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-concierge-bell"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Reception</div>
    <a href="#dashboard"      class="nav-link active" data-section="dashboard">
      <i class="fas fa-tachometer-alt"></i> Dashboard
    </a>
    <a href="#checkin"        class="nav-link" data-section="checkin">
      <i class="fas fa-sign-in-alt"></i> Check-in
      <?php if ($todayArrivals > 0): ?><span class="badge"><?= $todayArrivals ?></span><?php endif; ?>
    </a>
    <a href="#checkout"       class="nav-link" data-section="checkout">
      <i class="fas fa-sign-out-alt"></i> Check-out
      <?php if ($todayDepartures > 0): ?><span class="badge"><?= $todayDepartures ?></span><?php endif; ?>
    </a>
    <a href="#reservations"   class="nav-link" data-section="reservations">
      <i class="fas fa-calendar-check"></i> Reservations
      <?php if ($pendingConf > 0): ?><span class="badge"><?= $pendingConf ?></span><?php endif; ?>
    </a>
    <a href="#rooms"          class="nav-link" data-section="rooms">
      <i class="fas fa-door-open"></i> Room Status
    </a>
    <a href="#communication"  class="nav-link" data-section="communication">
      <i class="fas fa-comments"></i> Guest Communication
    </a>
    <a href="#reports"        class="nav-link" data-section="reports">
      <i class="fas fa-chart-bar"></i> Reports &amp; Records
    </a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<!-- ══════════════════════════════════════════════════════════
     MAIN CONTENT
══════════════════════════════════════════════════════════ -->
<div class="main-content">

  <!-- Top Nav -->
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2 id="pageTitle">Dashboard</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / <span id="breadcrumbSub">Reception</span></p>
      </div>
    </div>
    <div class="topnav-right">
      <span style="font-size:.82rem;color:var(--gray);"><?= date('D, d M Y') ?></span>
      <a href="../profile.php" class="topnav-icon"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">

    <!-- Alerts -->
    <?php if ($success): ?>
      <div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-error" data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- ══════════════════════════════════════════════════════
         SECTION: DASHBOARD
    ══════════════════════════════════════════════════════ -->
    <section id="sec-dashboard" class="rec-section">

      <!-- Welcome Banner -->
      <div class="dash-welcome">
        <div class="dash-welcome-text">
          <h2>Welcome back, <span><?= htmlspecialchars(explode(' ', $user['full_name'])[0]) ?></span> 👋</h2>
          <p>Here's what's happening at the front desk today — <?= date('l, d F Y') ?></p>
        </div>
        <div class="dash-welcome-icon"><i class="fas fa-concierge-bell"></i></div>
      </div>

      <style>
        .stat-card-link{text-decoration:none;color:inherit;display:block;border-radius:inherit;transition:transform .18s,box-shadow .18s;}
        .stat-card-link:hover .stat-card{transform:translateY(-4px);box-shadow:0 8px 28px rgba(0,0,0,.13);border-color:var(--primary);cursor:pointer;}
        .stat-card-link:hover .stat-value{color:var(--primary);}
      </style>
      <div class="stats-grid">
        <a href="#checkin" class="stat-card-link" onclick="switchSection('checkin');return false;">
          <div class="stat-card">
            <div class="stat-icon blue"><i class="fas fa-sign-in-alt"></i></div>
            <div class="stat-info">
              <div class="stat-value"><?= $todayArrivals ?></div>
              <div class="stat-label">Today's Arrivals</div>
            </div>
          </div>
        </a>
        <a href="#checkout" class="stat-card-link" onclick="switchSection('checkout');return false;">
          <div class="stat-card">
            <div class="stat-icon yellow"><i class="fas fa-sign-out-alt"></i></div>
            <div class="stat-info">
              <div class="stat-value"><?= $todayDepartures ?></div>
              <div class="stat-label">Today's Departures</div>
            </div>
          </div>
        </a>
        <a href="#reservations" class="stat-card-link" onclick="switchSection('reservations');return false;">
          <div class="stat-card">
            <div class="stat-icon green"><i class="fas fa-user-check"></i></div>
            <div class="stat-info">
              <div class="stat-value"><?= $currentGuests ?></div>
              <div class="stat-label">Current Guests</div>
            </div>
          </div>
        </a>
        <a href="#reservations" class="stat-card-link" onclick="switchSection('reservations');return false;">
          <div class="stat-card">
            <div class="stat-icon red"><i class="fas fa-clock"></i></div>
            <div class="stat-info">
              <div class="stat-value"><?= $pendingConf ?></div>
              <div class="stat-label">Pending Confirmation</div>
            </div>
          </div>
        </a>
        <a href="#rooms" class="stat-card-link" onclick="switchSection('rooms');return false;">
          <div class="stat-card">
            <div class="stat-icon teal"><i class="fas fa-door-open"></i></div>
            <div class="stat-info">
              <div class="stat-value"><?= $availableRooms ?></div>
              <div class="stat-label">Available Rooms</div>
            </div>
          </div>
        </a>
        <a href="#reports" class="stat-card-link" onclick="switchSection('reports');return false;">
          <div class="stat-card">
            <div class="stat-icon purple"><i class="fas fa-percentage"></i></div>
            <div class="stat-info">
              <div class="stat-value"><?= $rptOccupancy ?>%</div>
              <div class="stat-label">Occupancy Rate</div>
            </div>
          </div>
        </a>
      </div>

      <!-- Quick-action shortcuts -->
      <div class="quick-actions-title"><i class="fas fa-bolt"></i> Quick Actions</div>
      <div class="quick-actions">
        <button class="qa-btn" onclick="switchSection('checkin')">
          <div class="qa-icon"><i class="fas fa-sign-in-alt"></i></div>
          <span class="qa-label">Process Check-in</span>
        </button>
        <button class="qa-btn" onclick="switchSection('checkout')">
          <div class="qa-icon"><i class="fas fa-sign-out-alt"></i></div>
          <span class="qa-label">Process Check-out</span>
        </button>
        <button class="qa-btn" onclick="switchSection('reservations')">
          <div class="qa-icon"><i class="fas fa-calendar-check"></i></div>
          <span class="qa-label">Manage Reservations</span>
        </button>
        <button class="qa-btn" onclick="switchSection('rooms')">
          <div class="qa-icon"><i class="fas fa-door-open"></i></div>
          <span class="qa-label">Room Status</span>
        </button>
        <button class="qa-btn" onclick="switchSection('communication')">
          <div class="qa-icon"><i class="fas fa-comments"></i></div>
          <span class="qa-label">Guest Communication</span>
        </button>
        <button class="qa-btn" onclick="switchSection('reports')">
          <div class="qa-icon"><i class="fas fa-chart-bar"></i></div>
          <span class="qa-label">Daily Report</span>
        </button>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════
         SECTION: GUEST CHECK-IN
    ══════════════════════════════════════════════════════ -->
    <section id="sec-checkin" class="rec-section" style="display:none;">
      <div class="section-header-bar">
        <h3><i class="fas fa-sign-in-alt"></i> Guest Check-in Process</h3>
        <p class="section-desc">Confirm guest identity, verify booking, and complete check-in for today's arrivals.</p>
      </div>

      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-calendar-day"></i> Today's Arrivals — <?= date('d M Y') ?></h3>
          <input type="text" class="tbl-search" data-table="tbl-arrivals" placeholder="Search guest or room…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-arrivals">
              <thead>
                <tr>
                  <th>#</th><th>Guest</th><th>Phone</th><th>Room</th>
                  <th>Check-in</th><th>Check-out</th><th>Guests</th>
                  <th>Total (ETB)</th><th>Special Request</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $arrivalsToday->data_seek(0); while ($b = $arrivalsToday->fetch_assoc()): ?>
                <tr>
                  <td><?= $b['id'] ?></td>
                  <td>
                    <strong><?= htmlspecialchars($b['full_name']) ?></strong><br>
                    <small style="color:var(--gray)"><?= htmlspecialchars($b['phone'] ?? '—') ?></small>
                  </td>
                  <td><?= htmlspecialchars($b['phone'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?> · Fl.<?= $b['floor'] ?></td>
                  <td><?= $b['check_in'] ?></td>
                  <td><?= $b['check_out'] ?></td>
                  <td><?= $b['guests'] ?></td>
                  <td><?= number_format($b['total_price'], 2) ?></td>
                  <td><?= htmlspecialchars($b['special_request'] ?? '—') ?></td>
                  <td>
                    <form method="POST">
                      <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                      <button type="submit" name="action" value="check_in" class="btn btn-success btn-sm">
                        <i class="fas fa-sign-in-alt"></i> Check In
                      </button>
                    </form>
                  </td>
                </tr>
                <?php endwhile; ?>
                <?php if ($arrivalsToday->num_rows === 0): ?>
                <tr><td colspan="10" style="text-align:center;color:var(--gray);padding:2rem;">No arrivals scheduled for today.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- All confirmed bookings (not just today) -->
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-list"></i> All Confirmed Bookings (Pending Check-in)</h3>
          <input type="text" class="tbl-search" data-table="tbl-all-checkin" placeholder="Search…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-all-checkin">
              <thead>
                <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Action</th></tr>
              </thead>
              <tbody>
                <?php
                $confirmed = $conn->query("SELECT b.*, u.full_name, r.room_no, r.type, r.floor FROM bookings b JOIN users u ON u.id=b.user_id JOIN rooms r ON r.id=b.room_id WHERE b.status='confirmed' ORDER BY b.check_in ASC");
                while ($b = $confirmed->fetch_assoc()):
                ?>
                <tr>
                  <td><?= $b['id'] ?></td>
                  <td><?= htmlspecialchars($b['full_name']) ?></td>
                  <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?></td>
                  <td><?= $b['check_in'] ?></td>
                  <td><?= $b['check_out'] ?></td>
                  <td><?= number_format($b['total_price'],2) ?> birr</td>
                  <td>
                    <form method="POST">
                      <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                      <button type="submit" name="action" value="check_in" class="btn btn-success btn-sm">
                        <i class="fas fa-sign-in-alt"></i> Check In
                      </button>
                    </form>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════
         SECTION: GUEST CHECK-OUT
    ══════════════════════════════════════════════════════ -->
    <section id="sec-checkout" class="rec-section" style="display:none;">
      <div class="section-header-bar">
        <h3><i class="fas fa-sign-out-alt"></i> Guest Check-out Process</h3>
        <p class="section-desc">Process departures, settle outstanding balances, and release rooms for housekeeping.</p>
      </div>

      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-calendar-day"></i> Today's Departures — <?= date('d M Y') ?></h3>
          <input type="text" class="tbl-search" data-table="tbl-departures" placeholder="Search…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-departures">
              <thead>
                <tr>
                  <th>#</th><th>Guest</th><th>Room</th><th>Check-in</th>
                  <th>Check-out</th><th>Nights</th><th>Total (birr)</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $departuresToday->data_seek(0); while ($b = $departuresToday->fetch_assoc()):
                  $nights = (strtotime($b['check_out']) - strtotime($b['check_in'])) / 86400;
                ?>
                <tr>
                  <td><?= $b['id'] ?></td>
                  <td>
                    <strong><?= htmlspecialchars($b['full_name']) ?></strong><br>
                    <small style="color:var(--gray)"><?= htmlspecialchars($b['phone'] ?? '—') ?></small>
                  </td>
                  <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?> · Fl.<?= $b['floor'] ?></td>
                  <td><?= $b['check_in'] ?></td>
                  <td><?= $b['check_out'] ?></td>
                  <td><?= $nights ?></td>
                  <td><?= number_format($b['total_price'], 2) ?></td>
                  <td>
                    <form method="POST" style="display:inline;">
                      <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                      <button type="submit" name="action" value="check_out" class="btn btn-accent btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Check Out
                      </button>
                    </form>
                  </td>
                </tr>
                <?php endwhile; ?>
                <?php if ($departuresToday->num_rows === 0): ?>
                <tr><td colspan="8" style="text-align:center;color:var(--gray);padding:2rem;">No departures scheduled for today.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- All currently checked-in guests -->
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-user-check"></i> All Currently Checked-in Guests</h3>
          <input type="text" class="tbl-search" data-table="tbl-inhouse" placeholder="Search…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-inhouse">
              <thead>
                <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Action</th></tr>
              </thead>
              <tbody>
                <?php
                $inhouse = $conn->query("SELECT b.*, u.full_name, u.phone, r.room_no, r.type, r.floor FROM bookings b JOIN users u ON u.id=b.user_id JOIN rooms r ON r.id=b.room_id WHERE b.status='checked_in' ORDER BY b.check_out ASC");
                while ($b = $inhouse->fetch_assoc()):
                ?>
                <tr>
                  <td><?= $b['id'] ?></td>
                  <td><?= htmlspecialchars($b['full_name']) ?></td>
                  <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?></td>
                  <td><?= $b['check_in'] ?></td>
                  <td><?= $b['check_out'] ?></td>
                  <td><?= number_format($b['total_price'],2) ?> birr</td>
                  <td>
                    <form method="POST">
                      <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                      <button type="submit" name="action" value="check_out" class="btn btn-accent btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Check Out
                      </button>
                    </form>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════
         SECTION: ROOM RESERVATION MANAGEMENT
    ══════════════════════════════════════════════════════ -->
    <section id="sec-reservations" class="rec-section" style="display:none;">
      <div class="section-header-bar">
        <h3><i class="fas fa-calendar-check"></i> Room Reservation Management</h3>
        <p class="section-desc">View, confirm, or cancel guest reservations. Manage pending and upcoming bookings.</p>
      </div>

      <!-- Record Payment Modal trigger row -->
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-list-alt"></i> All Active Reservations</h3>
          <input type="text" class="tbl-search" data-table="tbl-reservations" placeholder="Search guest, room…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-reservations">
              <thead>
                <tr>
                  <th>#</th><th>Guest</th><th>Phone</th><th>Room</th>
                  <th>Check-in</th><th>Check-out</th><th>Guests</th>
                  <th>Total (birr)</th><th>Status</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $activeBookings->data_seek(0); while ($b = $activeBookings->fetch_assoc()): ?>
                <tr>
                  <td><?= $b['id'] ?></td>
                  <td>
                    <strong><?= htmlspecialchars($b['full_name']) ?></strong><br>
                    <small style="color:var(--gray)"><?= htmlspecialchars($b['email'] ?? '') ?></small>
                  </td>
                  <td><?= htmlspecialchars($b['phone'] ?? '—') ?></td>
                  <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?> · Fl.<?= $b['floor'] ?></td>
                  <td><?= $b['check_in'] ?></td>
                  <td><?= $b['check_out'] ?></td>
                  <td><?= $b['guests'] ?></td>
                  <td><?= number_format($b['total_price'], 2) ?></td>
                  <td><span class="badge badge-<?= $b['status'] ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
                  <td style="white-space:nowrap;">
                    <?php if ($b['status'] === 'pending'): ?>
                      <form method="POST" style="display:inline;">
                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                        <button type="submit" name="action" value="confirm_booking" class="btn btn-success btn-sm">
                          <i class="fas fa-check"></i> Confirm
                        </button>
                      </form>
                      <form method="POST" style="display:inline;" onsubmit="return confirm('Cancel booking #<?= $b['id'] ?>?')">
                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                        <button type="submit" name="action" value="cancel_booking" class="btn btn-danger btn-sm">
                          <i class="fas fa-times"></i> Cancel
                        </button>
                      </form>
                    <?php elseif ($b['status'] === 'confirmed'): ?>
                      <form method="POST" style="display:inline;">
                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                        <button type="submit" name="action" value="check_in" class="btn btn-primary-d btn-sm">
                          <i class="fas fa-sign-in-alt"></i> Check In
                        </button>
                      </form>
                      <form method="POST" style="display:inline;" onsubmit="return confirm('Cancel booking #<?= $b['id'] ?>?')">
                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                        <button type="submit" name="action" value="cancel_booking" class="btn btn-danger btn-sm">
                          <i class="fas fa-times"></i> Cancel
                        </button>
                      </form>
                    <?php elseif ($b['status'] === 'checked_in'): ?>
                      <form method="POST" style="display:inline;">
                        <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                        <button type="submit" name="action" value="check_out" class="btn btn-accent btn-sm">
                          <i class="fas fa-sign-out-alt"></i> Check Out
                        </button>
                      </form>
                    <?php endif; ?>
                    <!-- Record Payment -->
                    <button class="btn btn-outline-d btn-sm"
                            onclick="openPayModal(<?= $b['id'] ?>, '<?= htmlspecialchars($b['full_name']) ?>', <?= $b['total_price'] ?>)">
                      <i class="fas fa-money-bill-wave"></i> Payment
                    </button>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════
         SECTION: ROOM STATUS MONITORING
    ══════════════════════════════════════════════════════ -->
    <section id="sec-rooms" class="rec-section" style="display:none;">
      <div class="section-header-bar">
        <h3><i class="fas fa-door-open"></i> Room Status Monitoring</h3>
        <p class="section-desc">Live overview of every room — availability, occupancy, cleaning, and maintenance status.</p>
      </div>

      <!-- Legend -->
      <div class="room-legend">
        <span class="rl-item"><span class="rl-dot available"></span> Available</span>
        <span class="rl-item"><span class="rl-dot booked"></span> Occupied</span>
        <span class="rl-item"><span class="rl-dot cleaning"></span> Cleaning</span>
        <span class="rl-item"><span class="rl-dot maintenance"></span> Maintenance</span>
      </div>

      <!-- Room grid -->
      <div class="room-status-grid">
        <?php $allRooms->data_seek(0); while ($r = $allRooms->fetch_assoc()): ?>
        <div class="room-status-card rs-<?= $r['status'] ?>">
          <div class="rs-header">
            <span class="rs-number"><?= htmlspecialchars($r['room_no']) ?></span>
            <span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span>
          </div>
          <div class="rs-type"><?= ucfirst($r['type']) ?> · Floor <?= $r['floor'] ?></div>
          <div class="rs-price"><?= number_format($r['price'],2) ?> birr/night</div>
          <?php if ($r['current_guest']): ?>
            <div class="rs-guest"><i class="fas fa-user"></i> <?= htmlspecialchars($r['current_guest']) ?></div>
            <div class="rs-checkout"><i class="fas fa-calendar-times"></i> Out: <?= $r['checkout_date'] ?></div>
          <?php endif; ?>
        </div>
        <?php endwhile; ?>
      </div>

      <!-- Table view -->
      <div class="card" style="margin-top:2rem;">
        <div class="card-header">
          <h3><i class="fas fa-table"></i> Room Status Table</h3>
          <input type="text" class="tbl-search" data-table="tbl-rooms" placeholder="Search room…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-rooms">
              <thead>
                <tr><th>Room No</th><th>Type</th><th>Floor</th><th>Capacity</th><th>Price/Night</th><th>Status</th><th>Current Guest</th><th>Check-out</th></tr>
              </thead>
              <tbody>
                <?php
                $allRooms->data_seek(0);
                while ($r = $allRooms->fetch_assoc()):
                ?>
                <tr>
                  <td><strong><?= htmlspecialchars($r['room_no']) ?></strong></td>
                  <td><?= ucfirst($r['type']) ?></td>
                  <td><?= $r['floor'] ?></td>
                  <td><?= $r['capacity'] ?></td>
                  <td><?= number_format($r['price'],2) ?> birr</td>
                  <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                  <td><?= $r['current_guest'] ? htmlspecialchars($r['current_guest']) : '—' ?></td>
                  <td><?= $r['checkout_date'] ?? '—' ?></td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════
         SECTION: CUSTOMER SERVICE & COMMUNICATION
    ══════════════════════════════════════════════════════ -->
    <section id="sec-communication" class="rec-section" style="display:none;">
      <div class="section-header-bar">
        <h3><i class="fas fa-comments"></i> Customer Service &amp; Communication</h3>
        <p class="section-desc">Send notifications to guests, log service requests, and track all guest communications.</p>
      </div>

      <div class="two-col-layout">
        <!-- Send message form -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-paper-plane"></i> Send Guest Notification</h3>
          </div>
          <div class="card-body">
            <form method="POST">
              <input type="hidden" name="action" value="log_communication" />
              <div class="form-group">
                <label>Select Guest</label>
                <select name="user_id" required>
                  <option value="">— Choose a guest —</option>
                  <?php $guestList->data_seek(0); while ($g = $guestList->fetch_assoc()): ?>
                  <option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['full_name']) ?> (<?= htmlspecialchars($g['email']) ?>)</option>
                  <?php endwhile; ?>
                </select>
              </div>
              <div class="form-group">
                <label>Message / Service Note</label>
                <textarea name="message" rows="4" placeholder="e.g. Your room is ready. Welcome to Grand Lake Hotel!" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary-d">
                <i class="fas fa-paper-plane"></i> Send &amp; Log
              </button>
            </form>
          </div>
        </div>

        <!-- Communication log -->
        <div class="card">
          <div class="card-header">
            <h3><i class="fas fa-history"></i> Recent Communications</h3>
          </div>
          <div class="card-body" style="max-height:420px;overflow-y:auto;">
            <?php $communications->data_seek(0); $hasComm = false; while ($c = $communications->fetch_assoc()): $hasComm = true; ?>
            <div class="comm-item <?= $c['is_read'] ? '' : 'comm-unread' ?>">
              <div class="comm-meta">
                <span class="comm-guest"><i class="fas fa-user"></i> <?= htmlspecialchars($c['full_name']) ?></span>
                <span class="comm-time"><?= date('d M Y H:i', strtotime($c['created_at'])) ?></span>
                <?php if (!$c['is_read']): ?><span class="badge badge-open" style="font-size:.65rem;">Unread</span><?php endif; ?>
              </div>
              <p class="comm-msg"><?= htmlspecialchars($c['message']) ?></p>
            </div>
            <?php endwhile; ?>
            <?php if (!$hasComm): ?>
              <p style="color:var(--gray);text-align:center;padding:2rem;">No communications logged yet.</p>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </section>

    <!-- ══════════════════════════════════════════════════════
         SECTION: REPORTING & RECORDS
    ══════════════════════════════════════════════════════ -->
    <section id="sec-reports" class="rec-section" style="display:none;">
      <div class="section-header-bar">
        <h3><i class="fas fa-chart-bar"></i> Reporting &amp; Records</h3>
        <p class="section-desc">Daily activity summaries, payment records, and occupancy reports.</p>
      </div>

      <!-- Date picker for report -->
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-calendar-alt"></i> Daily Report</h3>
          <form method="GET" style="display:flex;gap:.5rem;align-items:center;">
            <input type="hidden" name="section" value="reports" />
            <input type="date" name="report_date" value="<?= htmlspecialchars($reportDate) ?>"
                   style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
            <button type="submit" class="btn btn-primary-d btn-sm"><i class="fas fa-search"></i> View</button>
          </form>
        </div>
        <div class="card-body">
          <div class="report-stats">
            <div class="rpt-card blue">
              <i class="fas fa-sign-in-alt"></i>
              <div class="rpt-val"><?= $rptArrivals ?></div>
              <div class="rpt-lbl">Arrivals</div>
            </div>
            <div class="rpt-card yellow">
              <i class="fas fa-sign-out-alt"></i>
              <div class="rpt-val"><?= $rptDepartures ?></div>
              <div class="rpt-lbl">Departures</div>
            </div>
            <div class="rpt-card green">
              <i class="fas fa-money-bill-wave"></i>
              <div class="rpt-val"><?= number_format($rptRevenue, 2) ?></div>
              <div class="rpt-lbl">Revenue (birr)</div>
            </div>
            <div class="rpt-card teal">
              <i class="fas fa-calendar-plus"></i>
              <div class="rpt-val"><?= $rptNewBookings ?></div>
              <div class="rpt-lbl">New Bookings</div>
            </div>
            <div class="rpt-card red">
              <i class="fas fa-calendar-times"></i>
              <div class="rpt-val"><?= $rptCancelled ?></div>
              <div class="rpt-lbl">Cancellations</div>
            </div>
            <div class="rpt-card purple">
              <i class="fas fa-percentage"></i>
              <div class="rpt-val"><?= $rptOccupancy ?>%</div>
              <div class="rpt-lbl">Occupancy</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Payment records -->
      <div class="card">
        <div class="card-header">
          <h3><i class="fas fa-receipt"></i> Payment Records</h3>
          <input type="text" class="tbl-search" data-table="tbl-payments" placeholder="Search…" />
        </div>
        <div class="card-body">
          <div class="table-wrap">
            <table class="data-table" id="tbl-payments">
              <thead>
                <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Amount (birr)</th><th>Method</th><th>Status</th><th>Paid At</th></tr>
              </thead>
              <tbody>
                <?php $payments->data_seek(0); while ($p = $payments->fetch_assoc()): ?>
                <tr>
                  <td><?= $p['id'] ?></td>
                  <td><?= htmlspecialchars($p['full_name']) ?></td>
                  <td><?= htmlspecialchars($p['room_no']) ?></td>
                  <td><?= $p['check_in'] ?></td>
                  <td><?= $p['check_out'] ?></td>
                  <td><?= number_format($p['amount'], 2) ?></td>
                  <td><?= ucfirst(str_replace('_',' ',$p['method'])) ?></td>
                  <td><span class="badge badge-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                  <td><?= $p['paid_at'] ? date('d M Y H:i', strtotime($p['paid_at'])) : '—' ?></td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

  </div><!-- /page-content -->
</div><!-- /main-content -->

<!-- ══════════════════════════════════════════════════════════
     PAYMENT MODAL
══════════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="payModal">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-money-bill-wave"></i> Record Payment</h3>
      <button class="modal-close" onclick="closePayModal()"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST">
      <input type="hidden" name="action" value="record_payment" />
      <div class="modal-body">
        <p id="payModalGuest" style="margin-bottom:1rem;color:var(--gray);font-size:.9rem;"></p>
        <input type="hidden" name="booking_id" id="payBookingId" />
        <div class="form-group">
          <label>Amount (birr)</label>
          <input type="number" name="amount" id="payAmount" step="0.01" min="1" required />
        </div>
        <div class="form-group">
          <label>Payment Method</label>
          <select name="method" required>
            <option value="cash">Cash</option>
            <option value="card">Card</option>
            <option value="bank_transfer">Bank Transfer</option>
            <option value="mobile_money">Mobile Money</option>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-d" onclick="closePayModal()">Cancel</button>
        <button type="submit" class="btn btn-success"><i class="fas fa-check"></i> Record Payment</button>
      </div>
    </form>
  </div>
</div>

<script src="reception.js"></script>
</body>
</html>
