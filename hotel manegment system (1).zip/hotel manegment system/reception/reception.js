document.addEventListener('DOMContentLoaded', () => {

  // ── Sidebar toggle ────────────────────────────────────────
  const sidebar   = document.getElementById('sidebar');
  const hamburger = document.getElementById('hamburgerDash');
  if (hamburger && sidebar) {
    hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
  }

  // ── Auto-dismiss alerts ───────────────────────────────────
  document.querySelectorAll('.alert[data-dismiss]').forEach(el => {
    setTimeout(() => el.style.display = 'none', 5000);
  });

  // ── Section navigation ────────────────────────────────────
  const sectionTitles = {
    dashboard:     'Dashboard',
    checkin:       'Guest Check-in',
    checkout:      'Guest Check-out',
    reservations:  'Reservation Management',
    rooms:         'Room Status Monitoring',
    communication: 'Customer Service & Communication',
    reports:       'Reporting & Records',
  };

  window.switchSection = function(name) {
    // hide all sections
    document.querySelectorAll('.rec-section').forEach(s => s.style.display = 'none');
    // show target
    const target = document.getElementById('sec-' + name);
    if (target) target.style.display = 'block';
    // update nav active state
    document.querySelectorAll('.nav-link').forEach(a => {
      a.classList.toggle('active', a.dataset.section === name);
    });
    // update page title
    const titleEl = document.getElementById('pageTitle');
    const breadEl = document.getElementById('breadcrumbSub');
    if (titleEl) titleEl.textContent = sectionTitles[name] || name;
    if (breadEl) breadEl.textContent = sectionTitles[name] || name;
    // close sidebar on mobile
    if (window.innerWidth <= 1024 && sidebar) sidebar.classList.remove('open');
  };

  // Attach nav link clicks
  document.querySelectorAll('.nav-link[data-section]').forEach(a => {
    a.addEventListener('click', e => {
      e.preventDefault();
      switchSection(a.dataset.section);
    });
  });

  // On load: check URL hash or query param
  const params = new URLSearchParams(window.location.search);
  const hashSection = window.location.hash.replace('#', '');
  const qSection    = params.get('section');
  const initSection = qSection || hashSection || 'dashboard';
  switchSection(initSection);

  // ── Table search ──────────────────────────────────────────
  document.querySelectorAll('.tbl-search').forEach(input => {
    input.addEventListener('input', function () {
      const q     = this.value.toLowerCase();
      const table = document.getElementById(this.dataset.table);
      if (!table) return;
      table.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });

});

// ── Payment modal ─────────────────────────────────────────
function openPayModal(bookingId, guestName, totalPrice) {
  document.getElementById('payBookingId').value  = bookingId;
  document.getElementById('payAmount').value     = totalPrice;
  document.getElementById('payModalGuest').textContent =
    'Booking #' + bookingId + ' — ' + guestName + ' — Total: ' + parseFloat(totalPrice).toFixed(2) + ' birr';
  document.getElementById('payModal').classList.add('open');
}

function closePayModal() {
  document.getElementById('payModal').classList.remove('open');
}

// Close modal on overlay click
document.addEventListener('click', e => {
  const modal = document.getElementById('payModal');
  if (modal && e.target === modal) closePayModal();
});
