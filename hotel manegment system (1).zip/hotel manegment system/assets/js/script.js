/**
 * Grand Lake Hotel — Shared JavaScript
 * assets/js/script.js
 *
 * Used by public-facing pages that include includes/footer.php.
 * Dashboard pages use admin/admin.js directly.
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {

  // ── Sticky header ─────────────────────────────────────────
  const header = document.getElementById('siteHeader');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 80);
    });
  }

  // ── Hamburger menu ────────────────────────────────────────
  const hamburger = document.getElementById('hamburger');
  const mainNav   = document.getElementById('mainNav');
  if (hamburger && mainNav) {
    hamburger.addEventListener('click', () => {
      mainNav.classList.toggle('open');
      hamburger.setAttribute('aria-expanded', mainNav.classList.contains('open'));
    });
    // Close on outside click
    document.addEventListener('click', e => {
      if (!hamburger.contains(e.target) && !mainNav.contains(e.target)) {
        mainNav.classList.remove('open');
      }
    });
  }

  // ── Counter animation (hero stats) ───────────────────────
  function animateCounters() {
    document.querySelectorAll('.stat-num[data-target]').forEach(el => {
      const target = parseInt(el.dataset.target, 10);
      let count = 0;
      const step = Math.ceil(target / 60);
      const timer = setInterval(() => {
        count = Math.min(count + step, target);
        el.textContent = count.toLocaleString();
        if (count >= target) clearInterval(timer);
      }, 30);
    });
  }

  const heroStats = document.querySelector('.hero-stats');
  if (heroStats) {
    new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) animateCounters();
    }, { threshold: 0.5 }).observe(heroStats);
  }

  // ── Set min date on all date inputs ───────────────────────
  const today = new Date().toISOString().split('T')[0];
  document.querySelectorAll('input[type="date"]').forEach(i => {
    if (!i.min) i.min = today;
  });

  // ── Contact form ──────────────────────────────────────────
  const contactForm = document.querySelector('.contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      const success = document.getElementById('contact-success');
      if (success) success.style.display = 'block';
      contactForm.reset();
    });
  }

  // ── Gallery filter tabs ───────────────────────────────────
  document.querySelectorAll('.gf-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.gf-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.dataset.filter;
      document.querySelectorAll('.gallery-item').forEach(item => {
        const match = filter === 'all' || item.dataset.category === filter;
        item.classList.toggle('hidden', !match);
      });
    });
  });

  // ── Lightbox ──────────────────────────────────────────────
  const lightbox  = document.getElementById('lightbox');
  const lbImg     = document.getElementById('lbImg');
  const lbCaption = document.getElementById('lbCaption');
  let galleryImgs = [];
  let lbIndex     = 0;

  if (lightbox) {
    function buildGalleryList() {
      galleryImgs = [...document.querySelectorAll('.gallery-item:not(.hidden) img')];
    }

    function showLbImage(i) {
      const img = galleryImgs[i];
      if (!img) return;
      lbImg.src = img.src.replace(/w=\d+/, 'w=1400');
      lbImg.alt = img.alt;
      const caption = img.closest('.gallery-item')?.querySelector('.gallery-caption');
      if (lbCaption) lbCaption.textContent = caption ? caption.textContent.trim() : '';
    }

    function openLightbox(img) {
      buildGalleryList();
      lbIndex = galleryImgs.indexOf(img);
      showLbImage(lbIndex);
      lightbox.classList.add('active');
      document.body.style.overflow = 'hidden';
    }

    function closeLightbox() {
      lightbox.classList.remove('active');
      document.body.style.overflow = '';
    }

    document.querySelectorAll('.gallery-item').forEach(item => {
      item.addEventListener('click', () => openLightbox(item.querySelector('img')));
    });

    document.getElementById('lbClose')?.addEventListener('click', closeLightbox);
    document.getElementById('lbPrev')?.addEventListener('click', () => {
      lbIndex = (lbIndex - 1 + galleryImgs.length) % galleryImgs.length;
      showLbImage(lbIndex);
    });
    document.getElementById('lbNext')?.addEventListener('click', () => {
      lbIndex = (lbIndex + 1) % galleryImgs.length;
      showLbImage(lbIndex);
    });
    lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });
    document.addEventListener('keydown', e => {
      if (!lightbox.classList.contains('active')) return;
      if (e.key === 'Escape')     closeLightbox();
      if (e.key === 'ArrowLeft')  { lbIndex = (lbIndex - 1 + galleryImgs.length) % galleryImgs.length; showLbImage(lbIndex); }
      if (e.key === 'ArrowRight') { lbIndex = (lbIndex + 1) % galleryImgs.length; showLbImage(lbIndex); }
    });
  }

  // ── Newsletter form ───────────────────────────────────────
  document.querySelectorAll('.newsletter-form').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      form.querySelector('input').value = '';
      const msg = document.createElement('p');
      msg.style.cssText = 'color:var(--accent);font-size:.85rem;margin-top:.5rem;';
      msg.textContent = '✓ Subscribed!';
      if (!form.nextElementSibling?.textContent.includes('Subscribed')) {
        form.insertAdjacentElement('afterend', msg);
      }
    });
  });

});
