Place hotel images here (room photos, logo, gallery images).
This folder is referenced by the public landing page (index.html) and the shared stylesheet.
