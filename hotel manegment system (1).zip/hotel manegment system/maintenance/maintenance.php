<?php
require_once '../connection.php';
requireRole('maintenance', '../login.php');
$user = currentUser();

$success = $error = '';

// ── Add Request ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_request'])) {
    $room_id  = intval($_POST['room_id']);
    $title    = escape($conn, $_POST['title']);
    $desc     = escape($conn, $_POST['description']);
    $priority = escape($conn, $_POST['priority']);
    $uid      = $user['id'];

    $stmt = $conn->prepare(
        "INSERT INTO maintenance_requests (room_id,reported_by,assigned_to,title,description,priority)
         VALUES (?,?,?,?,?,?)"
    );
    $stmt->bind_param("iiisss", $room_id, $uid, $uid, $title, $desc, $priority);
    $stmt->execute() ? $success = 'Maintenance request submitted.' : $error = 'Failed to submit request.';
    $stmt->close();
}

// ── Update Status ─────────────────────────────────────────
if (isset($_GET['resolve']) && is_numeric($_GET['resolve'])) {
    $id = intval($_GET['resolve']);
    $req = $conn->query("SELECT room_id FROM maintenance_requests WHERE id=$id AND assigned_to={$user['id']}")->fetch_assoc();
    $conn->query("UPDATE maintenance_requests SET status='resolved', resolved_at=NOW() WHERE id=$id AND assigned_to={$user['id']}");
    // When resolved, set room back to available (only if still in maintenance)
    if ($req) {
        $conn->query("UPDATE rooms SET status='available' WHERE id={$req['room_id']} AND status='maintenance'");
    }
    $success = 'Request marked as resolved. Room status restored to available.';
}
if (isset($_GET['progress']) && is_numeric($_GET['progress'])) {
    $id = intval($_GET['progress']);
    $req = $conn->query("SELECT room_id FROM maintenance_requests WHERE id=$id")->fetch_assoc();
    $conn->query("UPDATE maintenance_requests SET status='in_progress' WHERE id=$id");
    // When work starts, set room to maintenance status
    if ($req) {
        $conn->query("UPDATE rooms SET status='maintenance' WHERE id={$req['room_id']}");
    }
    $success = 'Request marked as in progress. Room set to maintenance status.';
}

// ── Stats ─────────────────────────────────────────────────
$openCount     = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='open'")->fetch_assoc()['c'];
$inProgCount   = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='in_progress'")->fetch_assoc()['c'];
$resolvedCount = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='resolved'")->fetch_assoc()['c'];
$urgentCount   = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE priority='urgent' AND status!='resolved'")->fetch_assoc()['c'];

// ── Data ──────────────────────────────────────────────────
$requests = $conn->query(
    "SELECT m.*, r.room_no, u.full_name reporter
     FROM maintenance_requests m
     JOIN rooms r ON r.id=m.room_id
     JOIN users u ON u.id=m.reported_by
     ORDER BY FIELD(m.priority,'urgent','high','medium','low'), m.created_at DESC"
);
$rooms = $conn->query("SELECT id, room_no, type FROM rooms ORDER BY room_no");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Maintenance — Grand Lake Hotel</title>
  <link rel="stylesheet" href="maintenance.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Maintenance</div></div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-tools"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Maintenance</div>
    <a href="#" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="#requests"><i class="fas fa-list"></i> All Requests <span class="badge"><?= $openCount ?></span></a>
    <a href="#" onclick="openModal('addRequestModal');return false;"><i class="fas fa-plus-circle"></i> New Request</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Maintenance Panel</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / Maintenance</p>
      </div>
    </div>
    <div class="topnav-right">
      <button class="btn btn-primary-d btn-sm" onclick="openModal('addRequestModal')">
        <i class="fas fa-plus"></i> New Request
      </button>
      <a href="../profile.php" class="topnav-icon"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-exclamation-circle"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $openCount ?></div><div class="stat-label">Open Requests</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon yellow"><i class="fas fa-spinner"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $inProgCount ?></div><div class="stat-label">In Progress</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $resolvedCount ?></div><div class="stat-label">Resolved</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-fire"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $urgentCount ?></div><div class="stat-label">Urgent</div></div>
      </div>
    </div>

    <!-- Requests Table -->
    <div class="card" id="requests">
      <div class="card-header">
        <h3><i class="fas fa-tools"></i> Maintenance Requests</h3>
        <input type="text" id="tableSearch" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table searchable-table">
            <thead><tr><th>#</th><th>Room</th><th>Title</th><th>Priority</th><th>Status</th><th>Reported By</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
              <?php while ($r = $requests->fetch_assoc()): ?>
                <tr>
                  <td><?= $r['id'] ?></td>
                  <td><strong><?= htmlspecialchars($r['room_no']) ?></strong></td>
                  <td>
                    <?= htmlspecialchars($r['title']) ?>
                    <?php if ($r['description']): ?>
                      <br><small style="color:var(--gray)"><?= htmlspecialchars(substr($r['description'],0,60)) ?>...</small>
                    <?php endif; ?>
                  </td>
                  <td><span class="badge badge-<?= $r['priority'] ?>"><?= ucfirst($r['priority']) ?></span></td>
                  <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst(str_replace('_',' ',$r['status'])) ?></span></td>
                  <td><?= htmlspecialchars($r['reporter']) ?></td>
                  <td><?= date('M d', strtotime($r['created_at'])) ?></td>
                  <td>
                    <?php if ($r['status'] === 'open'): ?>
                      <a href="?progress=<?= $r['id'] ?>" class="btn btn-accent btn-sm"><i class="fas fa-play"></i> Start</a>
                    <?php elseif ($r['status'] === 'in_progress'): ?>
                      <a href="?resolve=<?= $r['id'] ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Resolve</a>
                    <?php else: ?>
                      <span style="color:var(--gray);font-size:.8rem;"><i class="fas fa-check-circle"></i> Done</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Add Request Modal -->
<div class="modal-overlay" id="addRequestModal">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-plus-circle"></i> New Maintenance Request</h3>
      <button class="modal-close" onclick="closeModal('addRequestModal')">&times;</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-group">
          <label>Room</label>
          <select name="room_id" required>
            <option value="">Select room...</option>
            <?php $rooms->data_seek(0); while ($r = $rooms->fetch_assoc()): ?>
              <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['room_no']) ?> (<?= ucfirst($r['type']) ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Issue Title</label>
          <input type="text" name="title" placeholder="e.g. AC not working" required />
        </div>
        <div class="form-group">
          <label>Priority</label>
          <select name="priority" required>
            <option value="low">Low</option>
            <option value="medium" selected>Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea name="description" rows="3" placeholder="Describe the issue in detail..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-d" onclick="closeModal('addRequestModal')">Cancel</button>
        <button type="submit" name="add_request" class="btn btn-primary-d"><i class="fas fa-paper-plane"></i> Submit</button>
      </div>
    </form>
  </div>
</div>

<script src="maintenance.js"></script>
</body>
</html>
