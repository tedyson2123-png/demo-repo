'use strict';

document.addEventListener('DOMContentLoaded', () => {

  // ══════════════════════════════════════════════════════
  //  SIDEBAR TOGGLE
  // ══════════════════════════════════════════════════════
  const sidebar   = document.getElementById('sidebar');
  const hamburger = document.getElementById('hamburgerDash');
  hamburger?.addEventListener('click', () => sidebar?.classList.toggle('open'));

  // ══════════════════════════════════════════════════════
  //  ALERT AUTO-DISMISS (4 seconds)
  // ══════════════════════════════════════════════════════
  document.querySelectorAll('.alert[data-dismiss]').forEach(el => {
    setTimeout(() => el.remove(), 4000);
  });

  // ══════════════════════════════════════════════════════
  //  CONFIRM LINKS (cancel booking / cancel order)
  // ══════════════════════════════════════════════════════
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => {
      if (!confirm(el.dataset.confirm)) e.preventDefault();
    });
  });

  // ══════════════════════════════════════════════════════
  //  ROOM BOOKING — card selection + nights calculator
  // ══════════════════════════════════════════════════════
  const roomIdInput    = document.getElementById('room_id');
  const roomPriceInput = document.getElementById('room_price');

  document.querySelectorAll('.room-select-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.room-select-card').forEach(c => c.classList.remove('selected'));
      card.classList.add('selected');
      if (roomIdInput)    roomIdInput.value    = card.dataset.roomId;
      if (roomPriceInput) roomPriceInput.value = card.dataset.price;
      calcNights();
    });
  });

  const checkInEl  = document.getElementById('check_in');
  const checkOutEl = document.getElementById('check_out');

  // Set minimum date to today
  const today = new Date().toISOString().split('T')[0];
  if (checkInEl)  checkInEl.min  = today;
  if (checkOutEl) checkOutEl.min = today;

  function calcNights() {
    const d1 = new Date(checkInEl?.value);
    const d2 = new Date(checkOutEl?.value);
    const nightsEl = document.getElementById('nights_display');
    const totalEl  = document.getElementById('total_display');
    if (!nightsEl) return;
    if (d2 > d1) {
      const nights = Math.ceil((d2 - d1) / 86400000);
      const price  = parseFloat(roomPriceInput?.value || 0);
      nightsEl.textContent = nights + ' night' + (nights !== 1 ? 's' : '');
      if (totalEl) totalEl.textContent = 'ETB ' + (nights * price).toFixed(2);
    } else {
      nightsEl.textContent = '—';
      if (totalEl) totalEl.textContent = '—';
    }
  }

  checkInEl?.addEventListener('change', () => {
    // Ensure check-out is after check-in
    if (checkOutEl && checkInEl.value >= checkOutEl.value) {
      checkOutEl.value = '';
    }
    checkOutEl.min = checkInEl.value;
    calcNights();
  });
  checkOutEl?.addEventListener('change', calcNights);

  // ══════════════════════════════════════════════════════
  //  FOOD ORDER — category tab switching
  // ══════════════════════════════════════════════════════
  document.querySelectorAll('.menu-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.menu-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      document.querySelectorAll('.menu-grid').forEach(g => g.style.display = 'none');
      const grid = document.getElementById('cat-' + tab.dataset.cat);
      if (grid) grid.style.display = 'grid';
    });
  });

  // ══════════════════════════════════════════════════════
  //  CART FACTORY
  //  Reusable for both Food Order and Room Service.
  //  Options:
  //    addBtnSel   — CSS selector for "Add" buttons
  //    listId      — <ul> element id for cart rows
  //    countId     — badge span showing item count
  //    totalId     — span showing total price
  //    itemsInputId— hidden input that holds JSON for form
  //    submitBtnId — submit button (disabled when empty)
  //    clearBtnId  — "Clear" button
  // ══════════════════════════════════════════════════════
  function makeCart({ addBtnSel, listId, countId, totalId, itemsInputId, submitBtnId, clearBtnId }) {
    let cart = []; // [{ name, price, qty }, ...]

    const listEl     = document.getElementById(listId);
    const countEl    = document.getElementById(countId);
    const totalEl    = document.getElementById(totalId);
    const itemsInput = document.getElementById(itemsInputId);
    const submitBtn  = document.getElementById(submitBtnId);
    const clearBtn   = document.getElementById(clearBtnId);

    // Nothing to do if the section isn't rendered (no active booking)
    if (!listEl) return;

    function syncHiddenInput() {
      if (itemsInput) {
        itemsInput.value = JSON.stringify(
          cart.map(i => ({ name: i.name, qty: i.qty, price: i.price }))
        );
      }
    }

    function render() {
      listEl.innerHTML = '';

      if (cart.length === 0) {
        listEl.innerHTML = '<li class="cart-empty-msg">No items added yet.</li>';
        if (submitBtn) submitBtn.disabled = true;
        if (countEl)   countEl.textContent = '0';
        if (totalEl)   totalEl.textContent = 'ETB 0.00';
        syncHiddenInput();
        return;
      }

      let grandTotal = 0;

      cart.forEach((item, idx) => {
        const lineTotal = item.price * item.qty;
        grandTotal += lineTotal;

        const li = document.createElement('li');
        li.className = 'cart-row';
        li.innerHTML = `
          <span class="cart-row-name">${escHtml(item.name)}</span>
          <button class="cart-qty-btn" data-idx="${idx}" data-op="dec" type="button">−</button>
          <span class="cart-qty-val">${item.qty}</span>
          <button class="cart-qty-btn" data-idx="${idx}" data-op="inc" type="button">+</button>
          <span class="cart-row-price">ETB ${lineTotal.toFixed(2)}</span>
          <button class="cart-remove-btn" data-idx="${idx}" type="button" title="Remove item">
            <i class="fas fa-trash-alt"></i>
          </button>
        `;
        listEl.appendChild(li);
      });

      // Qty buttons
      listEl.querySelectorAll('.cart-qty-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const i = parseInt(btn.dataset.idx);
          if (btn.dataset.op === 'inc') {
            cart[i].qty++;
          } else {
            cart[i].qty--;
            if (cart[i].qty <= 0) cart.splice(i, 1);
          }
          render();
        });
      });

      // Remove buttons
      listEl.querySelectorAll('.cart-remove-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          cart.splice(parseInt(btn.dataset.idx), 1);
          render();
        });
      });

      // Update summary
      const totalCount = cart.reduce((s, i) => s + i.qty, 0);
      if (countEl)   countEl.textContent = totalCount;
      if (totalEl)   totalEl.textContent = 'ETB ' + grandTotal.toFixed(2);
      if (submitBtn) submitBtn.disabled  = false;
      syncHiddenInput();
    }

    // "Add" buttons on menu/service cards
    document.querySelectorAll(addBtnSel).forEach(btn => {
      btn.addEventListener('click', () => {
        const name  = btn.dataset.name;
        const price = parseFloat(btn.dataset.price) || 0;
        const existing = cart.find(i => i.name === name);
        if (existing) {
          existing.qty++;
        } else {
          cart.push({ name, price, qty: 1 });
        }
        render();
        // Visual feedback on the button
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-check"></i>';
        btn.style.background = '#10B981';
        setTimeout(() => {
          btn.innerHTML = orig;
          btn.style.background = '';
        }, 700);
      });
    });

    // Clear button
    clearBtn?.addEventListener('click', () => {
      if (cart.length === 0) return;
      if (confirm('Clear all items from the cart?')) {
        cart = [];
        render();
      }
    });

    // Guard: prevent submitting empty cart (double-check on form submit)
    const form = submitBtn?.closest('form');
    form?.addEventListener('submit', e => {
      syncHiddenInput();
      if (cart.length === 0) {
        e.preventDefault();
        alert('Your cart is empty. Please add at least one item before submitting.');
      }
    });

    render(); // initial empty state
  }

  // ── Initialise Food Cart ──────────────────────────────
  makeCart({
    addBtnSel:    '.btn-add-cart',
    listId:       'foodCartList',
    countId:      'food-cart-count',
    totalId:      'foodCartTotal',
    itemsInputId: 'foodOrderItems',
    submitBtnId:  'foodOrderBtn',
    clearBtnId:   'clearFoodCart',
  });

  // ── Initialise Room Service Cart ──────────────────────
  makeCart({
    addBtnSel:    '.btn-add-rs',
    listId:       'rsCartList',
    countId:      'rs-cart-count',
    totalId:      'rsCartTotal',
    itemsInputId: 'rsOrderItems',
    submitBtnId:  'rsOrderBtn',
    clearBtnId:   'clearRsCart',
  });

  // ══════════════════════════════════════════════════════
  //  NOTIFICATIONS — mark single as read (AJAX)
  // ══════════════════════════════════════════════════════
  document.querySelectorAll('.notif-mark-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id   = btn.dataset.id;
      const item = btn.closest('.notif-item');
      const fd   = new FormData();
      fd.append('mark_read', '1');
      fd.append('notif_id', id);
      fetch('customer.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
          if (data.ok) {
            item.classList.replace('notif-unread', 'notif-read');
            btn.outerHTML = '<span class="notif-read-tick" title="Read"><i class="fas fa-check-double"></i></span>';
            adjustBadge(-1);
          }
        })
        .catch(() => {}); // silent fail — page reload will show correct state
    });
  });

  function adjustBadge(delta) {
    document.querySelectorAll('.notif-badge, .topnav-notif-dot').forEach(b => {
      const next = (parseInt(b.textContent) || 0) + delta;
      if (next <= 0) b.remove();
      else b.textContent = next;
    });
  }

  // ══════════════════════════════════════════════════════
  //  UTILITY — HTML escape for dynamic content
  // ══════════════════════════════════════════════════════
  function escHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

});
