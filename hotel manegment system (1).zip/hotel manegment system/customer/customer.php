<?php
require_once '../connection.php';
requireRole('customer', '../login.php');
$user = currentUser();

$success = $error = '';

// ── AJAX: Mark single notification as read ────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_read'])) {
    $nid = intval($_POST['notif_id']);
    $conn->query("UPDATE notifications SET is_read=1 WHERE id=$nid AND user_id={$user['id']}");
    echo json_encode(['ok' => true]);
    exit;
}

// ── Mark ALL notifications as read ───────────────────────
if (isset($_GET['mark_all_read'])) {
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_id={$user['id']}");
    header('Location: customer.php#notifications');
    exit;
}

// ── Book a Room ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_room'])) {
    $room_id   = intval($_POST['room_id']);
    $check_in  = escape($conn, $_POST['check_in']);
    $check_out = escape($conn, $_POST['check_out']);
    $guests    = intval($_POST['guests']);
    $special   = escape($conn, $_POST['special_request'] ?? '');

    if (!$room_id || !$check_in || !$check_out) {
        $error = 'Please fill in all required fields.';
    } elseif ($check_out <= $check_in) {
        $error = 'Check-out date must be after check-in date.';
    } else {
        $room = $conn->query("SELECT * FROM rooms WHERE id=$room_id AND status='available'")->fetch_assoc();
        if (!$room) {
            $error = 'Selected room is not available. Please choose another.';
        } else {
            $days  = (strtotime($check_out) - strtotime($check_in)) / 86400;
            $total = $days * $room['price'];
            $stmt  = $conn->prepare(
                "INSERT INTO bookings (user_id,room_id,check_in,check_out,guests,total_price,special_request,status)
                 VALUES (?,?,?,?,?,?,?,'pending')"
            );
            $stmt->bind_param("iissids", $user['id'], $room_id, $check_in, $check_out, $guests, $total, $special);
            if ($stmt->execute()) {
                $newBookingId = $conn->insert_id;
                $conn->query("UPDATE rooms SET status='booked' WHERE id=$room_id");
                $safeMsg = $conn->real_escape_string(
                    "📋 Booking Received: Your booking #$newBookingId for Room {$room['room_no']} " .
                    "(Check-in: $check_in — Check-out: $check_out) has been submitted and is pending confirmation. " .
                    "We will notify you once it is confirmed."
                );
                $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ({$user['id']},'$safeMsg',0)");
                $success = "Booking submitted! Total: ETB " . number_format($total, 2) .
                           ". You will receive a confirmation notification shortly.";
            } else {
                $error = 'Booking failed. Please try again.';
            }
            $stmt->close();
        }
    }
}

// ── Cancel a Booking ──────────────────────────────────────
if (isset($_GET['cancel']) && is_numeric($_GET['cancel'])) {
    $bid = intval($_GET['cancel']);
    $b   = $conn->query(
        "SELECT b.*, r.room_no FROM bookings b
         JOIN rooms r ON r.id=b.room_id
         WHERE b.id=$bid AND b.user_id={$user['id']}"
    )->fetch_assoc();
    if ($b && in_array($b['status'], ['pending','confirmed'])) {
        $conn->query("UPDATE bookings SET status='cancelled' WHERE id=$bid");
        $conn->query("UPDATE rooms SET status='available' WHERE id={$b['room_id']}");
        $safeMsg = $conn->real_escape_string(
            "❌ Booking Cancelled: Your booking #$bid for Room {$b['room_no']} " .
            "(Check-in: {$b['check_in']}) has been cancelled as requested. " .
            "Contact reception if you need assistance."
        );
        $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ({$user['id']},'$safeMsg',0)");
        $success = 'Booking cancelled successfully.';
    } else {
        $error = 'Cannot cancel this booking.';
    }
}

// ── Customer Self-Service Payment ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_booking'])) {
    $bid    = intval($_POST['pay_bid']);
    $method = escape($conn, $_POST['pay_method'] ?? 'card');
    $b = $conn->query(
        "SELECT b.*, r.room_no FROM bookings b
         JOIN rooms r ON r.id=b.room_id
         WHERE b.id=$bid AND b.user_id={$user['id']}
         AND b.status IN ('pending','confirmed') LIMIT 1"
    )->fetch_assoc();
    if ($b) {
        // Check if already paid
        $alreadyPaid = $conn->query(
            "SELECT COUNT(*) c FROM payments WHERE booking_id=$bid AND status='paid'"
        )->fetch_assoc()['c'];
        if ($alreadyPaid > 0) {
            $error = 'This booking has already been paid.';
        } else {
            $amount = floatval($b['total_price']);
            $conn->query(
                "INSERT INTO payments (booking_id, amount, method, status, paid_at)
                 VALUES ($bid, $amount, '$method', 'paid', NOW())"
            );
            $safeMsg = $conn->real_escape_string(
                "💳 Payment Confirmed: ETB " . number_format($amount, 2) .
                " received for Booking #{$bid} (Room {$b['room_no']}) via " . ucfirst(str_replace('_',' ',$method)) . "."
            );
            $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ({$user['id']},'$safeMsg',0)");
            $success = "Payment of ETB " . number_format($amount, 2) . " confirmed for Booking #$bid.";
        }
    } else {
        $error = 'Booking not found or not eligible for payment.';
    }
}

// ── Place Food Order or Room Service Request ──────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $order_type = ($_POST['order_type'] ?? '') === 'room_service' ? 'room_service' : 'food';
    $booking_id = intval($_POST['booking_id'] ?? 0);
    $notes      = escape($conn, $_POST['order_notes'] ?? '');
    $items_raw  = trim($_POST['order_items'] ?? '[]');

    // ── Decode cart JSON ──────────────────────────────────
    $items = json_decode($items_raw, true);

    if (!is_array($items) || count($items) === 0) {
        $error = 'Your cart is empty. Please add items before placing an order.';

    } elseif ($booking_id <= 0) {
        // No booking_id in form — customer has no booking at all
        $error = 'You need a booking to place an order. Please book a room first.';

    } else {
        // ── Verify booking belongs to this user (any non-cancelled status) ──
        $bCheck = $conn->query(
            "SELECT b.id, b.status, r.room_no
             FROM bookings b JOIN rooms r ON r.id=b.room_id
             WHERE b.id=$booking_id AND b.user_id={$user['id']}
             AND b.status NOT IN ('cancelled','checked_out')"
        )->fetch_assoc();

        if (!$bCheck) {
            $error = 'Booking not found or no longer active. Please refresh the page.';
        } else {
            // ── Sanitise items ────────────────────────────
            $total      = 0;
            $cleanItems = [];
            foreach ($items as $item) {
                $name  = trim(htmlspecialchars(strip_tags($item['name'] ?? ''), ENT_QUOTES));
                $price = max(0, floatval($item['price'] ?? 0));
                $qty   = max(1, intval($item['qty']   ?? 1));
                if ($name !== '') {
                    $cleanItems[] = ['name' => $name, 'qty' => $qty, 'price' => $price];
                    $total += $price * $qty;
                }
            }

            if (empty($cleanItems)) {
                $error = 'No valid items found in cart. Please add items and try again.';
            } else {
                // ── Check service_orders table exists ─────
                $tableCheck = $conn->query("SHOW TABLES LIKE 'service_orders'");
                if (!$tableCheck || $tableCheck->num_rows === 0) {
                    // Auto-create the table if missing
                    $conn->query("
                        CREATE TABLE IF NOT EXISTS service_orders (
                          id           INT AUTO_INCREMENT PRIMARY KEY,
                          user_id      INT NOT NULL,
                          booking_id   INT DEFAULT NULL,
                          order_type   ENUM('food','room_service') NOT NULL,
                          items        TEXT NOT NULL,
                          total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
                          notes        TEXT DEFAULT NULL,
                          status       ENUM('pending','preparing','delivered','cancelled') DEFAULT 'pending',
                          created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
                          FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
                          FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    ");
                }

                // ── Insert order ──────────────────────────
                $safeItems = $conn->real_escape_string(json_encode($cleanItems));
                $result = $conn->query(
                    "INSERT INTO service_orders
                     (user_id, booking_id, order_type, items, total_amount, notes, status)
                     VALUES (
                       {$user['id']},
                       $booking_id,
                       '$order_type',
                       '$safeItems',
                       $total,
                       '$notes',
                       'pending'
                     )"
                );

                if ($result) {
                    $orderId   = $conn->insert_id;
                    $typeLabel = $order_type === 'food' ? 'Food Order' : 'Room Service Request';
                    $emoji     = $order_type === 'food' ? '🍽️' : '🛎️';
                    $roomNo    = htmlspecialchars($bCheck['room_no']);
                    $safeMsg   = $conn->real_escape_string(
                        "$emoji $typeLabel #$orderId for Room $roomNo received! " .
                        ($total > 0 ? "Total: ETB " . number_format($total, 2) . ". " : "") .
                        "We will attend to your request shortly."
                    );
                    $conn->query(
                        "INSERT INTO notifications (user_id, message, is_read)
                         VALUES ({$user['id']}, '$safeMsg', 0)"
                    );
                    $success = "✅ $typeLabel placed successfully! Order #$orderId" .
                               ($total > 0 ? " — ETB " . number_format($total, 2) : " (Complimentary)") .
                               ". Estimated delivery: 20–30 minutes.";
                } else {
                    $error = 'Order could not be saved: ' . $conn->error .
                             '. Please try again or contact reception.';
                }
            }
        }
    }
}

// ── Cancel a Service Order ────────────────────────────────
if (isset($_GET['cancel_order']) && is_numeric($_GET['cancel_order'])) {
    $oid = intval($_GET['cancel_order']);
    $o   = $conn->query(
        "SELECT * FROM service_orders WHERE id=$oid AND user_id={$user['id']}"
    )->fetch_assoc();
    if ($o && $o['status'] === 'pending') {
        $conn->query("UPDATE service_orders SET status='cancelled' WHERE id=$oid");
        $success = "Order #$oid has been cancelled.";
    } else {
        $error = 'Cannot cancel this order — it may already be preparing or delivered.';
    }
}

// ════════════════════════════════════════════════════════
//  DATA QUERIES
// ════════════════════════════════════════════════════════

// Available rooms for booking
$availRooms = $conn->query(
    "SELECT * FROM rooms WHERE status='available' ORDER BY type, price"
);

// Customer's bookings
$myBookings = $conn->query(
    "SELECT b.*, r.room_no, r.type, r.price
     FROM bookings b JOIN rooms r ON r.id=b.room_id
     WHERE b.user_id={$user['id']}
     ORDER BY b.created_at DESC"
);
$totalSpent = $conn->query(
    "SELECT COALESCE(SUM(total_price),0) t FROM bookings
     WHERE user_id={$user['id']} AND status NOT IN ('cancelled')"
)->fetch_assoc()['t'];
$totalStays = $conn->query(
    "SELECT COUNT(*) c FROM bookings WHERE user_id={$user['id']} AND status='checked_out'"
)->fetch_assoc()['c'];

// Notifications
$notifications = $conn->query(
    "SELECT * FROM notifications WHERE user_id={$user['id']} ORDER BY created_at DESC LIMIT 50"
);
$unreadCount = $conn->query(
    "SELECT COUNT(*) c FROM notifications WHERE user_id={$user['id']} AND is_read=0"
)->fetch_assoc()['c'];

// Active booking — any non-cancelled, non-checked_out booking
// Allows ordering even for pending/confirmed bookings (not just checked_in)
$activeBooking = $conn->query(
    "SELECT b.id, b.status, r.room_no
     FROM bookings b JOIN rooms r ON r.id=b.room_id
     WHERE b.user_id={$user['id']}
     AND b.status NOT IN ('cancelled','checked_out')
     ORDER BY FIELD(b.status,'checked_in','confirmed','pending') ASC
     LIMIT 1"
)->fetch_assoc();

// Food menu — auto-create table if missing, then load
$conn->query("
    CREATE TABLE IF NOT EXISTS food_menu (
      id           INT           AUTO_INCREMENT PRIMARY KEY,
      name         VARCHAR(100)  NOT NULL,
      category     ENUM('breakfast','lunch','dinner','snacks','beverages','desserts') NOT NULL,
      description  VARCHAR(255)  DEFAULT NULL,
      price        DECIMAL(10,2) NOT NULL,
      is_available TINYINT(1)    DEFAULT 1,
      created_at   DATETIME      DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Seed default menu if table is empty
$menuCount = $conn->query("SELECT COUNT(*) c FROM food_menu")->fetch_assoc()['c'];
if ($menuCount == 0) {
    $conn->query("INSERT INTO food_menu (name,category,description,price) VALUES
        ('Full English Breakfast','breakfast','Eggs, bacon, sausage, toast, beans & grilled tomato',120.00),
        ('Continental Breakfast','breakfast','Croissant, jam, butter, fresh juice & coffee',85.00),
        ('Pancakes & Maple Syrup','breakfast','Stack of 3 fluffy pancakes with maple syrup & berries',75.00),
        ('Avocado Toast','breakfast','Sourdough toast with smashed avocado & poached egg',90.00),
        ('Club Sandwich','lunch','Triple-decker with chicken, bacon, lettuce & tomato',110.00),
        ('Caesar Salad','lunch','Romaine, croutons, parmesan & Caesar dressing',95.00),
        ('Grilled Chicken Wrap','lunch','Grilled chicken, veggies & garlic sauce in a tortilla',105.00),
        ('Pasta Carbonara','lunch','Spaghetti with creamy egg sauce, pancetta & parmesan',130.00),
        ('Grilled Salmon','dinner','Atlantic salmon fillet with lemon butter & vegetables',220.00),
        ('Beef Tenderloin','dinner','200g tenderloin with mashed potato & red wine jus',280.00),
        ('Vegetable Curry','dinner','Seasonal vegetables in aromatic curry sauce with rice',150.00),
        ('Lamb Chops','dinner','Herb-crusted lamb chops with roasted potatoes',260.00),
        ('French Fries','snacks','Crispy golden fries with ketchup & mayo',55.00),
        ('Chicken Wings (6 pcs)','snacks','Spicy buffalo wings with blue cheese dip',95.00),
        ('Cheese Platter','snacks','Selection of 4 cheeses with crackers & grapes',120.00),
        ('Fresh Orange Juice','beverages','Freshly squeezed orange juice (300ml)',45.00),
        ('Mineral Water','beverages','Still or sparkling mineral water (500ml)',25.00),
        ('Ethiopian Coffee','beverages','Traditional Ethiopian coffee ceremony (2 cups)',60.00),
        ('Soft Drink (Can)','beverages','Coca-Cola, Pepsi, Sprite or Fanta',30.00),
        ('Chocolate Lava Cake','desserts','Warm chocolate cake with vanilla ice cream',85.00),
        ('Tiramisu','desserts','Classic Italian tiramisu with espresso & mascarpone',80.00),
        ('Fruit Salad','desserts','Seasonal fresh fruit salad with honey & mint',65.00)
    ");
}

$foodMenuRows = $conn->query(
    "SELECT * FROM food_menu WHERE is_available=1 ORDER BY category, name"
);
$cats     = ['breakfast','lunch','dinner','snacks','beverages','desserts'];
$catIcons = [
    'breakfast' => 'fa-sun',
    'lunch'     => 'fa-cloud-sun',
    'dinner'    => 'fa-moon',
    'snacks'    => 'fa-cookie-bite',
    'beverages' => 'fa-glass-water',
    'desserts'  => 'fa-ice-cream',
];
$menuByCat = [];
if ($foodMenuRows) {
    while ($m = $foodMenuRows->fetch_assoc()) {
        $menuByCat[$m['category']][] = $m;
    }
}

// Room service items (fixed list — no DB table needed)
$roomServiceItems = [
    ['name' => 'Extra Towels',         'price' => 0,   'icon' => 'fa-scroll'],
    ['name' => 'Extra Pillows',        'price' => 0,   'icon' => 'fa-bed'],
    ['name' => 'Room Cleaning',        'price' => 0,   'icon' => 'fa-broom'],
    ['name' => 'Laundry Service',      'price' => 80,  'icon' => 'fa-tshirt'],
    ['name' => 'Iron & Ironing Board', 'price' => 50,  'icon' => 'fa-fire'],
    ['name' => 'Wake-up Call',         'price' => 0,   'icon' => 'fa-bell'],
    ['name' => 'Toiletries Kit',       'price' => 0,   'icon' => 'fa-soap'],
    ['name' => 'Minibar Restock',      'price' => 150, 'icon' => 'fa-wine-bottle'],
    ['name' => 'Newspaper',            'price' => 15,  'icon' => 'fa-newspaper'],
    ['name' => 'Baby Cot',             'price' => 100, 'icon' => 'fa-baby'],
];

// My service orders
$myOrders = $conn->query(
    "SELECT * FROM service_orders WHERE user_id={$user['id']} ORDER BY created_at DESC LIMIT 30"
);

// Active orders count for stat card
$pendingOrders = $conn->query(
    "SELECT COUNT(*) c FROM service_orders
     WHERE user_id={$user['id']} AND status IN ('pending','preparing')"
)->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Customer Panel — Grand Lake Hotel</title>
  <link rel="stylesheet" href="customer.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<!-- ══════════════════════════════════════════════════════
     SIDEBAR
══════════════════════════════════════════════════════ -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div>
      <div class="brand-name">Grand Lake Hotel</div>
      <div class="brand-role">Customer Portal</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-user"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Booking</div>
    <a href="#book"><i class="fas fa-plus-circle"></i> Book a Room</a>
    <a href="#mybookings"><i class="fas fa-calendar-check"></i> My Bookings</a>
    <div class="nav-section-label">Services</div>
    <a href="#food-order"><i class="fas fa-utensils"></i> Order Food</a>
    <a href="#room-service"><i class="fas fa-concierge-bell"></i> Room Service</a>
    <a href="#my-orders"><i class="fas fa-receipt"></i> My Orders
      <?php if ($pendingOrders > 0): ?>
        <span class="notif-badge"><?= $pendingOrders ?></span>
      <?php endif; ?>
    </a>
    <div class="nav-section-label">Account</div>
    <a href="#notifications"><i class="fas fa-bell"></i> Notifications
      <?php if ($unreadCount > 0): ?><span class="notif-badge"><?= $unreadCount ?></span><?php endif; ?>
    </a>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> My Profile</a>
    <a href="../index.html"><i class="fas fa-home"></i> Hotel Home</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<!-- ══════════════════════════════════════════════════════
     MAIN CONTENT
══════════════════════════════════════════════════════ -->
<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Customer Panel</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / My Account</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="#notifications" class="topnav-icon" title="Notifications" style="position:relative;">
        <i class="fas fa-bell"></i>
        <?php if ($unreadCount > 0): ?>
          <span class="topnav-notif-dot"><?= $unreadCount ?></span>
        <?php endif; ?>
      </a>
      <a href="../profile.php" class="topnav-icon"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">

    <!-- Alerts -->
    <?php if ($success): ?>
      <div class="alert alert-success" data-dismiss>
        <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
      </div>
    <?php endif; ?>
    <?php if ($error): ?>
      <div class="alert alert-error" data-dismiss>
        <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <!-- ── Stats ──────────────────────────────────────────── -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-calendar-check"></i></div>
        <div class="stat-info">
          <div class="stat-value"><?= $myBookings->num_rows ?></div>
          <div class="stat-label">Total Bookings</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
        <div class="stat-info">
          <div class="stat-value"><?= $totalStays ?></div>
          <div class="stat-label">Completed Stays</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon purple"><i class="fas fa-money-bill"></i></div>
        <div class="stat-info">
          <div class="stat-value">ETB <?= number_format($totalSpent, 0) ?></div>
          <div class="stat-label">Total Spent</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon <?= $unreadCount > 0 ? 'red' : 'teal' ?>">
          <i class="fas fa-bell"></i>
        </div>
        <div class="stat-info">
          <div class="stat-value"><?= $unreadCount ?></div>
          <div class="stat-label">Unread Notifications</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon <?= $pendingOrders > 0 ? 'yellow' : 'teal' ?>">
          <i class="fas fa-receipt"></i>
        </div>
        <div class="stat-info">
          <div class="stat-value"><?= $pendingOrders ?></div>
          <div class="stat-label">Active Orders</div>
        </div>
      </div>
      <?php if ($activeBooking): ?>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-door-open"></i></div>
        <div class="stat-info">
          <div class="stat-value">Room <?= htmlspecialchars($activeBooking['room_no']) ?></div>
          <div class="stat-label"><?= ucfirst(str_replace('_',' ',$activeBooking['status'])) ?></div>
        </div>
      </div>
      <?php endif; ?>
    </div>

    <!-- ════════════════════════════════════════════════════
         SECTION 1 — BOOK A ROOM
    ════════════════════════════════════════════════════ -->
    <div class="card" id="book">
      <div class="card-header">
        <h3><i class="fas fa-plus-circle"></i> Book a Room</h3>
      </div>
      <div class="card-body">
        <form method="POST">

          <!-- Step 1: Select Room -->
          <div class="order-step-label"><span class="step-num">1</span> Select a Room</div>
          <?php if ($availRooms->num_rows === 0): ?>
            <p style="color:var(--gray);padding:1rem 0;">No rooms available at the moment. Please check back later.</p>
          <?php else: ?>
          <div class="room-cards-grid">
            <?php while ($r = $availRooms->fetch_assoc()): ?>
              <div class="room-select-card" data-room-id="<?= $r['id'] ?>" data-price="<?= $r['price'] ?>">
                <div class="room-card-top">
                  <span class="badge badge-available">Available</span>
                  <span class="room-floor">Floor <?= $r['floor'] ?></span>
                </div>
                <h4>Room <?= htmlspecialchars($r['room_no']) ?></h4>
                <p class="room-meta"><?= ucfirst($r['type']) ?> &middot; <?= $r['capacity'] ?> guest<?= $r['capacity'] > 1 ? 's' : '' ?></p>
                <div class="price">ETB <?= number_format($r['price'], 2) ?>/night</div>
                <p class="room-desc"><?= htmlspecialchars(substr($r['description'] ?? '', 0, 70)) ?>...</p>
              </div>
            <?php endwhile; ?>
          </div>
          <?php endif; ?>
          <input type="hidden" name="room_id" id="room_id" required />
          <input type="hidden" id="room_price" value="0" />

          <!-- Step 2: Dates & Guests -->
          <div class="order-step-label" style="margin-top:1.5rem;"><span class="step-num">2</span> Choose Dates &amp; Guests</div>
          <div class="form-grid-2">
            <div class="form-group">
              <label><i class="fas fa-calendar-check"></i> Check-in Date</label>
              <input type="date" id="check_in" name="check_in" required />
            </div>
            <div class="form-group">
              <label><i class="fas fa-calendar-times"></i> Check-out Date</label>
              <input type="date" id="check_out" name="check_out" required />
            </div>
            <div class="form-group">
              <label><i class="fas fa-users"></i> Number of Guests</label>
              <input type="number" name="guests" min="1" max="6" value="1" required />
            </div>
            <div class="form-group">
              <label><i class="fas fa-info-circle"></i> Booking Summary</label>
              <div class="booking-summary-box">
                Duration: <strong id="nights_display">—</strong><br>
                Estimated Total: <strong id="total_display">—</strong>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label><i class="fas fa-comment-dots"></i> Special Requests <span style="font-weight:400;color:var(--gray)">(optional)</span></label>
            <textarea name="special_request" rows="2" placeholder="e.g. early check-in, extra pillows, ground floor…"></textarea>
          </div>
          <button type="submit" name="book_room" class="btn btn-primary-d">
            <i class="fas fa-calendar-plus"></i> Confirm Booking
          </button>
        </form>
      </div>
    </div>

    <!-- ════════════════════════════════════════════════════
         SECTION 2 — MY BOOKINGS
    ════════════════════════════════════════════════════ -->
    <div class="card" id="mybookings">
      <div class="card-header">
        <h3><i class="fas fa-history"></i> My Bookings</h3>
      </div>
      <div class="card-body">
        <?php if ($myBookings->num_rows === 0): ?>
          <div class="notif-empty">
            <i class="fas fa-calendar-times"></i>
            <p>No bookings yet. Use the form above to book your first room!</p>
          </div>
        <?php else: ?>
          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  <th>#</th><th>Room</th><th>Check-in</th><th>Check-out</th>
                  <th>Guests</th><th>Total (ETB)</th><th>Status</th><th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $myBookings->data_seek(0); while ($b = $myBookings->fetch_assoc()): ?>
                  <tr>
                    <td><?= $b['id'] ?></td>
                    <td><?= htmlspecialchars($b['room_no']) ?> <small style="color:var(--gray)">(<?= ucfirst($b['type']) ?>)</small></td>
                    <td><?= $b['check_in'] ?></td>
                    <td><?= $b['check_out'] ?></td>
                    <td><?= $b['guests'] ?></td>
                    <td><?= number_format($b['total_price'], 2) ?></td>
                    <td>
                      <span class="badge badge-<?= $b['status'] ?>">
                        <?= ucfirst(str_replace('_', ' ', $b['status'])) ?>
                      </span>
                    </td>
                    <td>
                      <?php if (in_array($b['status'], ['pending','confirmed'])): ?>
                        <a href="?cancel=<?= $b['id'] ?>"
                           class="btn btn-danger btn-sm"
                           data-confirm="Cancel booking #<?= $b['id'] ?>?">
                          <i class="fas fa-times"></i> Cancel
                        </a>
                        <?php
                        // Check if already paid
                        $isPaid = $conn->query("SELECT COUNT(*) c FROM payments WHERE booking_id={$b['id']} AND status='paid'")->fetch_assoc()['c'];
                        if (!$isPaid): ?>
                        <button class="btn btn-success btn-sm"
                          onclick="openPayModal(<?= $b['id'] ?>, <?= $b['total_price'] ?>)">
                          <i class="fas fa-credit-card"></i> Pay
                        </button>
                        <?php else: ?>
                        <span style="color:var(--success);font-size:.8rem;"><i class="fas fa-check-circle"></i> Paid</span>
                        <?php endif; ?>
                      <?php else: ?>
                        <span style="color:var(--gray);font-size:.8rem;">—</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- ════════════════════════════════════════════════════
         SECTION 3 — ORDER FOOD
    ════════════════════════════════════════════════════ -->
    <div class="card" id="food-order">
      <div class="card-header">
        <h3><i class="fas fa-utensils"></i> Order Food</h3>
        <?php if ($activeBooking): ?>
          <span class="order-room-badge">
            <i class="fas fa-door-open"></i> Room <?= htmlspecialchars($activeBooking['room_no']) ?>
          </span>
        <?php endif; ?>
      </div>
      <div class="card-body">

        <?php if (!$activeBooking): ?>
          <!-- No active booking — show friendly message -->
          <div class="order-no-booking">
            <i class="fas fa-info-circle"></i>
            <div>
              <strong>No booking found.</strong><br>
              You need at least a pending booking to order food or request room service.
              <a href="#book" style="color:#92400E;font-weight:600;">Book a room above</a> to get started.
            </div>
          </div>

        <?php else: ?>

          <!-- Category Tabs -->
          <div class="menu-tabs" id="menuTabs">
            <?php foreach ($cats as $i => $cat): ?>
              <button class="menu-tab <?= $i === 0 ? 'active' : '' ?>" data-cat="<?= $cat ?>">
                <i class="fas <?= $catIcons[$cat] ?>"></i> <?= ucfirst($cat) ?>
              </button>
            <?php endforeach; ?>
          </div>

          <!-- Menu Grids (one per category) -->
          <?php foreach ($cats as $i => $cat): ?>
            <div class="menu-grid" id="cat-<?= $cat ?>" <?= $i > 0 ? 'style="display:none"' : '' ?>>
              <?php if (empty($menuByCat[$cat])): ?>
                <p style="color:var(--gray);padding:1rem 0;grid-column:1/-1;">
                  No items available in this category right now.
                </p>
              <?php else: ?>
                <?php foreach ($menuByCat[$cat] as $item): ?>
                  <div class="menu-item-card">
                    <div class="menu-item-icon">
                      <i class="fas <?= $catIcons[$cat] ?>"></i>
                    </div>
                    <div class="menu-item-info">
                      <h4><?= htmlspecialchars($item['name']) ?></h4>
                      <p><?= htmlspecialchars($item['description'] ?? '') ?></p>
                      <span class="menu-price">ETB <?= number_format($item['price'], 2) ?></span>
                    </div>
                    <button class="btn-add-cart"
                            data-name="<?= htmlspecialchars($item['name'], ENT_QUOTES) ?>"
                            data-price="<?= $item['price'] ?>"
                            type="button"
                            title="Add to cart">
                      <i class="fas fa-plus"></i>
                    </button>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>

          <!-- Food Cart -->
          <div class="order-cart" id="foodCart">
            <div class="cart-header">
              <h4>
                <i class="fas fa-shopping-cart"></i> Your Cart
                <span id="food-cart-count" class="cart-count">0</span>
              </h4>
              <button class="btn-clear-cart" id="clearFoodCart" type="button">
                <i class="fas fa-trash"></i> Clear
              </button>
            </div>
            <ul class="cart-list" id="foodCartList">
              <li class="cart-empty-msg">No items added yet. Browse the menu above.</li>
            </ul>
            <div class="cart-total">
              Order Total: <strong id="foodCartTotal">ETB 0.00</strong>
            </div>
            <form method="POST" id="foodOrderForm">
              <input type="hidden" name="place_order"  value="1" />
              <input type="hidden" name="order_type"   value="food" />
              <input type="hidden" name="booking_id"   value="<?= (int)$activeBooking['id'] ?>" />
              <input type="hidden" name="order_items"  id="foodOrderItems" value="[]" />
              <div class="form-group" style="margin-top:.85rem;">
                <label><i class="fas fa-sticky-note"></i> Delivery Notes <span style="font-weight:400;color:var(--gray)">(optional)</span></label>
                <input type="text" name="order_notes"
                       placeholder="e.g. No onions, deliver at 7 PM, allergic to nuts…" />
              </div>
              <button type="submit" class="btn btn-primary-d" id="foodOrderBtn" disabled>
                <i class="fas fa-paper-plane"></i> Place Food Order
              </button>
            </form>
          </div>

        <?php endif; ?>
      </div>
    </div>

    <!-- ════════════════════════════════════════════════════
         SECTION 4 — ROOM SERVICE
    ════════════════════════════════════════════════════ -->
    <div class="card" id="room-service">
      <div class="card-header">
        <h3><i class="fas fa-concierge-bell"></i> Room Service</h3>
        <?php if ($activeBooking): ?>
          <span class="order-room-badge">
            <i class="fas fa-door-open"></i> Room <?= htmlspecialchars($activeBooking['room_no']) ?>
          </span>
        <?php endif; ?>
      </div>
      <div class="card-body">

        <?php if (!$activeBooking): ?>
          <div class="order-no-booking">
            <i class="fas fa-info-circle"></i>
            <div>
              <strong>No booking found.</strong><br>
              You need at least a pending booking to request room service.
              <a href="#book" style="color:#92400E;font-weight:600;">Book a room above</a> to get started.
            </div>
          </div>

        <?php else: ?>

          <p class="rs-info-note">
            <i class="fas fa-info-circle"></i>
            Items marked <strong>Complimentary</strong> are free of charge.
            Chargeable items will be added to your room bill.
          </p>

          <!-- Room Service Items Grid -->
          <div class="rs-grid">
            <?php foreach ($roomServiceItems as $rs): ?>
              <div class="rs-item-card">
                <div class="rs-icon">
                  <i class="fas <?= $rs['icon'] ?>"></i>
                </div>
                <div class="rs-info">
                  <h4><?= htmlspecialchars($rs['name']) ?></h4>
                  <span class="rs-price">
                    <?= $rs['price'] > 0
                        ? 'ETB ' . number_format($rs['price'], 2)
                        : 'Complimentary' ?>
                  </span>
                </div>
                <button class="btn-add-rs"
                        data-name="<?= htmlspecialchars($rs['name'], ENT_QUOTES) ?>"
                        data-price="<?= $rs['price'] ?>"
                        type="button"
                        title="Add to request list">
                  <i class="fas fa-plus"></i>
                </button>
              </div>
            <?php endforeach; ?>
          </div>

          <!-- Room Service Cart -->
          <div class="order-cart" id="rsCart">
            <div class="cart-header">
              <h4>
                <i class="fas fa-list-check"></i> Request List
                <span id="rs-cart-count" class="cart-count">0</span>
              </h4>
              <button class="btn-clear-cart" id="clearRsCart" type="button">
                <i class="fas fa-trash"></i> Clear
              </button>
            </div>
            <ul class="cart-list" id="rsCartList">
              <li class="cart-empty-msg">No items selected yet. Choose from the list above.</li>
            </ul>
            <div class="cart-total">
              Charges: <strong id="rsCartTotal">ETB 0.00</strong>
            </div>
            <form method="POST" id="rsOrderForm">
              <input type="hidden" name="place_order"  value="1" />
              <input type="hidden" name="order_type"   value="room_service" />
              <input type="hidden" name="booking_id"   value="<?= (int)$activeBooking['id'] ?>" />
              <input type="hidden" name="order_items"  id="rsOrderItems" value="[]" />
              <div class="form-group" style="margin-top:.85rem;">
                <label><i class="fas fa-sticky-note"></i> Additional Notes <span style="font-weight:400;color:var(--gray)">(optional)</span></label>
                <input type="text" name="order_notes"
                       placeholder="e.g. Bring towels before 9 PM, need 2 sets…" />
              </div>
              <button type="submit" class="btn btn-primary-d" id="rsOrderBtn" disabled>
                <i class="fas fa-paper-plane"></i> Submit Request
              </button>
            </form>
          </div>

        <?php endif; ?>
      </div>
    </div>

    <!-- ════════════════════════════════════════════════════
         SECTION 5 — MY ORDERS
    ════════════════════════════════════════════════════ -->
    <div class="card" id="my-orders">
      <div class="card-header">
        <h3><i class="fas fa-receipt"></i> My Orders</h3>
      </div>
      <div class="card-body">
        <?php if ($myOrders->num_rows === 0): ?>
          <div class="notif-empty">
            <i class="fas fa-receipt"></i>
            <p>No orders yet. Use the Food Order or Room Service sections above to place your first order.</p>
          </div>
        <?php else: ?>
          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Type</th>
                  <th>Items</th>
                  <th>Total (ETB)</th>
                  <th>Notes</th>
                  <th>Status</th>
                  <th>Ordered At</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($o = $myOrders->fetch_assoc()):
                  $oItems = json_decode($o['items'], true) ?? [];
                  $itemSummary = implode(', ', array_map(
                      fn($i) => ($i['qty'] ?? 1) . '× ' . ($i['name'] ?? ''),
                      $oItems
                  ));
                ?>
                <tr>
                  <td><?= $o['id'] ?></td>
                  <td>
                    <?php if ($o['order_type'] === 'food'): ?>
                      <span class="badge badge-confirmed">
                        <i class="fas fa-utensils"></i> Food
                      </span>
                    <?php else: ?>
                      <span class="badge badge-pending">
                        <i class="fas fa-concierge-bell"></i> Room Svc
                      </span>
                    <?php endif; ?>
                  </td>
                  <td style="max-width:220px;font-size:.82rem;white-space:normal;">
                    <?= htmlspecialchars($itemSummary) ?>
                  </td>
                  <td><?= number_format($o['total_amount'], 2) ?></td>
                  <td style="font-size:.82rem;"><?= htmlspecialchars($o['notes'] ?? '—') ?></td>
                  <td>
                    <?php
                      $statusMap = [
                          'pending'   => 'badge-pending',
                          'preparing' => 'badge-checked_in',
                          'delivered' => 'badge-checked_out',
                          'cancelled' => 'badge-cancelled',
                      ];
                      $cls = $statusMap[$o['status']] ?? 'badge-pending';
                    ?>
                    <span class="badge <?= $cls ?>"><?= ucfirst($o['status']) ?></span>
                  </td>
                  <td style="font-size:.8rem;white-space:nowrap;">
                    <?= date('d M Y, H:i', strtotime($o['created_at'])) ?>
                  </td>
                  <td>
                    <?php if ($o['status'] === 'pending'): ?>
                      <a href="?cancel_order=<?= $o['id'] ?>"
                         class="btn btn-danger btn-sm"
                         data-confirm="Cancel order #<?= $o['id'] ?>?">
                        <i class="fas fa-times"></i> Cancel
                      </a>
                    <?php else: ?>
                      <span style="color:var(--gray);font-size:.8rem;">—</span>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- ════════════════════════════════════════════════════
         SECTION 6 — NOTIFICATIONS
    ════════════════════════════════════════════════════ -->
    <div class="card" id="notifications">
      <div class="card-header">
        <h3>
          <i class="fas fa-bell"></i> My Notifications
          <?php if ($unreadCount > 0): ?>
            <span class="notif-badge" style="margin-left:.5rem;"><?= $unreadCount ?> unread</span>
          <?php endif; ?>
        </h3>
        <?php if ($notifications->num_rows > 0): ?>
          <a href="?mark_all_read=1" class="btn btn-outline-d btn-sm">
            <i class="fas fa-check-double"></i> Mark All Read
          </a>
        <?php endif; ?>
      </div>
      <div class="card-body">
        <?php if ($notifications->num_rows === 0): ?>
          <div class="notif-empty">
            <i class="fas fa-bell-slash"></i>
            <p>No notifications yet. You will be notified when your booking is confirmed, when you check in, and when orders are received.</p>
          </div>
        <?php else: ?>
          <ul class="notif-list">
            <?php while ($n = $notifications->fetch_assoc()): ?>
              <li class="notif-item <?= $n['is_read'] ? 'notif-read' : 'notif-unread' ?>"
                  data-id="<?= $n['id'] ?>">
                <div class="notif-icon-wrap">
                  <?php
                    $nm = $n['message'];
                    if (str_contains($nm, 'Confirmation') || str_contains($nm, 'confirmed'))
                        echo '<span class="notif-icon-circle green"><i class="fas fa-calendar-check"></i></span>';
                    elseif (str_contains($nm, 'Check-in') || str_contains($nm, 'checked in'))
                        echo '<span class="notif-icon-circle blue"><i class="fas fa-sign-in-alt"></i></span>';
                    elseif (str_contains($nm, 'Check-out') || str_contains($nm, 'checked out'))
                        echo '<span class="notif-icon-circle yellow"><i class="fas fa-sign-out-alt"></i></span>';
                    elseif (str_contains($nm, 'Cancelled') || str_contains($nm, 'cancelled'))
                        echo '<span class="notif-icon-circle red"><i class="fas fa-times-circle"></i></span>';
                    elseif (str_contains($nm, 'Order') || str_contains($nm, 'Service'))
                        echo '<span class="notif-icon-circle purple"><i class="fas fa-utensils"></i></span>';
                    else
                        echo '<span class="notif-icon-circle purple"><i class="fas fa-info-circle"></i></span>';
                  ?>
                </div>
                <div class="notif-body">
                  <p class="notif-msg"><?= htmlspecialchars($n['message']) ?></p>
                  <span class="notif-time">
                    <i class="fas fa-clock"></i>
                    <?= date('d M Y, H:i', strtotime($n['created_at'])) ?>
                  </span>
                </div>
                <?php if (!$n['is_read']): ?>
                  <button class="notif-mark-btn" data-id="<?= $n['id'] ?>" title="Mark as read">
                    <i class="fas fa-check"></i>
                  </button>
                <?php else: ?>
                  <span class="notif-read-tick" title="Read">
                    <i class="fas fa-check-double"></i>
                  </span>
                <?php endif; ?>
              </li>
            <?php endwhile; ?>
          </ul>
        <?php endif; ?>
      </div>
    </div>

  </div><!-- /page-content -->
</div><!-- /main-content -->

<script src="customer.js"></script>

<!-- ── Payment Modal ─────────────────────────────────── -->
<div class="modal-overlay" id="payModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:500;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:16px;padding:2rem;width:100%;max-width:420px;box-shadow:0 8px 40px rgba(0,0,0,.2);">
    <h3 style="color:var(--primary);margin-bottom:1.25rem;"><i class="fas fa-credit-card"></i> Pay for Booking</h3>
    <form method="POST">
      <input type="hidden" name="pay_bid" id="pay_bid" />
      <div style="background:var(--light);border-radius:10px;padding:1rem;margin-bottom:1.25rem;text-align:center;">
        <div style="font-size:.85rem;color:var(--gray);">Amount Due</div>
        <div style="font-size:1.8rem;font-weight:800;color:var(--primary);" id="pay_amount_display">ETB 0.00</div>
      </div>
      <div style="margin-bottom:1.25rem;">
        <label style="display:block;font-weight:600;margin-bottom:.4rem;font-size:.9rem;">Payment Method</label>
        <select name="pay_method" style="width:100%;padding:.7rem 1rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.95rem;">
          <option value="card">💳 Credit / Debit Card</option>
          <option value="mobile_money">📱 Mobile Money</option>
          <option value="bank_transfer">🏦 Bank Transfer</option>
          <option value="cash">💵 Cash at Reception</option>
        </select>
      </div>
      <div style="display:flex;gap:1rem;">
        <button type="submit" name="pay_booking" style="flex:1;padding:.8rem;background:var(--success);color:#fff;border:none;border-radius:var(--radius);font-weight:700;cursor:pointer;font-size:.95rem;">
          <i class="fas fa-check-circle"></i> Confirm Payment
        </button>
        <button type="button" onclick="closePayModal()" style="padding:.8rem 1.2rem;background:var(--light);border:1.5px solid var(--gray-l);border-radius:var(--radius);cursor:pointer;font-weight:600;">
          Cancel
        </button>
      </div>
    </form>
  </div>
</div>

<script>
function openPayModal(bid, amount) {
  document.getElementById('pay_bid').value = bid;
  document.getElementById('pay_amount_display').textContent = 'ETB ' + parseFloat(amount).toFixed(2);
  const m = document.getElementById('payModal');
  m.style.display = 'flex';
}
function closePayModal() {
  document.getElementById('payModal').style.display = 'none';
}
document.getElementById('payModal').addEventListener('click', function(e) {
  if (e.target === this) closePayModal();
});
</script>
</body>
</html>
