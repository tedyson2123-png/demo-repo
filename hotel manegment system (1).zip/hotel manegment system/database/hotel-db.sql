-- ============================================================
--  Grand Lake Hotel — Complete Database Schema & Seed Data
--  Database: hotel_management
--  File: hotel_db.sql  (renamed from ted.db.sql)
-- ============================================================

DROP DATABASE IF EXISTS hotel_management;
CREATE DATABASE hotel_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE hotel_management;

-- ── 1. USERS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id          INT          AUTO_INCREMENT PRIMARY KEY,
  full_name   VARCHAR(100) NOT NULL,
  email       VARCHAR(100) NOT NULL UNIQUE,
  phone       VARCHAR(20)  DEFAULT NULL,
  username    VARCHAR(50)  NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  role        ENUM('admin','customer','reception','manager','maintenance','housekeeper')
              NOT NULL DEFAULT 'customer',
  avatar      VARCHAR(255) DEFAULT NULL,
  created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- ── 2. ROOMS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rooms (
  id          INT           AUTO_INCREMENT PRIMARY KEY,
  room_no     VARCHAR(20)   NOT NULL UNIQUE,
  type        ENUM('single','double','suite','deluxe') NOT NULL,
  floor       INT           NOT NULL DEFAULT 1,
  capacity    INT           NOT NULL DEFAULT 1,
  price       DECIMAL(10,2) NOT NULL,
  description TEXT          DEFAULT NULL,
  image       VARCHAR(255)  DEFAULT NULL,
  status      ENUM('available','booked','cleaning','maintenance') DEFAULT 'available',
  created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- ── 3. BOOKINGS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookings (
  id              INT           AUTO_INCREMENT PRIMARY KEY,
  user_id         INT           NOT NULL,
  room_id         INT           NOT NULL,
  check_in        DATE          NOT NULL,
  check_out       DATE          NOT NULL,
  guests          INT           NOT NULL DEFAULT 1,
  total_price     DECIMAL(10,2) NOT NULL,
  special_request TEXT          DEFAULT NULL,
  status          ENUM('pending','confirmed','checked_in','checked_out','cancelled')
                  DEFAULT 'pending',
  created_at      DATETIME      DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

-- ── 4. PAYMENTS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
  id          INT           AUTO_INCREMENT PRIMARY KEY,
  booking_id  INT           NOT NULL,
  amount      DECIMAL(10,2) NOT NULL,
  method      ENUM('cash','card','bank_transfer','mobile_money') NOT NULL,
  status      ENUM('pending','paid','refunded') DEFAULT 'pending',
  paid_at     DATETIME      DEFAULT NULL,
  created_at  DATETIME      DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
);

-- ── 5. MAINTENANCE REQUESTS ──────────────────────────────────
CREATE TABLE IF NOT EXISTS maintenance_requests (
  id           INT  AUTO_INCREMENT PRIMARY KEY,
  room_id      INT  NOT NULL,
  reported_by  INT  NOT NULL,
  assigned_to  INT  DEFAULT NULL,
  title        VARCHAR(150) NOT NULL,
  description  TEXT         DEFAULT NULL,
  priority     ENUM('low','medium','high','urgent') DEFAULT 'medium',
  status       ENUM('open','in_progress','resolved','closed') DEFAULT 'open',
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at  DATETIME DEFAULT NULL,
  FOREIGN KEY (room_id)     REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (reported_by) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
);

-- ── 6. HOUSEKEEPING TASKS ────────────────────────────────────
CREATE TABLE IF NOT EXISTS housekeeping_tasks (
  id           INT  AUTO_INCREMENT PRIMARY KEY,
  room_id      INT  NOT NULL,
  assigned_to  INT  DEFAULT NULL,
  task_type    ENUM('cleaning','inspection','restocking','turndown') DEFAULT 'cleaning',
  notes        TEXT DEFAULT NULL,
  status       ENUM('pending','in_progress','done') DEFAULT 'pending',
  scheduled_at DATE NOT NULL,
  completed_at DATETIME DEFAULT NULL,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (room_id)     REFERENCES rooms(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
);

-- ── 7. NOTIFICATIONS ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id         INT  AUTO_INCREMENT PRIMARY KEY,
  user_id    INT  NOT NULL,
  message    TEXT NOT NULL,
  is_read    TINYINT(1) DEFAULT 0,
  created_at DATETIME   DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── 8. FOOD MENU ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS food_menu (
  id           INT           AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100)  NOT NULL,
  category     ENUM('breakfast','lunch','dinner','snacks','beverages','desserts') NOT NULL,
  description  VARCHAR(255)  DEFAULT NULL,
  price        DECIMAL(10,2) NOT NULL,
  is_available TINYINT(1)    DEFAULT 1,
  created_at   DATETIME      DEFAULT CURRENT_TIMESTAMP
);

-- ── 9. SERVICE ORDERS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS service_orders (
  id           INT  AUTO_INCREMENT PRIMARY KEY,
  user_id      INT  NOT NULL,
  booking_id   INT  DEFAULT NULL,
  order_type   ENUM('food','room_service') NOT NULL,
  items        TEXT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  notes        TEXT DEFAULT NULL,
  status       ENUM('pending','preparing','delivered','cancelled') DEFAULT 'pending',
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL
);

-- ── 10. PASSWORD RESET TOKENS ────────────────────────────────
CREATE TABLE password_reset_tokens (
  id         INT          AUTO_INCREMENT PRIMARY KEY,
  email      VARCHAR(100) NOT NULL,
  token      VARCHAR(6)   NOT NULL,
  expires_at DATETIME     NOT NULL,
  used       TINYINT(1)   DEFAULT 0,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_prt_email (email),
  INDEX idx_prt_token (token)
);

-- ── 11. SYSTEM LOGS ──────────────────────────────────────────
--  Used by: admin panel — View System Logs
CREATE TABLE system_logs (
  id         INT          AUTO_INCREMENT PRIMARY KEY,
  user_id    INT          DEFAULT NULL,
  username   VARCHAR(50)  DEFAULT NULL,
  action     VARCHAR(100) NOT NULL,
  detail     TEXT         DEFAULT NULL,
  ip_address VARCHAR(45)  DEFAULT NULL,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ── 12. SYSTEM SETTINGS ──────────────────────────────────────
--  Used by: admin panel — System Settings
CREATE TABLE system_settings (
  id          INT          AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(80)  NOT NULL UNIQUE,
  setting_val TEXT         DEFAULT NULL,
  updated_at  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Default settings
INSERT INTO system_settings (setting_key, setting_val) VALUES
('hotel_name',    'Grand Lake Hotel'),
('hotel_email',   'info@grandlakehotel.com'),
('hotel_phone',   '+251 583 20 9653'),
('hotel_address', 'Bahir Dar, Ethiopia'),
('hotel_currency','ETB'),
('checkin_time',  '14:00'),
('checkout_time', '12:00'),
('max_guests',    '10');

-- ============================================================
--  SEED DATA
-- ============================================================

INSERT INTO users (full_name, email, phone, username, password, role) VALUES
('Admin User',      'admin@hotel.com',       '+251911000001', 'admin',       MD5('admin123'),       'admin'),
('John Reception',  'reception@hotel.com',   '+251911000002', 'reception',   MD5('reception123'),   'reception'),
('Sara Manager',    'manager@hotel.com',     '+251911000003', 'manager',     MD5('manager123'),     'manager'),
('Tom Maintenance', 'maintenance@hotel.com', '+251911000004', 'maintenance', MD5('maintenance123'), 'maintenance'),
('Eva Housekeeper', 'housekeeper@hotel.com', '+251911000005', 'housekeeper', MD5('housekeeper123'), 'housekeeper'),
('Alice Customer',  'alice@example.com',     '+251911000006', 'alice',       MD5('alice123'),       'customer'),
('Bob Customer',    'bob@example.com',       '+251911000007', 'bob',         MD5('bob123'),         'customer'),
('Carol Customer',  'carol@example.com',     '+251911000008', 'carol',       MD5('carol123'),       'customer');

INSERT INTO rooms (room_no, type, floor, capacity, price, description, status) VALUES
('101','single', 1,1, 80.00,'Cozy single room with city view, free Wi-Fi, and en-suite bathroom.','available'),
('102','single', 1,1, 80.00,'Bright single room on ground floor, ideal for solo travellers.','available'),
('103','single', 1,1, 85.00,'Single room with garden view and complimentary breakfast.','available'),
('201','double', 2,2,120.00,'Spacious double room with queen bed, sitting area, and mountain view.','available'),
('202','double', 2,2,120.00,'Modern double room with twin beds and private balcony.','booked'),
('203','double', 2,2,125.00,'Double room with lake view, mini-fridge, and work desk.','available'),
('301','suite',  3,4,200.00,'Luxury suite with king bed, lounge, jacuzzi, and panoramic lake view.','available'),
('302','suite',  3,4,200.00,'Executive suite with separate living room and premium amenities.','cleaning'),
('303','suite',  3,4,220.00,'Presidential suite with private terrace, butler service, and lake view.','available'),
('401','deluxe', 4,3,160.00,'Deluxe room with king bed, work desk, and complimentary breakfast.','available'),
('402','deluxe', 4,3,160.00,'Deluxe corner room with extra space and dual-aspect windows.','maintenance'),
('403','deluxe', 4,3,175.00,'Deluxe room with private balcony, soaking tub, and city panorama.','available');

INSERT INTO bookings (user_id,room_id,check_in,check_out,guests,total_price,special_request,status) VALUES
(6,1,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 3 DAY),1,240.00,'Non-smoking room please.','confirmed'),
(7,5,DATE_SUB(CURDATE(),INTERVAL 1 DAY),DATE_ADD(CURDATE(),INTERVAL 2 DAY),2,360.00,'Extra pillows needed.','checked_in'),
(8,7,DATE_ADD(CURDATE(),INTERVAL 2 DAY),DATE_ADD(CURDATE(),INTERVAL 5 DAY),3,600.00,'Late check-in around 11 PM.','pending'),
(6,4,DATE_SUB(CURDATE(),INTERVAL 10 DAY),DATE_SUB(CURDATE(),INTERVAL 7 DAY),2,360.00,NULL,'checked_out'),
(7,10,DATE_SUB(CURDATE(),INTERVAL 20 DAY),DATE_SUB(CURDATE(),INTERVAL 18 DAY),1,320.00,NULL,'checked_out'),
(8,3,DATE_SUB(CURDATE(),INTERVAL 5 DAY),DATE_SUB(CURDATE(),INTERVAL 3 DAY),1,170.00,NULL,'cancelled'),
(6,9,DATE_ADD(CURDATE(),INTERVAL 7 DAY),DATE_ADD(CURDATE(),INTERVAL 10 DAY),2,660.00,'Anniversary — flowers in room.','confirmed'),
(7,6,DATE_SUB(CURDATE(),INTERVAL 2 DAY),CURDATE(),2,250.00,NULL,'checked_in');

INSERT INTO payments (booking_id,amount,method,status,paid_at) VALUES
(1,240.00,'card','paid',NOW()),
(2,360.00,'cash','paid',NOW()),
(4,360.00,'bank_transfer','paid',DATE_SUB(NOW(),INTERVAL 10 DAY)),
(5,320.00,'card','paid',DATE_SUB(NOW(),INTERVAL 20 DAY)),
(7,660.00,'mobile_money','paid',NOW()),
(8,250.00,'cash','paid',DATE_SUB(NOW(),INTERVAL 2 DAY));

INSERT INTO maintenance_requests (room_id,reported_by,assigned_to,title,description,priority,status) VALUES
(11,2,4,'AC not working','The air conditioning unit in room 402 is not cooling properly.','high','in_progress'),
(5,2,4,'Leaking faucet','Bathroom faucet in room 202 drips continuously.','medium','open'),
(8,4,4,'Broken wardrobe door','Wardrobe sliding door in room 302 is off its track.','low','open'),
(1,2,4,'Light bulb replacement','Bedside lamp bulb blown in room 101.','low','resolved'),
(7,2,4,'Jacuzzi jet malfunction','One of the jacuzzi jets in suite 301 is not functioning.','urgent','open');
UPDATE maintenance_requests SET resolved_at=DATE_SUB(NOW(),INTERVAL 1 DAY) WHERE status='resolved';

INSERT INTO housekeeping_tasks (room_id,assigned_to,task_type,notes,status,scheduled_at) VALUES
(8,5,'cleaning','Post-checkout deep clean required for suite 302.','in_progress',CURDATE()),
(1,5,'restocking','Replenish toiletries and towels in room 101.','pending',CURDATE()),
(5,5,'turndown','Evening turndown service for room 202 (guest checked in).','pending',CURDATE()),
(10,5,'inspection','Pre-arrival inspection for room 401.','pending',DATE_ADD(CURDATE(),INTERVAL 1 DAY)),
(4,5,'cleaning','Standard cleaning after checkout — room 201.','done',DATE_SUB(CURDATE(),INTERVAL 1 DAY));
UPDATE housekeeping_tasks SET completed_at=DATE_SUB(NOW(),INTERVAL 3 HOUR) WHERE status='done';

INSERT INTO notifications (user_id,message,is_read) VALUES
(6,'Your booking #1 has been confirmed. We look forward to welcoming you!',0),
(7,'Your booking #2 check-in is complete. Enjoy your stay!',1),
(8,'Your booking #3 is pending confirmation. We will contact you shortly.',0),
(6,'Your booking #7 has been confirmed. Happy anniversary!',0);

INSERT INTO food_menu (name,category,description,price,is_available) VALUES
('Full English Breakfast','breakfast','Eggs, bacon, sausage, toast, beans & grilled tomato',120.00,1),
('Continental Breakfast','breakfast','Croissant, jam, butter, fresh juice & coffee',85.00,1),
('Pancakes & Maple Syrup','breakfast','Stack of 3 fluffy pancakes with maple syrup & berries',75.00,1),
('Avocado Toast','breakfast','Sourdough toast with smashed avocado & poached egg',90.00,1),
('Club Sandwich','lunch','Triple-decker with chicken, bacon, lettuce & tomato',110.00,1),
('Caesar Salad','lunch','Romaine, croutons, parmesan & Caesar dressing',95.00,1),
('Grilled Chicken Wrap','lunch','Grilled chicken, veggies & garlic sauce in a tortilla',105.00,1),
('Pasta Carbonara','lunch','Spaghetti with creamy egg sauce, pancetta & parmesan',130.00,1),
('Grilled Salmon','dinner','Atlantic salmon fillet with lemon butter & vegetables',220.00,1),
('Beef Tenderloin','dinner','200g tenderloin with mashed potato & red wine jus',280.00,1),
('Vegetable Curry','dinner','Seasonal vegetables in aromatic curry sauce with rice',150.00,1),
('Lamb Chops','dinner','Herb-crusted lamb chops with roasted potatoes',260.00,1),
('French Fries','snacks','Crispy golden fries with ketchup & mayo',55.00,1),
('Chicken Wings (6 pcs)','snacks','Spicy buffalo wings with blue cheese dip',95.00,1),
('Cheese Platter','snacks','Selection of 4 cheeses with crackers & grapes',120.00,1),
('Fresh Orange Juice','beverages','Freshly squeezed orange juice (300ml)',45.00,1),
('Mineral Water','beverages','Still or sparkling mineral water (500ml)',25.00,1),
('Ethiopian Coffee','beverages','Traditional Ethiopian coffee ceremony (2 cups)',60.00,1),
('Soft Drink (Can)','beverages','Coca-Cola, Pepsi, Sprite or Fanta',30.00,1),
('Chocolate Lava Cake','desserts','Warm chocolate cake with vanilla ice cream',85.00,1),
('Tiramisu','desserts','Classic Italian tiramisu with espresso & mascarpone',80.00,1),
('Fruit Salad','desserts','Seasonal fresh fruit salad with honey & mint',65.00,1);

INSERT INTO service_orders (user_id,booking_id,order_type,items,total_amount,notes,status) VALUES
(7,2,'food','[{"name":"Club Sandwich","qty":2,"price":110.00},{"name":"Fresh Orange Juice","qty":2,"price":45.00}]',310.00,'Please deliver to room 202','delivered'),
(7,2,'room_service','[{"name":"Extra Towels","qty":2,"price":0.00},{"name":"Room Cleaning","qty":1,"price":0.00}]',0.00,'Need fresh towels urgently','delivered'),
(6,1,'food','[{"name":"Continental Breakfast","qty":1,"price":85.00},{"name":"Ethiopian Coffee","qty":1,"price":60.00}]',145.00,NULL,'pending');
