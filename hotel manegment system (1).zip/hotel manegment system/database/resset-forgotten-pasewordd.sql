-- ============================================================
--  Grand Lake Hotel — Password Reset Tokens (patch only)
--  Use this ONLY if you already imported mom.db.sql and just
--  need to add the missing table without re-importing everything.
--
--  In phpMyAdmin:
--    1. Select the "hotel_management" database on the left.
--    2. Click the "SQL" tab.
--    3. Paste this file's contents and click "Go".
-- ============================================================

USE hotel_management;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id         INT          AUTO_INCREMENT PRIMARY KEY,
  email      VARCHAR(100) NOT NULL,
  token      VARCHAR(6)   NOT NULL,
  expires_at DATETIME     NOT NULL,
  used       TINYINT(1)   DEFAULT 0,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_prt_email (email),
  INDEX idx_prt_token (token)
);
