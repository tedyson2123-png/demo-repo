<?php
// ============================================================
//  Grand Lake Hotel — Customer Model
//  models/Customer.php
// ============================================================

require_once __DIR__ . '/../connection.php';

class Customer {

    private mysqli $conn;

    public function __construct() {
        global $conn;
        $this->conn = $conn;
    }

    // ── Fetch all customers (role = 'customer') ───────────
    public function getAll(int $limit = 0): array {
        $lim = $limit > 0 ? "LIMIT $limit" : '';
        $result = $this->conn->query(
            "SELECT id, full_name, username, email, phone, created_at
             FROM users
             WHERE role = 'customer'
             ORDER BY created_at DESC $lim"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Fetch single customer by ID ───────────────────────
    public function getById(int $id): ?array {
        $result = $this->conn->query(
            "SELECT id, full_name, username, email, phone, created_at
             FROM users
             WHERE id = $id AND role = 'customer'
             LIMIT 1"
        );
        return $result ? $result->fetch_assoc() : null;
    }

    // ── Fetch customer with booking stats ─────────────────
    public function getWithStats(int $id): ?array {
        $customer = $this->getById($id);
        if (!$customer) return null;

        $stats = $this->conn->query(
            "SELECT
               COUNT(*) AS total_bookings,
               SUM(status = 'checked_out') AS completed_stays,
               SUM(status = 'cancelled')   AS cancellations,
               COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END), 0) AS total_spent
             FROM bookings
             WHERE user_id = $id"
        )->fetch_assoc();

        return array_merge($customer, $stats ?? []);
    }

    // ── Search customers ──────────────────────────────────
    public function search(string $q): array {
        $q = '%' . $this->conn->real_escape_string($q) . '%';
        $result = $this->conn->query(
            "SELECT id, full_name, username, email, phone, created_at
             FROM users
             WHERE role = 'customer'
               AND (full_name LIKE '$q' OR email LIKE '$q' OR username LIKE '$q' OR phone LIKE '$q')
             ORDER BY full_name ASC"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Count total customers ─────────────────────────────
    public function count(): int {
        $row = $this->conn->query(
            "SELECT COUNT(*) c FROM users WHERE role = 'customer'"
        )->fetch_assoc();
        return (int) $row['c'];
    }

    // ── Update customer profile ───────────────────────────
    public function update(int $id, array $data): bool {
        $full_name = $this->conn->real_escape_string($data['full_name']);
        $email     = $this->conn->real_escape_string($data['email']);
        $phone     = $this->conn->real_escape_string($data['phone'] ?? '');

        $stmt = $this->conn->prepare(
            "UPDATE users SET full_name=?, email=?, phone=? WHERE id=? AND role='customer'"
        );
        $stmt->bind_param("sssi", $full_name, $email, $phone, $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    // ── Delete customer ───────────────────────────────────
    public function delete(int $id): bool {
        return (bool) $this->conn->query(
            "DELETE FROM users WHERE id=$id AND role='customer'"
        );
    }

    // ── Get currently checked-in customers ───────────────
    public function getCheckedIn(): array {
        $result = $this->conn->query(
            "SELECT DISTINCT u.id, u.full_name, u.email, u.phone,
                    r.room_no, b.check_in, b.check_out
             FROM users u
             JOIN bookings b ON b.user_id = u.id
             JOIN rooms    r ON r.id = b.room_id
             WHERE b.status = 'checked_in'
             ORDER BY u.full_name ASC"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
}
