<?php
// ============================================================
//  Grand Lake Hotel — Booking Model
//  models/Booking.php
// ============================================================

require_once __DIR__ . '/../connection.php';

class Booking {

    private mysqli $conn;

    public function __construct() {
        global $conn;
        $this->conn = $conn;
    }

    // ── Fetch all bookings (with guest & room info) ───────
    public function getAll(string $status = '', int $limit = 0): array {
        $where = $status
            ? "WHERE b.status = '" . $this->conn->real_escape_string($status) . "'"
            : '';
        $lim = $limit > 0 ? "LIMIT $limit" : '';
        $result = $this->conn->query(
            "SELECT b.*, u.full_name, u.email, u.phone, r.room_no, r.type, r.floor, r.price
             FROM bookings b
             JOIN users u ON u.id = b.user_id
             JOIN rooms  r ON r.id = b.room_id
             $where
             ORDER BY b.created_at DESC $lim"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Fetch single booking ──────────────────────────────
    public function getById(int $id): ?array {
        $result = $this->conn->query(
            "SELECT b.*, u.full_name, u.email, u.phone, r.room_no, r.type, r.floor, r.price
             FROM bookings b
             JOIN users u ON u.id = b.user_id
             JOIN rooms  r ON r.id = b.room_id
             WHERE b.id = $id LIMIT 1"
        );
        return $result ? $result->fetch_assoc() : null;
    }

    // ── Fetch bookings for a specific user ────────────────
    public function getByUser(int $userId, int $limit = 0): array {
        $lim = $limit > 0 ? "LIMIT $limit" : '';
        $result = $this->conn->query(
            "SELECT b.*, r.room_no, r.type, r.price
             FROM bookings b
             JOIN rooms r ON r.id = b.room_id
             WHERE b.user_id = $userId
             ORDER BY b.created_at DESC $lim"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Create a booking ──────────────────────────────────
    public function create(array $data): int|false {
        $stmt = $this->conn->prepare(
            "INSERT INTO bookings (user_id, room_id, check_in, check_out, guests, total_price, special_request, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')"
        );
        $stmt->bind_param(
            "iissids",
            $data['user_id'],
            $data['room_id'],
            $data['check_in'],
            $data['check_out'],
            $data['guests'],
            $data['total_price'],
            $data['special_request']
        );
        if ($stmt->execute()) {
            $id = $this->conn->insert_id;
            $stmt->close();
            return $id;
        }
        $stmt->close();
        return false;
    }

    // ── Update booking status ─────────────────────────────
    public function setStatus(int $id, string $status): bool {
        $s = $this->conn->real_escape_string($status);
        return (bool) $this->conn->query("UPDATE bookings SET status='$s' WHERE id=$id");
    }

    // ── Cancel a booking ──────────────────────────────────
    public function cancel(int $id): bool {
        return $this->setStatus($id, 'cancelled');
    }

    // ── Today's arrivals ──────────────────────────────────
    public function getTodayArrivals(): array {
        $result = $this->conn->query(
            "SELECT b.*, u.full_name, u.phone, r.room_no, r.type, r.floor
             FROM bookings b
             JOIN users u ON u.id = b.user_id
             JOIN rooms  r ON r.id = b.room_id
             WHERE b.check_in = CURDATE() AND b.status = 'confirmed'
             ORDER BY b.id ASC"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Today's departures ────────────────────────────────
    public function getTodayDepartures(): array {
        $result = $this->conn->query(
            "SELECT b.*, u.full_name, u.phone, r.room_no, r.type, r.floor
             FROM bookings b
             JOIN users u ON u.id = b.user_id
             JOIN rooms  r ON r.id = b.room_id
             WHERE b.check_out = CURDATE() AND b.status = 'checked_in'
             ORDER BY b.id ASC"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Revenue summary ───────────────────────────────────
    public function getTotalRevenue(): float {
        $row = $this->conn->query(
            "SELECT COALESCE(SUM(amount), 0) r FROM payments WHERE status = 'paid'"
        )->fetch_assoc();
        return (float) $row['r'];
    }

    // ── Monthly revenue (last N months) ──────────────────
    public function getMonthlyRevenue(int $months = 6): array {
        $result = $this->conn->query(
            "SELECT DATE_FORMAT(paid_at,'%b %Y') mo, SUM(amount) total
             FROM payments
             WHERE status = 'paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL $months MONTH)
             GROUP BY YEAR(paid_at), MONTH(paid_at)
             ORDER BY paid_at ASC"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Count by status ───────────────────────────────────
    public function countByStatus(): array {
        $result = $this->conn->query(
            "SELECT status, COUNT(*) cnt FROM bookings GROUP BY status"
        );
        $counts = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $counts[$row['status']] = (int) $row['cnt'];
            }
        }
        return $counts;
    }
}
