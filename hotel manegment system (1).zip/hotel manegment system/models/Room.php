<?php
// ============================================================
//  Grand Lake Hotel — Room Model
//  models/Room.php
// ============================================================

require_once __DIR__ . '/../connection.php';

class Room {

    private mysqli $conn;

    public function __construct() {
        global $conn;
        $this->conn = $conn;
    }

    // ── Fetch all rooms ───────────────────────────────────
    public function getAll(string $status = ''): array {
        $where = $status ? "WHERE status = '" . $this->conn->real_escape_string($status) . "'" : '';
        $result = $this->conn->query(
            "SELECT * FROM rooms $where ORDER BY floor ASC, room_no ASC"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }

    // ── Fetch single room by ID ───────────────────────────
    public function getById(int $id): ?array {
        $result = $this->conn->query("SELECT * FROM rooms WHERE id = $id LIMIT 1");
        return $result ? $result->fetch_assoc() : null;
    }

    // ── Fetch available rooms ─────────────────────────────
    public function getAvailable(): array {
        return $this->getAll('available');
    }

    // ── Create a new room ─────────────────────────────────
    public function create(array $data): bool {
        $room_no = $this->conn->real_escape_string(trim($data['room_no']));
        $type    = $this->conn->real_escape_string($data['type']);
        $floor   = intval($data['floor']);
        $cap     = intval($data['capacity']);
        $price   = floatval($data['price']);
        $desc    = $this->conn->real_escape_string($data['description'] ?? '');

        $stmt = $this->conn->prepare(
            "INSERT INTO rooms (room_no, type, floor, capacity, price, description)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("ssiids", $room_no, $type, $floor, $cap, $price, $desc);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    // ── Update a room ─────────────────────────────────────
    public function update(int $id, array $data): bool {
        $type    = $this->conn->real_escape_string($data['type']);
        $floor   = intval($data['floor']);
        $cap     = intval($data['capacity']);
        $price   = floatval($data['price']);
        $desc    = $this->conn->real_escape_string($data['description'] ?? '');
        $status  = $this->conn->real_escape_string($data['status'] ?? 'available');

        $stmt = $this->conn->prepare(
            "UPDATE rooms SET type=?, floor=?, capacity=?, price=?, description=?, status=?
             WHERE id=?"
        );
        $stmt->bind_param("siidss i", $type, $floor, $cap, $price, $desc, $status, $id);
        $ok = $stmt->execute();
        $stmt->close();
        return $ok;
    }

    // ── Delete a room ─────────────────────────────────────
    public function delete(int $id): bool {
        return (bool) $this->conn->query("DELETE FROM rooms WHERE id = $id");
    }

    // ── Update room status ────────────────────────────────
    public function setStatus(int $id, string $status): bool {
        $s = $this->conn->real_escape_string($status);
        return (bool) $this->conn->query("UPDATE rooms SET status='$s' WHERE id=$id");
    }

    // ── Count by status ───────────────────────────────────
    public function countByStatus(): array {
        $result = $this->conn->query(
            "SELECT status, COUNT(*) AS cnt FROM rooms GROUP BY status"
        );
        $counts = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $counts[$row['status']] = (int) $row['cnt'];
            }
        }
        return $counts;
    }

    // ── Search rooms ──────────────────────────────────────
    public function search(string $q): array {
        $q = '%' . $this->conn->real_escape_string($q) . '%';
        $result = $this->conn->query(
            "SELECT * FROM rooms
             WHERE room_no LIKE '$q' OR type LIKE '$q' OR description LIKE '$q'
             ORDER BY room_no"
        );
        return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    }
}
