document.addEventListener('DOMContentLoaded', () => {
  const sidebar   = document.getElementById('sidebar');
  const hamburger = document.getElementById('hamburgerDash');
  if (hamburger && sidebar) hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.querySelectorAll('.alert[data-dismiss]').forEach(el => setTimeout(() => el.style.display='none', 4000));
});
function drawBarChart(id, labels, data, label) {
  const c = document.getElementById(id);
  if (!c || typeof Chart === 'undefined') return;
  new Chart(c, { type:'bar', data:{ labels, datasets:[{ label, data, backgroundColor:'rgba(0,53,128,.7)', borderRadius:6 }] }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} } });
}
function drawLine(id, labels, data, label) {
  const c = document.getElementById(id);
  if (!c || typeof Chart === 'undefined') return;
  new Chart(c, { type:'line', data:{ labels, datasets:[{ label, data, borderColor:'#C8A951', backgroundColor:'rgba(200,169,81,.1)', tension:.4, fill:true }] }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true}} } });
}
