<?php
require_once '../connection.php';
requireRole('manager', '../login.php');
$user = currentUser();

// ── KPI Stats ─────────────────────────────────────────────
$totalRevenue  = $conn->query("SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='paid'")->fetch_assoc()['r'];
$monthRevenue  = $conn->query("SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='paid' AND MONTH(paid_at)=MONTH(NOW()) AND YEAR(paid_at)=YEAR(NOW())")->fetch_assoc()['r'];
$totalBookings = $conn->query("SELECT COUNT(*) c FROM bookings")->fetch_assoc()['c'];
$occupancyRate = $conn->query("SELECT ROUND(COUNT(*)*100/(SELECT COUNT(*) FROM rooms),1) r FROM rooms WHERE status IN ('booked','cleaning')")->fetch_assoc()['r'];
$avgStay       = $conn->query("SELECT ROUND(AVG(DATEDIFF(check_out,check_in)),1) a FROM bookings WHERE status='checked_out'")->fetch_assoc()['a'];
$cancelRate    = $conn->query("SELECT ROUND(SUM(status='cancelled')*100/COUNT(*),1) r FROM bookings")->fetch_assoc()['r'];

// ── Monthly Revenue (last 6 months) ──────────────────────
$monthlyRev = $conn->query(
    "SELECT DATE_FORMAT(paid_at,'%b %Y') mo, SUM(amount) total
     FROM payments WHERE status='paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
     GROUP BY YEAR(paid_at), MONTH(paid_at) ORDER BY paid_at"
);
$revLabels = $revData = [];
while ($row = $monthlyRev->fetch_assoc()) {
    $revLabels[] = $row['mo'];
    $revData[]   = round($row['total'], 2);
}

// ── Bookings by room type ─────────────────────────────────
$byType = $conn->query("SELECT r.type, COUNT(*) c FROM bookings b JOIN rooms r ON r.id=b.room_id GROUP BY r.type");
$typeLabels = $typeData = [];
while ($row = $byType->fetch_assoc()) {
    $typeLabels[] = ucfirst($row['type']);
    $typeData[]   = $row['c'];
}

// ── Recent payments ───────────────────────────────────────
$payments = $conn->query(
    "SELECT p.*, b.id bid, u.full_name, r.room_no
     FROM payments p
     JOIN bookings b ON b.id=p.booking_id
     JOIN users u ON u.id=b.user_id
     JOIN rooms r ON r.id=b.room_id
     ORDER BY p.created_at DESC LIMIT 15"
);

// ── Top rooms by revenue ──────────────────────────────────
$topRooms = $conn->query(
    "SELECT r.room_no, r.type, COUNT(b.id) bookings, SUM(b.total_price) revenue
     FROM rooms r LEFT JOIN bookings b ON b.room_id=r.id
     GROUP BY r.id ORDER BY revenue DESC LIMIT 8"
);

// ── Staff list ────────────────────────────────────────────
$staffList = $conn->query(
    "SELECT u.id, u.full_name, u.username, u.email, u.phone, u.role, u.created_at,
            (SELECT COUNT(*) FROM bookings b WHERE b.user_id=u.id) AS total_bookings
     FROM users u
     WHERE u.role != 'customer'
     ORDER BY u.role, u.full_name"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manager Reports — Grand Lake Hotel</title>
  <link rel="stylesheet" href="manager.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Manager Reports</div></div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-chart-line"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Reports</div>
    <a href="#kpi" class="active"><i class="fas fa-tachometer-alt"></i> KPI Overview</a>
    <a href="#revenue"><i class="fas fa-money-bill"></i> Revenue</a>
    <a href="#payments"><i class="fas fa-credit-card"></i> Payments</a>
    <a href="#rooms"><i class="fas fa-bed"></i> Room Performance</a>
    <a href="#staff"><i class="fas fa-users-cog"></i> Staff</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Manager Reports</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / Manager</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="../profile.php" class="topnav-icon"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">

    <!-- KPI Cards -->
    <style>
      .stat-card-link{text-decoration:none;color:inherit;display:block;border-radius:inherit;transition:transform .18s,box-shadow .18s;}
      .stat-card-link:hover .stat-card{transform:translateY(-4px);box-shadow:0 8px 28px rgba(0,0,0,.13);border-color:var(--primary);cursor:pointer;}
      .stat-card-link:hover .stat-value{color:var(--primary);}
    </style>
    <div class="stats-grid" id="kpi">
      <a href="#payments" class="stat-card-link" onclick="document.getElementById('payments').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon purple"><i class="fas fa-money-bill"></i></div>
          <div class="stat-info"><div class="stat-value">ETB <?= number_format($totalRevenue, 0) ?></div><div class="stat-label">Total Revenue</div></div>
        </div>
      </a>
      <a href="#revenue" class="stat-card-link" onclick="document.getElementById('revenue').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon green"><i class="fas fa-calendar-alt"></i></div>
          <div class="stat-info"><div class="stat-value">ETB <?= number_format($monthRevenue, 0) ?></div><div class="stat-label">This Month</div></div>
        </div>
      </a>
      <a href="#payments" class="stat-card-link" onclick="document.getElementById('payments').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fas fa-calendar-check"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $totalBookings ?></div><div class="stat-label">Total Bookings</div></div>
        </div>
      </a>
      <a href="#rooms" class="stat-card-link" onclick="document.getElementById('rooms').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon teal"><i class="fas fa-percentage"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $occupancyRate ?>%</div><div class="stat-label">Occupancy Rate</div></div>
        </div>
      </a>
      <a href="#rooms" class="stat-card-link" onclick="document.getElementById('rooms').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon yellow"><i class="fas fa-moon"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $avgStay ?></div><div class="stat-label">Avg. Stay (nights)</div></div>
        </div>
      </a>
      <a href="#payments" class="stat-card-link" onclick="document.getElementById('payments').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon red"><i class="fas fa-times-circle"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $cancelRate ?>%</div><div class="stat-label">Cancellation Rate</div></div>
        </div>
      </a>
    </div>

    <!-- Charts -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem;" id="revenue">
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-line"></i> Monthly Revenue (Last 6 Months)</h3></div>
        <div class="card-body"><canvas id="revChart" height="140"></canvas></div>
      </div>
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-bar"></i> Bookings by Room Type</h3></div>
        <div class="card-body"><canvas id="typeChart" height="140"></canvas></div>
      </div>
    </div>

    <!-- Payments Table -->
    <div class="card" id="payments">
      <div class="card-header"><h3><i class="fas fa-credit-card"></i> Recent Payments</h3></div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              <?php while ($p = $payments->fetch_assoc()): ?>
                <tr>
                  <td><?= $p['id'] ?></td>
                  <td><?= htmlspecialchars($p['full_name']) ?></td>
                  <td><?= htmlspecialchars($p['room_no']) ?></td>
                  <td>ETB <?= number_format($p['amount'], 2) ?></td>
                  <td><?= ucfirst(str_replace('_', ' ', $p['method'])) ?></td>
                  <td><span class="badge badge-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                  <td><?= $p['paid_at'] ? date('M d, Y', strtotime($p['paid_at'])) : '—' ?></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Room Performance -->
    <div class="card" id="rooms">
      <div class="card-header"><h3><i class="fas fa-bed"></i> Room Performance</h3></div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>Room No</th><th>Type</th><th>Total Bookings</th><th>Revenue Generated</th></tr></thead>
            <tbody>
              <?php while ($r = $topRooms->fetch_assoc()): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($r['room_no']) ?></strong></td>
                  <td><?= ucfirst($r['type']) ?></td>
                  <td><?= $r['bookings'] ?? 0 ?></td>
                  <td>ETB <?= number_format($r['revenue'] ?? 0, 2) ?></td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── Staff Management ──────────────────────────────── -->
    <div class="card" id="staff">
      <div class="card-header"><h3><i class="fas fa-users-cog"></i> Staff Directory</h3></div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>#</th><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>Role</th><th>Joined</th></tr></thead>
            <tbody>
              <?php while ($s = $staffList->fetch_assoc()): ?>
              <tr>
                <td><?= $s['id'] ?></td>
                <td><strong><?= htmlspecialchars($s['full_name']) ?></strong></td>
                <td><?= htmlspecialchars($s['username']) ?></td>
                <td><?= htmlspecialchars($s['email']) ?></td>
                <td><?= htmlspecialchars($s['phone'] ?? '—') ?></td>
                <td><span class="badge badge-confirmed"><?= ucfirst($s['role']) ?></span></td>
                <td><?= date('d M Y', strtotime($s['created_at'])) ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="manager.js"></script>
<script>
drawLine('revChart', <?= json_encode($revLabels) ?>, <?= json_encode($revData) ?>, 'Revenue (ETB)');
drawBarChart('typeChart', <?= json_encode($typeLabels) ?>, <?= json_encode($typeData) ?>, 'Bookings');
</script>
</body>
</html>
