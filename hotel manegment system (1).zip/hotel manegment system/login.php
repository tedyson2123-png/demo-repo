<?php
require_once 'connection.php';

if (isLoggedIn()) {
    redirect(currentUser()['role'] . '/' . currentUser()['role'] . '.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = escape($conn, $_POST['username'] ?? '');
    $password = MD5(trim($_POST['password'] ?? ''));

    if ($username && $password) {
        $stmt = $conn->prepare(
            "SELECT id, full_name, username, email, role
             FROM users
             WHERE (username = ? OR email = ?) AND password = ?
             LIMIT 1"
        );
        $stmt->bind_param("sss", $username, $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            $_SESSION['user_id']   = $row['id'];
            $_SESSION['username']  = $row['username'];
            $_SESSION['full_name'] = $row['full_name'];
            $_SESSION['email']     = $row['email'];
            $_SESSION['role']      = $row['role'];

            writeLog('login', "User {$row['username']} ({$row['role']}) logged in.");

            // Role-based redirect
            $role = $row['role'];
            redirect("{$role}/{$role}.php");
        } else {
            $error = 'Invalid username or password. Please try again.';
        }
        $stmt->close();
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login — Grand Lake Hotel</title>
  <link rel="stylesheet" href="home.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body{background:var(--light)}
    .auth-wrapper{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem 1rem;background:linear-gradient(135deg,var(--primary-d) 0%,#1a4a8a 100%)}
    .auth-card{background:var(--white);border-radius:20px;box-shadow:var(--shadow-lg);width:100%;max-width:460px;overflow:hidden}
    .auth-header{background:linear-gradient(135deg,var(--primary),#1a4a8a);padding:2.5rem 2rem;text-align:center;color:var(--white)}
    .auth-header .logo-icon{margin:0 auto 1rem;width:60px;height:60px;font-size:1.8rem}
    .auth-header h2{font-size:1.5rem;margin-bottom:.3rem}
    .auth-header p{color:rgba(255,255,255,.75);font-size:.9rem}
    .auth-body{padding:2rem}
    .form-group{margin-bottom:1.25rem}
    .form-group label{display:block;font-weight:600;color:var(--dark);margin-bottom:.4rem;font-size:.9rem}
    .input-wrap{position:relative}
    .input-wrap i.icon{position:absolute;left:1rem;top:50%;transform:translateY(-50%);color:var(--gray)}
    .input-wrap input{width:100%;padding:.75rem 1rem .75rem 2.75rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.95rem;transition:border-color var(--transition)}
    .input-wrap input:focus{outline:none;border-color:var(--primary)}
    .toggle-pw{position:absolute;right:1rem;top:50%;transform:translateY(-50%);cursor:pointer;color:var(--gray)}
    .form-options{display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;font-size:.88rem}
    .form-options label{display:flex;align-items:center;gap:.4rem;cursor:pointer;color:var(--gray)}
    .form-options a{color:var(--primary);font-weight:600}
    .btn-auth{width:100%;padding:.85rem;background:var(--primary);color:var(--white);border:none;border-radius:var(--radius);font-size:1rem;font-weight:700;cursor:pointer;transition:background var(--transition)}
    .btn-auth:hover{background:var(--accent);color:var(--dark)}
    .auth-footer{text-align:center;margin-top:1.5rem;font-size:.9rem;color:var(--gray)}
    .auth-footer a{color:var(--primary);font-weight:600}
    .alert{padding:.75rem 1rem;border-radius:var(--radius);margin-bottom:1rem;font-size:.9rem}
    .alert-error{background:#FEE2E2;color:var(--danger);border:1px solid #FECACA}
    .alert-success{background:#D1FAE5;color:var(--success);border:1px solid #A7F3D0}
  </style>
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card">
    <div class="auth-header">
      <div class="logo-icon"><i class="fas fa-hotel"></i></div>
      <h2>Welcome Back</h2>
      <p>Sign in to your Grand Lake Hotel account</p>
    </div>
    <div class="auth-body">
      <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php $reg = flash('register_success'); if ($reg): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($reg) ?></div>
      <?php endif; ?>

      <form method="POST" action="login.php">
        <div class="form-group">
          <label>Username or Email</label>
          <div class="input-wrap">
            <i class="fas fa-user icon"></i>
            <input type="text" name="username" placeholder="Enter your username" required
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" />
          </div>
        </div>
        <div class="form-group">
          <label>Password</label>
          <div class="input-wrap">
            <i class="fas fa-lock icon"></i>
            <input type="password" id="password" name="password" placeholder="Enter your password" required />
            <span class="toggle-pw" onclick="togglePw()"><i class="fas fa-eye" id="eyeIcon"></i></span>
          </div>
        </div>
        <div class="form-options">
          <label><input type="checkbox" name="remember" /> Remember me</label>
          <a href="forgot_password.php">Forgot password?</a>
        </div>
        <button type="submit" class="btn-auth">
          <i class="fas fa-sign-in-alt"></i> Sign In
        </button>
      </form>
      <div class="auth-footer">
        Don't have an account? <a href="register.html">Register here</a> &nbsp;|&nbsp; <a href="index.html">Back to Home</a>
      </div>
    </div>
  </div>
</div>
<script>
function togglePw() {
  const pw = document.getElementById('password');
  const icon = document.getElementById('eyeIcon');
  pw.type = pw.type === 'password' ? 'text' : 'password';
  icon.className = pw.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
</body>
</html>
