<?php
// ============================================================
//  Grand Lake Hotel — Database Configuration
//  config/database.php
//
//  This is the single source of truth for DB credentials.
//  connection.php includes this file so all pages that use
//  connection.php automatically get these settings.
// ============================================================

define('DB_HOST',    'localhost');
define('DB_USER',    'root');
define('DB_PASS',    '');           // change if you set a MySQL password
define('DB_NAME',    'hotel_management');
define('DB_CHARSET', 'utf8mb4');
