<?php
// ============================================================
//  Grand Lake Hotel — Forgot Password
//  forgot_password.php
// ============================================================
require_once 'connection.php';

// Already logged in? Redirect away.
if (isLoggedIn()) {
    redirect(currentUser()['role'] . '/' . currentUser()['role'] . '.php');
}

$error   = '';
$success = '';
$step    = 'request'; // 'request' | 'verify'

// ── Step 1: User submits their email ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'send_code') {
    $email = trim($_POST['email'] ?? '');

    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Check if email exists
        $stmt = $conn->prepare("SELECT id, full_name FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user   = $result->fetch_assoc();
        $stmt->close();

        if (!$user) {
            // Generic message to avoid user enumeration
            $success = 'If that email is registered, a verification code has been sent.';
        } else {
            // Generate a 6-digit code
            $code       = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
            $expires_at = date('Y-m-d H:i:s', strtotime('+15 minutes'));

            // Delete any old tokens for this email
            $del = $conn->prepare("DELETE FROM password_reset_tokens WHERE email = ?");
            $del->bind_param("s", $email);
            $del->execute();
            $del->close();

            // Store new token
            $ins = $conn->prepare(
                "INSERT INTO password_reset_tokens (email, token, expires_at) VALUES (?, ?, ?)"
            );
            $ins->bind_param("sss", $email, $code, $expires_at);
            $ins->execute();
            $ins->close();

            // ── Send email ───────────────────────────────────
            $to      = $email;
            $subject = 'Grand Lake Hotel — Password Reset Code';
            $name    = htmlspecialchars($user['full_name']);
            $body    = "Dear {$name},\n\n"
                     . "Your password reset verification code is:\n\n"
                     . "  {$code}\n\n"
                     . "This code expires in 15 minutes.\n\n"
                     . "If you did not request a password reset, please ignore this email.\n\n"
                     . "— Grand Lake Hotel";

            $headers = "From: noreply@grandlakehotel.com\r\n"
                     . "Reply-To: noreply@grandlakehotel.com\r\n"
                     . "X-Mailer: PHP/" . phpversion();

            mail($to, $subject, $body, $headers);

            // Store email in session so the verify step knows who we're resetting
            $_SESSION['reset_email'] = $email;

            $success = 'A 6-digit verification code has been sent to your email address.';
            $step    = 'verify';
        }
    }
}

// ── Step 2: User submits code + new password ─────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'verify_code') {
    $email    = $_SESSION['reset_email'] ?? '';
    $code     = trim($_POST['code'] ?? '');
    $password = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $step     = 'verify';

    if (!$email) {
        $error = 'Session expired. Please start over.';
        $step  = 'request';
    } elseif (strlen($code) !== 6 || !ctype_digit($code)) {
        $error = 'Please enter the 6-digit code sent to your email.';
    } elseif (strlen($password) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        // Validate token
        $stmt = $conn->prepare(
            "SELECT id FROM password_reset_tokens
             WHERE email = ? AND token = ? AND expires_at > NOW() AND used = 0
             LIMIT 1"
        );
        $stmt->bind_param("ss", $email, $code);
        $stmt->execute();
        $result = $stmt->get_result();
        $token  = $result->fetch_assoc();
        $stmt->close();

        if (!$token) {
            $error = 'Invalid or expired code. Please request a new one.';
        } else {
            // Update password
            $hashed = MD5($password);
            $upd = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $upd->bind_param("ss", $hashed, $email);
            $upd->execute();
            $upd->close();

            // Mark token as used
            $mark = $conn->prepare(
                "UPDATE password_reset_tokens SET used = 1 WHERE email = ? AND token = ?"
            );
            $mark->bind_param("ss", $email, $code);
            $mark->execute();
            $mark->close();

            // Clean up session
            unset($_SESSION['reset_email']);

            // Flash message and redirect to login
            flash('register_success', 'Password reset successfully. Please sign in with your new password.');
            redirect('login.php');
        }
    }
}

// Restore step if session has email (user refreshed the verify page)
if ($step === 'request' && !empty($_SESSION['reset_email']) && !$error) {
    $step = 'verify';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Forgot Password — Grand Lake Hotel</title>
  <link rel="stylesheet" href="home.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body { background: var(--light); }
    .auth-wrapper {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem 1rem;
      background: linear-gradient(135deg, var(--primary-d) 0%, #1a4a8a 100%);
    }
    .auth-card {
      background: var(--white);
      border-radius: 20px;
      box-shadow: var(--shadow-lg);
      width: 100%;
      max-width: 460px;
      overflow: hidden;
    }
    .auth-header {
      background: linear-gradient(135deg, var(--primary), #1a4a8a);
      padding: 2.5rem 2rem;
      text-align: center;
      color: var(--white);
    }
    .auth-header .logo-icon {
      margin: 0 auto 1rem;
      width: 60px;
      height: 60px;
      font-size: 1.8rem;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .auth-header h2 { font-size: 1.5rem; margin-bottom: .3rem; }
    .auth-header p  { color: rgba(255,255,255,.75); font-size: .9rem; }
    .auth-body  { padding: 2rem; }
    .form-group { margin-bottom: 1.25rem; }
    .form-group label {
      display: block;
      font-weight: 600;
      color: var(--dark);
      margin-bottom: .4rem;
      font-size: .9rem;
    }
    .input-wrap { position: relative; }
    .input-wrap i.icon {
      position: absolute;
      left: 1rem;
      top: 50%;
      transform: translateY(-50%);
      color: var(--gray);
    }
    .input-wrap input {
      width: 100%;
      padding: .75rem 1rem .75rem 2.75rem;
      border: 1.5px solid var(--gray-l);
      border-radius: var(--radius);
      font-size: .95rem;
      transition: border-color var(--transition);
      box-sizing: border-box;
    }
    .input-wrap input:focus { outline: none; border-color: var(--primary); }
    .toggle-pw {
      position: absolute;
      right: 1rem;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      color: var(--gray);
    }
    .btn-auth {
      width: 100%;
      padding: .85rem;
      background: var(--primary);
      color: var(--white);
      border: none;
      border-radius: var(--radius);
      font-size: 1rem;
      font-weight: 700;
      cursor: pointer;
      transition: background var(--transition);
    }
    .btn-auth:hover { background: var(--accent); color: var(--dark); }
    .auth-footer {
      text-align: center;
      margin-top: 1.5rem;
      font-size: .9rem;
      color: var(--gray);
    }
    .auth-footer a { color: var(--primary); font-weight: 600; }
    .alert {
      padding: .75rem 1rem;
      border-radius: var(--radius);
      margin-bottom: 1rem;
      font-size: .9rem;
    }
    .alert-error   { background: #FEE2E2; color: var(--danger);  border: 1px solid #FECACA; }
    .alert-success { background: #D1FAE5; color: var(--success); border: 1px solid #A7F3D0; }
    /* Code input */
    .code-input {
      letter-spacing: .5rem;
      font-size: 1.6rem;
      font-weight: 700;
      text-align: center;
      padding: .75rem 1rem !important;
    }
    .step-indicator {
      display: flex;
      justify-content: center;
      gap: .5rem;
      margin-bottom: 1.5rem;
    }
    .step-dot {
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background: var(--gray-l);
    }
    .step-dot.active { background: var(--primary); }
    .resend-link {
      text-align: center;
      margin-top: .75rem;
      font-size: .85rem;
      color: var(--gray);
    }
    .resend-link a { color: var(--primary); font-weight: 600; cursor: pointer; }
    .hint {
      font-size: .82rem;
      color: var(--gray);
      margin-top: .3rem;
    }
  </style>
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card">

    <div class="auth-header">
      <div class="logo-icon"><i class="fas fa-key"></i></div>
      <h2>Reset Password</h2>
      <p>
        <?= $step === 'verify'
            ? 'Enter the code sent to your email'
            : 'Enter your email to receive a reset code' ?>
      </p>
    </div>

    <div class="auth-body">

      <!-- Step indicator -->
      <div class="step-indicator">
        <div class="step-dot <?= $step === 'request' ? 'active' : '' ?>"></div>
        <div class="step-dot <?= $step === 'verify'  ? 'active' : '' ?>"></div>
      </div>

      <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if ($success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <!-- ── STEP 1: Request code ── -->
      <?php if ($step === 'request'): ?>
      <form method="POST" action="forgot_password.php">
        <input type="hidden" name="action" value="send_code" />
        <div class="form-group">
          <label for="email">Registered Email Address</label>
          <div class="input-wrap">
            <i class="fas fa-envelope icon"></i>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="you@example.com"
              value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
              required
              autocomplete="email"
            />
          </div>
          <p class="hint">We'll send a 6-digit code to this address.</p>
        </div>
        <button type="submit" class="btn-auth">
          <i class="fas fa-paper-plane"></i> Send Verification Code
        </button>
      </form>

      <!-- ── STEP 2: Verify code + new password ── -->
      <?php else: ?>
      <form method="POST" action="forgot_password.php">
        <input type="hidden" name="action" value="verify_code" />

        <div class="form-group">
          <label for="code">6-Digit Verification Code</label>
          <div class="input-wrap">
            <input
              type="text"
              id="code"
              name="code"
              class="code-input"
              placeholder="000000"
              maxlength="6"
              inputmode="numeric"
              pattern="\d{6}"
              autocomplete="one-time-code"
              required
            />
          </div>
          <p class="hint">Check your inbox (and spam folder) for the code.</p>
        </div>

        <div class="form-group">
          <label for="new_password">New Password</label>
          <div class="input-wrap">
            <i class="fas fa-lock icon"></i>
            <input
              type="password"
              id="new_password"
              name="new_password"
              placeholder="At least 6 characters"
              minlength="6"
              required
            />
            <span class="toggle-pw" onclick="togglePw('new_password','eyeNew')">
              <i class="fas fa-eye" id="eyeNew"></i>
            </span>
          </div>
        </div>

        <div class="form-group">
          <label for="confirm_password">Confirm New Password</label>
          <div class="input-wrap">
            <i class="fas fa-lock icon"></i>
            <input
              type="password"
              id="confirm_password"
              name="confirm_password"
              placeholder="Repeat your new password"
              minlength="6"
              required
            />
            <span class="toggle-pw" onclick="togglePw('confirm_password','eyeConfirm')">
              <i class="fas fa-eye" id="eyeConfirm"></i>
            </span>
          </div>
        </div>

        <button type="submit" class="btn-auth" id="submitBtn">
          <i class="fas fa-shield-alt"></i> Reset Password
        </button>
      </form>

      <div class="resend-link">
        Didn't receive the code?
        <a href="forgot_password.php?clear=1">Resend code</a>
      </div>
      <?php endif; ?>

      <div class="auth-footer">
        <a href="login.php"><i class="fas fa-arrow-left"></i> Back to Sign In</a>
      </div>

    </div><!-- /.auth-body -->
  </div><!-- /.auth-card -->
</div><!-- /.auth-wrapper -->

<script>
function togglePw(fieldId, iconId) {
  const field = document.getElementById(fieldId);
  const icon  = document.getElementById(iconId);
  field.type  = field.type === 'password' ? 'text' : 'password';
  icon.className = field.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}

// Allow only digits in the code field
const codeField = document.getElementById('code');
if (codeField) {
  codeField.addEventListener('input', function () {
    this.value = this.value.replace(/\D/g, '').slice(0, 6);
  });
}

// Client-side password match check
const submitBtn = document.getElementById('submitBtn');
if (submitBtn) {
  submitBtn.closest('form').addEventListener('submit', function (e) {
    const pw  = document.getElementById('new_password')?.value;
    const cpw = document.getElementById('confirm_password')?.value;
    if (pw && cpw && pw !== cpw) {
      e.preventDefault();
      alert('Passwords do not match. Please try again.');
    }
  });
}
</script>

<?php
// Clear session if user wants to start over
if (isset($_GET['clear'])) {
    unset($_SESSION['reset_email']);
    header('Location: forgot_password.php');
    exit;
}
?>
</body>
</html>
