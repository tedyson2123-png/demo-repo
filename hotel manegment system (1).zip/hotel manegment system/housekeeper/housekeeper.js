document.addEventListener('DOMContentLoaded', () => {
  const sidebar   = document.getElementById('sidebar');
  const hamburger = document.getElementById('hamburgerDash');
  if (hamburger && sidebar) hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', e => { if (!confirm(el.dataset.confirm)) e.preventDefault(); });
  });
  document.querySelectorAll('.alert[data-dismiss]').forEach(el => setTimeout(() => el.style.display='none', 4000));
  const search = document.getElementById('tableSearch');
  if (search) search.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.searchable-table tbody tr').forEach(r => r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none');
  });
  window.openModal  = id => document.getElementById(id)?.classList.add('open');
  window.closeModal = id => document.getElementById(id)?.classList.remove('open');
  document.querySelectorAll('.modal-overlay').forEach(m => m.addEventListener('click', e => { if (e.target===m) m.classList.remove('open'); }));
});
