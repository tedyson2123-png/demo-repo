<?php
require_once '../connection.php';
requireRole('housekeeper', '../login.php');
$user = currentUser();

$success = $error = '';

// ── Mark task done ────────────────────────────────────────
if (isset($_GET['done']) && is_numeric($_GET['done'])) {
    $id = intval($_GET['done']);
    $conn->query("UPDATE housekeeping_tasks SET status='done', completed_at=NOW() WHERE id=$id AND assigned_to={$user['id']}");
    $success = 'Task marked as completed.';
}
if (isset($_GET['start']) && is_numeric($_GET['start'])) {
    $id = intval($_GET['start']);
    $conn->query("UPDATE housekeeping_tasks SET status='in_progress' WHERE id=$id AND assigned_to={$user['id']}");
    $success = 'Task started.';
}

// ── Mark room clean ───────────────────────────────────────
if (isset($_GET['clean_room']) && is_numeric($_GET['clean_room'])) {
    $rid = intval($_GET['clean_room']);
    $conn->query("UPDATE rooms SET status='available' WHERE id=$rid AND status='cleaning'");
    $success = 'Room marked as available.';
}

// ── Mark room dirty (needs cleaning) ─────────────────────
if (isset($_GET['dirty_room']) && is_numeric($_GET['dirty_room'])) {
    $rid = intval($_GET['dirty_room']);
    $conn->query("UPDATE rooms SET status='cleaning' WHERE id=$rid AND status='available'");
    $success = 'Room marked as needing cleaning.';
}

// ── Report room issue (creates maintenance request) ───────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['report_issue'])) {
    $room_id  = intval($_POST['issue_room_id']);
    $title    = escape($conn, $_POST['issue_title']);
    $desc     = escape($conn, $_POST['issue_desc']);
    $priority = escape($conn, $_POST['issue_priority']);
    $uid      = $user['id'];
    $stmt = $conn->prepare(
        "INSERT INTO maintenance_requests (room_id, reported_by, title, description, priority)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("iisss", $room_id, $uid, $title, $desc, $priority);
    $stmt->execute() ? $success = 'Issue reported to maintenance.' : $error = 'Failed to report issue.';
    $stmt->close();
}

// ── Add task ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_task'])) {
    $room_id   = intval($_POST['room_id']);
    $task_type = escape($conn, $_POST['task_type']);
    $notes     = escape($conn, $_POST['notes']);
    $scheduled = escape($conn, $_POST['scheduled_at']);
    $uid       = $user['id'];

    $stmt = $conn->prepare(
        "INSERT INTO housekeeping_tasks (room_id,assigned_to,task_type,notes,scheduled_at)
         VALUES (?,?,?,?,?)"
    );
    $stmt->bind_param("iisss", $room_id, $uid, $task_type, $notes, $scheduled);
    $stmt->execute() ? $success = 'Task added.' : $error = 'Failed to add task.';
    $stmt->close();
}

// ── Stats ─────────────────────────────────────────────────
$pendingCount  = $conn->query("SELECT COUNT(*) c FROM housekeeping_tasks WHERE status='pending' AND assigned_to={$user['id']}")->fetch_assoc()['c'];
$inProgCount   = $conn->query("SELECT COUNT(*) c FROM housekeeping_tasks WHERE status='in_progress' AND assigned_to={$user['id']}")->fetch_assoc()['c'];
$doneToday     = $conn->query("SELECT COUNT(*) c FROM housekeeping_tasks WHERE status='done' AND DATE(completed_at)=CURDATE() AND assigned_to={$user['id']}")->fetch_assoc()['c'];
$cleaningRooms = $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='cleaning'")->fetch_assoc()['c'];

// ── Data ──────────────────────────────────────────────────
$tasks = $conn->query(
    "SELECT t.*, r.room_no, r.type, r.floor
     FROM housekeeping_tasks t
     JOIN rooms r ON r.id=t.room_id
     WHERE t.assigned_to={$user['id']}
     ORDER BY FIELD(t.status,'in_progress','pending','done'), t.scheduled_at ASC"
);
$cleaningRoomsList = $conn->query("SELECT * FROM rooms WHERE status='cleaning' ORDER BY room_no");
$rooms = $conn->query("SELECT id, room_no, type FROM rooms ORDER BY room_no");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Housekeeping — Grand Lake Hotel</title>
  <link rel="stylesheet" href="housekeeper.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Housekeeping</div></div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-broom"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Housekeeping</div>
    <a href="#" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="#tasks"><i class="fas fa-tasks"></i> My Tasks <span class="badge"><?= $pendingCount ?></span></a>
    <a href="#cleaning"><i class="fas fa-bed"></i> Rooms to Clean <span class="badge"><?= $cleaningRooms ?></span></a>
    <a href="#" onclick="openModal('addTaskModal');return false;"><i class="fas fa-plus-circle"></i> Add Task</a>
    <a href="#" onclick="openModal('reportIssueModal');return false;"><i class="fas fa-exclamation-triangle"></i> Report Issue</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Housekeeping Panel</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / Housekeeping</p>
      </div>
    </div>
    <div class="topnav-right">
      <button class="btn btn-primary-d btn-sm" onclick="openModal('addTaskModal')">
        <i class="fas fa-plus"></i> Add Task
      </button>
      <button class="btn btn-danger btn-sm" onclick="openModal('reportIssueModal')" style="margin-left:.5rem;">
        <i class="fas fa-exclamation-triangle"></i> Report Issue
      </button>
      <a href="../profile.php" class="topnav-icon"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon yellow"><i class="fas fa-clock"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $pendingCount ?></div><div class="stat-label">Pending Tasks</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-spinner"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $inProgCount ?></div><div class="stat-label">In Progress</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $doneToday ?></div><div class="stat-label">Done Today</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-bed"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $cleaningRooms ?></div><div class="stat-label">Rooms to Clean</div></div>
      </div>
    </div>

    <!-- Rooms Needing Cleaning -->
    <?php if ($cleaningRoomsList->num_rows > 0): ?>
    <div class="card" id="cleaning">
      <div class="card-header"><h3><i class="fas fa-bed"></i> Rooms Awaiting Cleaning</h3></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem;">
          <?php while ($r = $cleaningRoomsList->fetch_assoc()): ?>
            <div style="background:var(--light);border-radius:12px;padding:1rem;text-align:center;border:2px solid #FEF3C7;">
              <div style="font-size:2rem;color:var(--accent);margin-bottom:.5rem;"><i class="fas fa-bed"></i></div>
              <h4 style="color:var(--primary);">Room <?= htmlspecialchars($r['room_no']) ?></h4>
              <p style="font-size:.82rem;color:var(--gray);"><?= ucfirst($r['type']) ?> · Floor <?= $r['floor'] ?></p>
              <a href="?clean_room=<?= $r['id'] ?>" class="btn btn-success btn-sm" style="margin-top:.75rem;display:inline-block;"
                 data-confirm="Mark room <?= htmlspecialchars($r['room_no']) ?> as clean and available?">
                <i class="fas fa-check"></i> Mark Clean
              </a>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Available Rooms — Mark Dirty -->
    <?php
    $availableRoomsList = $conn->query("SELECT * FROM rooms WHERE status='available' ORDER BY room_no");
    if ($availableRoomsList->num_rows > 0):
    ?>
    <div class="card" id="available-rooms">
      <div class="card-header"><h3><i class="fas fa-door-open"></i> Available Rooms — Mark as Dirty</h3></div>
      <div class="card-body">
        <p style="color:var(--gray);font-size:.88rem;margin-bottom:1rem;">
          If a room needs cleaning but was not automatically flagged, you can mark it dirty here.
        </p>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:1rem;">
          <?php while ($r = $availableRoomsList->fetch_assoc()): ?>
            <div style="background:var(--light);border-radius:12px;padding:1rem;text-align:center;border:2px solid #D1FAE5;">
              <div style="font-size:1.8rem;color:var(--success);margin-bottom:.4rem;"><i class="fas fa-door-open"></i></div>
              <h4 style="color:var(--primary);font-size:.95rem;">Room <?= htmlspecialchars($r['room_no']) ?></h4>
              <p style="font-size:.78rem;color:var(--gray);"><?= ucfirst($r['type']) ?> · Fl.<?= $r['floor'] ?></p>
              <a href="?dirty_room=<?= $r['id'] ?>" class="btn btn-accent btn-sm" style="margin-top:.6rem;display:inline-block;"
                 data-confirm="Mark room <?= htmlspecialchars($r['room_no']) ?> as needing cleaning?">
                <i class="fas fa-broom"></i> Mark Dirty
              </a>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- Tasks Table -->
    <div class="card" id="tasks">
      <div class="card-header">
        <h3><i class="fas fa-tasks"></i> My Housekeeping Tasks</h3>
        <input type="text" id="tableSearch" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <?php if ($tasks->num_rows === 0): ?>
          <p style="text-align:center;color:var(--gray);padding:2rem;">No tasks assigned. Great work!</p>
        <?php else: ?>
          <div class="table-wrap">
            <table class="data-table searchable-table">
              <thead><tr><th>#</th><th>Room</th><th>Task Type</th><th>Notes</th><th>Scheduled</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                <?php while ($t = $tasks->fetch_assoc()): ?>
                  <tr>
                    <td><?= $t['id'] ?></td>
                    <td><strong><?= htmlspecialchars($t['room_no']) ?></strong> · <?= ucfirst($t['type']) ?> · Fl.<?= $t['floor'] ?></td>
                    <td><?= ucfirst($t['task_type']) ?></td>
                    <td style="max-width:200px;"><?= htmlspecialchars($t['notes'] ?? '—') ?></td>
                    <td><?= $t['scheduled_at'] ?></td>
                    <td><span class="badge badge-<?= $t['status'] ?>"><?= ucfirst(str_replace('_',' ',$t['status'])) ?></span></td>
                    <td>
                      <?php if ($t['status'] === 'pending'): ?>
                        <a href="?start=<?= $t['id'] ?>" class="btn btn-accent btn-sm"><i class="fas fa-play"></i> Start</a>
                      <?php elseif ($t['status'] === 'in_progress'): ?>
                        <a href="?done=<?= $t['id'] ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Done</a>
                      <?php else: ?>
                        <span style="color:var(--gray);font-size:.8rem;"><i class="fas fa-check-circle"></i> Completed</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- Add Task Modal -->
<div class="modal-overlay" id="addTaskModal">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-plus-circle"></i> Add Housekeeping Task</h3>
      <button class="modal-close" onclick="closeModal('addTaskModal')">&times;</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-group">
          <label>Room</label>
          <select name="room_id" required>
            <option value="">Select room...</option>
            <?php $rooms->data_seek(0); while ($r = $rooms->fetch_assoc()): ?>
              <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['room_no']) ?> (<?= ucfirst($r['type']) ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-grid-2">
          <div class="form-group">
            <label>Task Type</label>
            <select name="task_type" required>
              <option value="cleaning">Cleaning</option>
              <option value="inspection">Inspection</option>
              <option value="restocking">Restocking</option>
              <option value="turndown">Turndown</option>
            </select>
          </div>
          <div class="form-group">
            <label>Scheduled Date</label>
            <input type="date" name="scheduled_at" required />
          </div>
        </div>
        <div class="form-group">
          <label>Notes</label>
          <textarea name="notes" rows="3" placeholder="Any special instructions..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-d" onclick="closeModal('addTaskModal')">Cancel</button>
        <button type="submit" name="add_task" class="btn btn-primary-d"><i class="fas fa-save"></i> Add Task</button>
      </div>
    </form>
  </div>
</div>

<script src="housekeeper.js"></script>
</body>
</html>

<!-- Report Issue Modal -->
<div class="modal-overlay" id="reportIssueModal">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-exclamation-triangle"></i> Report Room Issue</h3>
      <button class="modal-close" onclick="closeModal('reportIssueModal')">&times;</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-group">
          <label>Room</label>
          <select name="issue_room_id" required>
            <option value="">Select room...</option>
            <?php $rooms->data_seek(0); while ($r = $rooms->fetch_assoc()): ?>
              <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['room_no']) ?> (<?= ucfirst($r['type']) ?>)</option>
            <?php endwhile; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Issue Title</label>
          <input type="text" name="issue_title" placeholder="e.g. Broken light, Leaking tap" required />
        </div>
        <div class="form-group">
          <label>Priority</label>
          <select name="issue_priority" required>
            <option value="low">Low</option>
            <option value="medium" selected>Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea name="issue_desc" rows="3" placeholder="Describe the issue in detail..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-d" onclick="closeModal('reportIssueModal')">Cancel</button>
        <button type="submit" name="report_issue" class="btn btn-danger"><i class="fas fa-paper-plane"></i> Report Issue</button>
      </div>
    </form>
  </div>
</div>

<script src="housekeeper.js"></script>
</body>
</html>
