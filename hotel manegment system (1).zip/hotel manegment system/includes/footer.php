<?php
// ============================================================
//  Grand Lake Hotel — Shared Footer
//  includes/footer.php
// ============================================================

// Resolve base path
$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_FILENAME']);
$rootPath   = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$relDepth   = substr_count(ltrim(str_replace($rootPath, '', $scriptPath), '/'), '/');
$base       = str_repeat('../', $relDepth);
?>

<!-- ── Footer ───────────────────────────────────────────── -->
<footer class="site-footer">
  <div class="footer-top">
    <div class="footer-col">
      <div class="footer-logo">
        <i class="fas fa-hotel"></i>
        <span>Grand Lake Hotel</span>
      </div>
      <p>Luxury hospitality on the shores of Lake Tana, Bahir Dar, Ethiopia. Your comfort is our passion.</p>
      <div class="social-links">
        <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
        <a href="#" aria-label="TripAdvisor"><i class="fab fa-tripadvisor"></i></a>
      </div>
    </div>

    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="<?= $base ?>index.html">Home</a></li>
        <li><a href="<?= $base ?>home.html">About</a></li>
        <li><a href="<?= $base ?>index.html#rooms">Rooms</a></li>
        <li><a href="<?= $base ?>index.html#food">Food</a></li>
        <li><a href="<?= $base ?>index.html#services">Services</a></li>
        <li><a href="<?= $base ?>index.html#contact">Contact</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Guest Portal</h4>
      <ul>
        <li><a href="<?= $base ?>login.php">Login</a></li>
        <li><a href="<?= $base ?>register.html">Register</a></li>
        <li><a href="<?= $base ?>customer/customer.php">My Bookings</a></li>
        <li><a href="<?= $base ?>profile.php">My Profile</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Newsletter</h4>
      <p>Subscribe for exclusive offers and updates.</p>
      <form class="newsletter-form" onsubmit="event.preventDefault();this.querySelector('input').value='';this.insertAdjacentHTML('afterend','<p style=\'color:var(--accent);font-size:.85rem;margin-top:.5rem;\'>✓ Subscribed!</p>')">
        <input type="email" placeholder="Your email address" required />
        <button type="submit" aria-label="Subscribe"><i class="fas fa-paper-plane"></i></button>
      </form>
    </div>
  </div>

  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> Grand Lake Hotel, Bahir Dar. All rights reserved.</p>
    <p>
      <a href="<?= $base ?>index.html#contact">Contact</a> &nbsp;|&nbsp;
      <a href="<?= $base ?>home.html">About</a>
    </p>
  </div>
</footer>

<!-- Shared JS -->
<script src="<?= $base ?>assets/js/script.js"></script>
</body>
</html>
