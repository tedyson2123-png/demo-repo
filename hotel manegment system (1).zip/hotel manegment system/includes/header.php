<?php
// ============================================================
//  Grand Lake Hotel — Shared HTML Header
//  includes/header.php
//
//  Usage:
//    $pageTitle = 'Page Name';
//    $activePage = 'rooms';   // matches nav link id
//    require_once __DIR__ . '/../includes/header.php';
// ============================================================

if (session_status() === PHP_SESSION_NONE) session_start();

// Resolve base path so assets work from any sub-directory
$depth  = substr_count(str_replace('\\', '/', $_SERVER['SCRIPT_FILENAME']),
                       str_replace('\\', '/', realpath(__DIR__ . '/..')));
$base   = str_repeat('../', max(0, $depth - 1));
$pageTitle  = $pageTitle  ?? 'Grand Lake Hotel';
$activePage = $activePage ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= htmlspecialchars($pageTitle) ?> — Grand Lake Hotel</title>

  <!-- Shared stylesheet -->
  <link rel="stylesheet" href="<?= $base ?>assets/css/style.css" />
  <!-- Font Awesome -->
  <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body>
