<?php
// ============================================================
//  Grand Lake Hotel — Shared Navigation Bar
//  includes/navbar.php
//
//  Requires: session already started, $activePage set.
// ============================================================

$isLoggedIn = isset($_SESSION['user_id']);
$role       = $_SESSION['role'] ?? '';
$fullName   = $_SESSION['full_name'] ?? '';

// Resolve base path
$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_FILENAME']);
$rootPath   = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$relDepth   = substr_count(ltrim(str_replace($rootPath, '', $scriptPath), '/'), '/');
$base       = str_repeat('../', $relDepth);

$activePage = $activePage ?? '';

// Role → dashboard link map
$dashLinks = [
    'admin'       => $base . 'admin/admin.php',
    'reception'   => $base . 'reception/reception.php',
    'manager'     => $base . 'manager/manager.php',
    'maintenance' => $base . 'maintenance/maintenance.php',
    'housekeeper' => $base . 'housekeeper/housekeeper.php',
    'customer'    => $base . 'customer/customer.php',
];
$dashLink = $dashLinks[$role] ?? ($base . 'login.php');
?>

<!-- ── Top Bar ──────────────────────────────────────────── -->
<div class="topbar">
  <div class="topbar-inner">
    <span><i class="fas fa-phone"></i> +251 583 20 9653</span>
    <span><i class="fas fa-envelope"></i> info@grandlakehotel.com</span>
    <span class="topbar-hide-sm"><i class="fas fa-map-marker-alt"></i> Bahir Dar, Ethiopia</span>
    <div class="topbar-links">
      <?php if ($isLoggedIn): ?>
        <a href="<?= $dashLink ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="<?= $base ?>logout.php" class="btn-register">Logout</a>
      <?php else: ?>
        <a href="<?= $base ?>login.php">Login</a>
        <a href="<?= $base ?>register.html" class="btn-register">Register</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- ── Main Header ──────────────────────────────────────── -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="<?= $base ?>index.html" class="logo">
      <div class="logo-icon"><i class="fas fa-hotel"></i></div>
      <div class="logo-text">
        <span class="logo-name">Grand Lake Hotel</span>
        <span class="logo-sub">Bahir Dar, Ethiopia</span>
      </div>
    </a>

    <nav class="main-nav" id="mainNav">
      <a href="<?= $base ?>index.html"   class="<?= $activePage==='home'     ? 'active':'' ?>">Home</a>
      <a href="<?= $base ?>home.html"    class="<?= $activePage==='about'    ? 'active':'' ?>">About</a>
      <a href="<?= $base ?>index.html#rooms"    class="<?= $activePage==='rooms'    ? 'active':'' ?>">Rooms</a>
      <a href="<?= $base ?>index.html#food"     class="<?= $activePage==='food'     ? 'active':'' ?>">Food</a>
      <a href="<?= $base ?>index.html#services" class="<?= $activePage==='services' ? 'active':'' ?>">Services</a>
      <a href="<?= $base ?>index.html#gallery"  class="<?= $activePage==='gallery'  ? 'active':'' ?>">Gallery</a>
      <a href="<?= $base ?>index.html#contact"  class="<?= $activePage==='contact'  ? 'active':'' ?>">Contact</a>
    </nav>

    <a href="<?= $base ?>register.html" class="btn-book">Book Now</a>
    <button class="hamburger" id="hamburger" aria-label="Toggle menu">
      <i class="fas fa-bars"></i>
    </button>
  </div>
</header>
