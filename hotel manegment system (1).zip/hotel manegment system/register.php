<?php
require_once 'connection.php';

if (isLoggedIn()) redirect('index.html');

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name        = escape($conn, $_POST['full_name']        ?? '');
    $username         = escape($conn, $_POST['username']         ?? '');
    $email            = escape($conn, $_POST['email']            ?? '');
    $phone            = escape($conn, $_POST['phone']            ?? '');
    $password         = trim($_POST['password']         ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // Validation
    if (!$full_name)  $errors[] = 'Full name is required.';
    if (!$username)   $errors[] = 'Username is required.';
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm_password) $errors[] = 'Passwords do not match.';

    // Check duplicates
    if (!$errors) {
        $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1");
        $check->bind_param("ss", $username, $email);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $errors[] = 'Username or email already exists.';
        }
        $check->close();
    }

    if (!$errors) {
        $hashed = MD5($password); // Use password_hash() in production
        $role   = 'customer';
        $stmt   = $conn->prepare(
            "INSERT INTO users (full_name, username, email, phone, password, role)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("ssssss", $full_name, $username, $email, $phone, $hashed, $role);

        if ($stmt->execute()) {
            flash('register_success', 'Account created successfully! Please log in.');
            redirect('login.php');
        } else {
            $errors[] = 'Registration failed. Please try again.';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register — Grand Lake Hotel</title>
  <link rel="stylesheet" href="home.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body{background:var(--light)}
    .auth-wrapper{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:2rem 1rem;background:linear-gradient(135deg,var(--primary-d) 0%,#1a4a8a 100%)}
    .auth-card{background:var(--white);border-radius:20px;box-shadow:var(--shadow-lg);width:100%;max-width:520px;overflow:hidden}
    .auth-header{background:linear-gradient(135deg,var(--primary),#1a4a8a);padding:2rem;text-align:center;color:var(--white)}
    .auth-header .logo-icon{margin:0 auto .75rem;width:56px;height:56px;font-size:1.6rem}
    .auth-body{padding:2rem}
    .form-row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
    .form-group{margin-bottom:1.1rem}
    .form-group label{display:block;font-weight:600;color:var(--dark);margin-bottom:.35rem;font-size:.88rem}
    .input-wrap{position:relative}
    .input-wrap i.icon{position:absolute;left:.9rem;top:50%;transform:translateY(-50%);color:var(--gray);font-size:.9rem}
    .input-wrap input{width:100%;padding:.7rem .9rem .7rem 2.5rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.92rem;transition:border-color var(--transition);font-family:inherit}
    .input-wrap input:focus{outline:none;border-color:var(--primary)}
    .btn-auth{width:100%;padding:.85rem;background:var(--primary);color:var(--white);border:none;border-radius:var(--radius);font-size:1rem;font-weight:700;cursor:pointer;transition:background var(--transition);margin-top:.5rem}
    .btn-auth:hover{background:var(--accent);color:var(--dark)}
    .auth-footer{text-align:center;margin-top:1.25rem;font-size:.9rem;color:var(--gray)}
    .auth-footer a{color:var(--primary);font-weight:600}
    .alert{padding:.75rem 1rem;border-radius:var(--radius);margin-bottom:1rem;font-size:.9rem}
    .alert-error{background:#FEE2E2;color:var(--danger);border:1px solid #FECACA}
    .pw-strength{height:4px;border-radius:2px;margin-top:.4rem;transition:all .3s}
    @media(max-width:480px){.form-row{grid-template-columns:1fr}}
  </style>
</head>
<body>
<div class="auth-wrapper">
  <div class="auth-card">
    <div class="auth-header">
      <div class="logo-icon"><i class="fas fa-hotel"></i></div>
      <h2>Create Account</h2>
      <p>Join Grand Lake Hotel and start booking today</p>
    </div>
    <div class="auth-body">
      <?php if ($errors): ?>
        <div class="alert alert-error">
          <i class="fas fa-exclamation-circle"></i>
          <ul style="margin:.5rem 0 0 1rem;">
            <?php foreach ($errors as $e): ?>
              <li><?= htmlspecialchars($e) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <form method="POST" action="register.php">
        <div class="form-row">
          <div class="form-group">
            <label>Full Name</label>
            <div class="input-wrap">
              <i class="fas fa-user icon"></i>
              <input type="text" name="full_name" placeholder="Abebe Girma" required
                     value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" />
            </div>
          </div>
          <div class="form-group">
            <label>Username</label>
            <div class="input-wrap">
              <i class="fas fa-at icon"></i>
              <input type="text" name="username" placeholder="abebe123" required
                     value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" />
            </div>
          </div>
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <div class="input-wrap">
            <i class="fas fa-envelope icon"></i>
            <input type="email" name="email" placeholder="abebe@example.com" required
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" />
          </div>
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <div class="input-wrap">
            <i class="fas fa-phone icon"></i>
            <input type="tel" name="phone" placeholder="+251 9XX XXX XXX"
                   value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" />
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>Password</label>
            <div class="input-wrap">
              <i class="fas fa-lock icon"></i>
              <input type="password" id="pw" name="password" placeholder="Min. 6 characters" required oninput="checkStrength(this.value)" />
            </div>
            <div class="pw-strength" id="pwStrength"></div>
          </div>
          <div class="form-group">
            <label>Confirm Password</label>
            <div class="input-wrap">
              <i class="fas fa-lock icon"></i>
              <input type="password" name="confirm_password" placeholder="Repeat password" required />
            </div>
          </div>
        </div>
        <button type="submit" class="btn-auth">
          <i class="fas fa-user-plus"></i> Create Account
        </button>
      </form>
      <div class="auth-footer">
        Already have an account? <a href="login.php">Sign in</a> &nbsp;|&nbsp; <a href="index.html">Back to Home</a>
      </div>
    </div>
  </div>
</div>
<script>
function checkStrength(val) {
  const bar = document.getElementById('pwStrength');
  if (!val) { bar.style.width='0'; return; }
  let score = 0;
  if (val.length >= 6) score++;
  if (val.length >= 10) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const colors = ['#EF4444','#F97316','#EAB308','#22C55E','#10B981'];
  bar.style.width = (score * 20) + '%';
  bar.style.background = colors[score - 1] || '#EF4444';
}
</script>
</body>
</html>
