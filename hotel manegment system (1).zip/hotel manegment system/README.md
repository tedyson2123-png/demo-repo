# Grand Lake Hotel — Hotel Management System

## Overview

Grand Lake Hotel Management System is a full-featured, web-based hotel management application built for **Grand Lake Hotel** located in **Bahir Dar, Ethiopia**. It provides a complete digital solution for managing all aspects of hotel operations — from guest bookings and room management to housekeeping, maintenance, and financial reporting.

The system is designed around **six distinct user roles**, each with their own dedicated dashboard and set of responsibilities. A public-facing landing page allows visitors to explore the hotel, browse rooms, and register as customers before making bookings online.

The application uses a navy and gold color theme inspired by BDU (Bahir Dar University) branding, giving it a professional and locally relevant aesthetic.

---

## About the Hotel

| Detail | Info |
|---|---|
| **Hotel Name** | Grand Lake Hotel |
| **Location** | Bahir Dar, Ethiopia |
| **Email** | info@grandlakehotel.com |
| **Phone** | +251 583 20 9653 |
| **Currency** | ETB (Ethiopian Birr) |
| **Check-in Time** | 14:00 |
| **Check-out Time** | 12:00 |
| **Max Guests per Booking** | 50 |

---

## Room Types

The hotel offers four categories of rooms across four floors:

| Type | Floors | Capacity | Price Range (ETB) | Description |
|---|---|---|---|---|
| **Single** | 1 | 1 guest | 80 – 85 | Cozy rooms with city or garden views, free Wi-Fi, en-suite bathroom |
| **Double** | 2 | 2 guests | 120 – 125 | Spacious rooms with queen/twin beds, balcony or lake view options |
| **Suite** | 3 | 4 guests | 200 – 220 | Luxury suites with king bed, lounge, jacuzzi, and panoramic lake views |
| **Deluxe** | 4 | 3 guests | 160 – 175 | Premium rooms with king bed, soaking tub, private balcony |

Room statuses tracked in real time: `available`, `booked`, `cleaning`, `maintenance`.

---

## User Roles & Dashboards

The system supports six roles. After login, each user is automatically redirected to their dedicated dashboard.

### 1. Admin
The admin has full control over the entire system.
- **Room Management** — Add, edit, delete rooms; update room status, type, price, floor, capacity, and description
- **Booking Management** — View and manage all bookings across all customers; update booking status
- **User Management** — View all registered users, their roles, and account details
- **Revenue Charts** — Visual charts showing monthly revenue trends and room status distribution
- **System Logs** — View a full audit trail of all user actions (login, bookings, updates) with timestamps and IP addresses
- **System Settings** — Update hotel name, contact info, currency, check-in/check-out times, and max guests

### 2. Customer
Customers can self-register and manage their own bookings.
- **Browse Rooms** — View all available rooms with photos, descriptions, capacity, and pricing
- **Book a Room** — Select check-in/check-out dates using a date picker, specify number of guests, add special requests
- **Booking History** — View all past and current bookings with status indicators
- **Cancel Bookings** — Cancel pending or confirmed bookings
- **Food & Room Service** — Order food from the hotel menu or request room services during their stay
- **Notifications** — Receive in-app notifications for booking confirmations, check-in updates, and more
- **Profile Management** — Update personal details, change password

### 3. Reception
The reception desk manages the physical arrival and departure of guests.
- **Today's Arrivals** — See all guests expected to check in today
- **Today's Departures** — See all guests scheduled to check out today
- **Check-In** — Process guest check-in, update booking status to `checked_in`
- **Check-Out** — Process guest check-out, update booking status to `checked_out`
- **Active Bookings List** — View all currently active (checked-in) guests

### 4. Manager
The manager has a read-only financial and operational overview of the hotel.
- **KPI Dashboard** — Key performance indicators: total revenue, occupancy rate, bookings count, average stay duration
- **Monthly Revenue Chart** — Bar/line chart showing revenue trends month by month
- **Bookings by Room Type** — Pie or bar chart breaking down bookings by single, double, suite, and deluxe
- **Payment History** — Full list of all payments with method (cash, card, bank transfer, mobile money) and status
- **Room Performance** — Which rooms generate the most revenue and have the highest occupancy

### 5. Maintenance
The maintenance team handles all repair and upkeep requests for rooms and facilities.
- **Submit Requests** — Log new maintenance issues with title, description, affected room, and priority level
- **Priority Levels** — `low`, `medium`, `high`, `urgent`
- **Track Status** — Monitor request progress through `open` → `in_progress` → `resolved` → `closed`
- **Assignment** — Requests can be assigned to specific maintenance staff members
- **Resolution Tracking** — Resolved requests are timestamped for reporting

### 6. Housekeeper
The housekeeping team manages room cleanliness and preparation.
- **Task List** — View all assigned housekeeping tasks for the day
- **Task Types** — `cleaning`, `inspection`, `restocking`, `turndown`
- **Start / Complete Tasks** — Update task status from `pending` → `in_progress` → `done`
- **Rooms-to-Clean Grid** — Visual overview of which rooms need attention
- **Scheduled Tasks** — Tasks can be scheduled for future dates (e.g., pre-arrival inspections)

---

## Authentication & Security

- **Registration** — New users register with full name, email, phone, username, and password
- **Login** — Supports login via username or email; role-based redirect after successful authentication
- **Forgot Password** — Two-step email verification flow:
  1. User enters their registered email address
  2. A 6-digit OTP code is sent via email (expires in 15 minutes)
  3. User enters the code and sets a new password
- **Session Management** — PHP sessions with role stored server-side; all protected pages verify role before rendering
- **Logout** — Destroys the session and redirects to the login page
- **System Logs** — Every login and significant action is recorded with user ID, username, action, detail, and IP address

---

## Food & Room Service

The hotel has a built-in food ordering system with a full menu:

| Category | Example Items |
|---|---|
| Breakfast | Full English Breakfast, Continental Breakfast, Pancakes, Avocado Toast |
| Lunch | Club Sandwich, Caesar Salad, Grilled Chicken Wrap, Pasta Carbonara |
| Dinner | Grilled Salmon, Beef Tenderloin, Vegetable Curry, Lamb Chops |
| Snacks | French Fries, Chicken Wings, Cheese Platter |
| Beverages | Fresh Orange Juice, Ethiopian Coffee, Mineral Water, Soft Drinks |
| Desserts | Chocolate Lava Cake, Tiramisu, Fruit Salad |

Customers can place food orders or request room services (extra towels, room cleaning, etc.) linked to their active booking. Orders are tracked through `pending` → `preparing` → `delivered` → `cancelled`.

---

## Payment Methods

The system supports four payment methods:

- **Cash**
- **Card**
- **Bank Transfer**
- **Mobile Money**

Payment records are linked to bookings and tracked with statuses: `pending`, `paid`, `refunded`.

---

## Database Schema

The database (`hotel_management`) contains 12 tables:

| Table | Purpose |
|---|---|
| `users` | All user accounts with roles |
| `rooms` | Room inventory with type, floor, price, status |
| `bookings` | Guest reservations with dates, guests, status |
| `payments` | Payment records linked to bookings |
| `maintenance_requests` | Room repair and issue tracking |
| `housekeeping_tasks` | Cleaning and preparation task management |
| `notifications` | In-app notifications per user |
| `food_menu` | Hotel restaurant menu items |
| `service_orders` | Food and room service orders |
| `password_reset_tokens` | OTP tokens for password recovery |
| `system_logs` | Audit trail of all user actions |
| `system_settings` | Configurable hotel-wide settings |

---

## Project Structure

```
hotel-management-system/
├── connection.php          ← DB connection, session, auth helpers
├── config/
│   └── database.php        ← DB credentials (host, user, pass, name)
├── setup.php               ← Auto database setup & seed data
├── index.html              ← Public landing page (hero, rooms, services, gallery)
├── home.html               ← About page
├── home.css                ← Global stylesheet (navy + gold theme)
├── login.php               ← Login handler + form
├── register.php            ← Registration handler + form
├── forgot_password.php     ← Two-step password reset (email OTP)
├── profile.php             ← User profile & booking history
├── logout.php              ← Session destroy
├── admin/
│   ├── admin.php           ← Admin dashboard (rooms, bookings, users, charts, logs, settings)
│   ├── admin.css
│   └── admin.js
├── customer/
│   ├── customer.php        ← Room browsing, booking, history, cancellation, food orders
│   ├── customer.css
│   └── customer.js
├── reception/
│   ├── reception.php       ← Check-in / check-out management
│   ├── reception.css
│   └── reception.js
├── manager/
│   ├── manager.php         ← Revenue reports, KPIs, charts, payment history
│   ├── manager.css
│   └── manager.js
├── maintenance/
│   ├── maintenance.php     ← Maintenance requests (submit, track, resolve)
│   ├── maintenance.css
│   └── maintenance.js
├── housekeeper/
│   ├── housekeeper.php     ← Housekeeping tasks, room cleaning status
│   ├── housekeeper.css
│   └── housekeeper.js
├── includes/
│   ├── header.php          ← Shared HTML head / header
│   ├── navbar.php          ← Shared navigation bar
│   └── footer.php          ← Shared footer
├── assets/
│   ├── css/style.css       ← Additional global styles
│   ├── js/script.js        ← Additional global scripts
│   └── images/             ← Hotel images and assets
└── database/
    └── hotel-db.sql        ← Full schema + seed data
```

---

## Setup

### Prerequisites
- XAMPP (or any Apache + PHP + MySQL stack)
- PHP 7.4 or higher
- MySQL 5.7+ or MariaDB

### 1. Place the Project
Copy the project folder into your web server root:
```
C:/xampp/htdocs/hotel-management-system/
```

### 2. Configure Database Credentials
Edit `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');          // your MySQL password
define('DB_NAME', 'hotel_management');
```

### 3. Run Setup
Open your browser and navigate to:
```
http://localhost/hotel-managmenet-system/setup.php
```
This will automatically:
- Create the `hotel_management` database
- Create all 12 tables
- Insert default system settings
- Seed demo users, rooms, bookings, payments, and menu items

> **Note:** `connection.php` also auto-detects a missing database on first load and redirects to `setup.php` automatically.

### 4. Open the Application
```
http://localhost/hotel-management-system/
```

---

## use this recomended programer login npage

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Reception | `reception` | `reception123` |
| Manager | `manager` | `manager123` |
| Maintenance | `maintenance` | `maintenance123` |
| Housekeeper | `housekeeper` | `housekeeper123` |
| Customer | `alice` | `alice123` |
| Customer | `bob` | `bob123` |
| Customer | `carol` | `carol123` |

---

## Tech Stack

| Layer | Technology |
|---|---|
| **Frontend** | HTML5, CSS3 (custom, no framework), Vanilla JavaScript |
| **Icons** | Font Awesome 6.5 |
| **Charts** | Chart.js 4 |
| **Backend** | PHP 7.4+ (procedural, no framework) |
| **Database** | MySQL 5.7+ / MariaDB |
| **Server** | Apache (XAMPP recommended) |
| **Architecture** | Role-based MVC-lite with shared connection helper |

---

## Key Design Decisions

- **No external PHP framework** — the entire backend is plain procedural PHP, making it easy to read and deploy on any shared hosting or XAMPP setup without Composer.
- **Role-based access control** — every protected page calls `requireRole()` at the top, ensuring users can only access their own dashboard.
- **Auto-setup** — `setup.php` and the auto-redirect in `connection.php` mean the application self-initialises on first run with no manual SQL import required.
- **Prepared statements** — all database queries that accept user input use `mysqli` prepared statements to prevent SQL injection.
- **Session-based auth** — user identity and role are stored server-side in PHP sessions; no JWT or cookie tokens are used.
- **Audit logging** — the `writeLog()` helper in `connection.php` records every significant action to `system_logs` for admin review.
