<?php
require_once 'connection.php';
requireLogin('login.php');

$user = currentUser();
$success = '';
$error   = '';

// Fetch full user record
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$profile = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = escape($conn, $_POST['full_name'] ?? '');
    $email     = escape($conn, $_POST['email']     ?? '');
    $phone     = escape($conn, $_POST['phone']     ?? '');

    if (!$full_name || !$email) {
        $error = 'Name and email are required.';
    } else {
        $stmt = $conn->prepare("UPDATE users SET full_name=?, email=?, phone=? WHERE id=?");
        $stmt->bind_param("sssi", $full_name, $email, $phone, $user['id']);
        if ($stmt->execute()) {
            $_SESSION['full_name'] = $full_name;
            $_SESSION['email']     = $email;
            $success = 'Profile updated successfully.';
            $profile['full_name'] = $full_name;
            $profile['email']     = $email;
            $profile['phone']     = $phone;
        } else {
            $error = 'Update failed. Please try again.';
        }
        $stmt->close();
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current = MD5(trim($_POST['current_password'] ?? ''));
    $new_pw  = trim($_POST['new_password']     ?? '');
    $confirm = trim($_POST['confirm_password'] ?? '');

    if ($profile['password'] !== $current) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($new_pw) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($new_pw !== $confirm) {
        $error = 'New passwords do not match.';
    } else {
        $hashed = MD5($new_pw);
        $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
        $stmt->bind_param("si", $hashed, $user['id']);
        $stmt->execute() ? $success = 'Password changed successfully.' : $error = 'Failed to change password.';
        $stmt->close();
    }
}

// Fetch booking history
$bookings = $conn->query(
    "SELECT b.*, r.room_no, r.type FROM bookings b
     JOIN rooms r ON r.id = b.room_id
     WHERE b.user_id = {$user['id']}
     ORDER BY b.created_at DESC LIMIT 10"
);

$dashLink = $user['role'] . '/' . $user['role'] . '.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Profile — Grand Lake Hotel</title>
  <link rel="stylesheet" href="home.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    body{background:var(--light)}
    .page-header{background:linear-gradient(135deg,var(--primary-d),#1a4a8a);padding:2rem 1.5rem;color:#fff}
    .page-header .container{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem}
    .page-header h1{font-size:1.6rem}
    .breadcrumb{font-size:.85rem;color:rgba(255,255,255,.7)}
    .breadcrumb a{color:var(--accent)}
    .profile-layout{display:grid;grid-template-columns:280px 1fr;gap:2rem;padding:2rem 0}
    .profile-sidebar{background:var(--white);border-radius:16px;box-shadow:var(--shadow);padding:2rem;text-align:center;height:fit-content}
    .avatar-circle{width:90px;height:90px;background:linear-gradient(135deg,var(--primary),#1a4a8a);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2.5rem;color:var(--white);margin:0 auto 1rem}
    .profile-sidebar h3{color:var(--primary);margin-bottom:.25rem}
    .role-badge{display:inline-block;background:var(--accent);color:var(--dark);font-size:.75rem;font-weight:700;padding:.2rem .7rem;border-radius:50px;text-transform:uppercase;margin-bottom:1rem}
    .sidebar-nav{text-align:left;margin-top:1.5rem}
    .sidebar-nav a{display:flex;align-items:center;gap:.75rem;padding:.65rem 1rem;border-radius:var(--radius);color:var(--gray);font-size:.9rem;transition:all var(--transition);margin-bottom:.25rem}
    .sidebar-nav a:hover,.sidebar-nav a.active{background:var(--primary);color:var(--white)}
    .sidebar-nav i{width:18px;text-align:center}
    .profile-main{}
    .profile-card{background:var(--white);border-radius:16px;box-shadow:var(--shadow);padding:2rem;margin-bottom:1.5rem}
    .profile-card h3{color:var(--primary);margin-bottom:1.5rem;padding-bottom:.75rem;border-bottom:2px solid var(--gray-l);display:flex;align-items:center;gap:.5rem}
    .form-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
    .form-group{margin-bottom:1rem}
    .form-group label{display:block;font-weight:600;font-size:.88rem;color:var(--dark);margin-bottom:.35rem}
    .form-group input{width:100%;padding:.7rem 1rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.92rem;transition:border-color var(--transition)}
    .form-group input:focus{outline:none;border-color:var(--primary)}
    .form-group input[readonly]{background:var(--light);color:var(--gray)}
    .btn-save{background:var(--primary);color:var(--white);border:none;padding:.7rem 2rem;border-radius:var(--radius);font-weight:700;cursor:pointer;transition:background var(--transition)}
    .btn-save:hover{background:var(--accent);color:var(--dark)}
    .alert{padding:.75rem 1rem;border-radius:var(--radius);margin-bottom:1rem;font-size:.9rem}
    .alert-success{background:#D1FAE5;color:var(--success);border:1px solid #A7F3D0}
    .alert-error{background:#FEE2E2;color:var(--danger);border:1px solid #FECACA}
    .booking-table{width:100%;border-collapse:collapse;font-size:.88rem}
    .booking-table th{background:var(--primary);color:var(--white);padding:.65rem 1rem;text-align:left}
    .booking-table td{padding:.65rem 1rem;border-bottom:1px solid var(--gray-l)}
    .booking-table tr:hover td{background:var(--light)}
    .status-badge{display:inline-block;padding:.2rem .6rem;border-radius:50px;font-size:.75rem;font-weight:700}
    .status-confirmed{background:#DBEAFE;color:#1D4ED8}
    .status-checked_in{background:#D1FAE5;color:#065F46}
    .status-checked_out{background:#F3F4F6;color:#374151}
    .status-pending{background:#FEF3C7;color:#92400E}
    .status-cancelled{background:#FEE2E2;color:#991B1B}
    @media(max-width:768px){.profile-layout{grid-template-columns:1fr}.form-grid{grid-template-columns:1fr}}
  </style>
</head>
<body>

<div class="page-header">
  <div class="container">
    <div>
      <h1><i class="fas fa-user-circle"></i> My Profile</h1>
      <p class="breadcrumb"><a href="index.html">Home</a> / <a href="<?= $dashLink ?>">Dashboard</a> / Profile</p>
    </div>
    <a href="logout.php" class="btn-primary" style="font-size:.9rem;padding:.5rem 1.2rem;">
      <i class="fas fa-sign-out-alt"></i> Logout
    </a>
  </div>
</div>

<div class="container">
  <div class="profile-layout">

    <!-- Sidebar -->
    <aside class="profile-sidebar">
      <div class="avatar-circle"><i class="fas fa-user"></i></div>
      <h3><?= htmlspecialchars($profile['full_name']) ?></h3>
      <span class="role-badge"><?= htmlspecialchars($profile['role']) ?></span>
      <p style="color:var(--gray);font-size:.85rem;"><?= htmlspecialchars($profile['email']) ?></p>
      <nav class="sidebar-nav">
        <a href="#profile" class="active"><i class="fas fa-user"></i> Edit Profile</a>
        <a href="#password"><i class="fas fa-lock"></i> Change Password</a>
        <a href="#bookings"><i class="fas fa-calendar-check"></i> My Bookings</a>
        <a href="<?= $dashLink ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </nav>
    </aside>

    <!-- Main -->
    <div class="profile-main">
      <?php if ($success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
      <?php endif; ?>
      <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <!-- Edit Profile -->
      <div class="profile-card" id="profile">
        <h3><i class="fas fa-user-edit"></i> Edit Profile</h3>
        <form method="POST">
          <div class="form-grid">
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" name="full_name" value="<?= htmlspecialchars($profile['full_name']) ?>" required />
            </div>
            <div class="form-group">
              <label>Username</label>
              <input type="text" value="<?= htmlspecialchars($profile['username']) ?>" readonly />
            </div>
            <div class="form-group">
              <label>Email Address</label>
              <input type="email" name="email" value="<?= htmlspecialchars($profile['email']) ?>" required />
            </div>
            <div class="form-group">
              <label>Phone Number</label>
              <input type="tel" name="phone" value="<?= htmlspecialchars($profile['phone'] ?? '') ?>" />
            </div>
          </div>
          <button type="submit" name="update_profile" class="btn-save">
            <i class="fas fa-save"></i> Save Changes
          </button>
        </form>
      </div>

      <!-- Change Password -->
      <div class="profile-card" id="password">
        <h3><i class="fas fa-key"></i> Change Password</h3>
        <form method="POST">
          <div class="form-group">
            <label>Current Password</label>
            <input type="password" name="current_password" required />
          </div>
          <div class="form-grid">
            <div class="form-group">
              <label>New Password</label>
              <input type="password" name="new_password" required />
            </div>
            <div class="form-group">
              <label>Confirm New Password</label>
              <input type="password" name="confirm_password" required />
            </div>
          </div>
          <button type="submit" name="change_password" class="btn-save">
            <i class="fas fa-lock"></i> Update Password
          </button>
        </form>
      </div>

      <!-- Booking History -->
      <div class="profile-card" id="bookings">
        <h3><i class="fas fa-history"></i> Booking History</h3>
        <?php if ($bookings->num_rows === 0): ?>
          <p style="color:var(--gray);text-align:center;padding:2rem;">No bookings found. <a href="customer/customer.php" style="color:var(--primary);">Book a room</a></p>
        <?php else: ?>
          <div style="overflow-x:auto;">
            <table class="booking-table">
              <thead>
                <tr>
                  <th>#</th><th>Room</th><th>Check-in</th><th>Check-out</th>
                  <th>Guests</th><th>Total</th><th>Status</th>
                </tr>
              </thead>
              <tbody>
                <?php while ($b = $bookings->fetch_assoc()): ?>
                  <tr>
                    <td><?= $b['id'] ?></td>
                    <td><?= htmlspecialchars($b['room_no']) ?> (<?= ucfirst($b['type']) ?>)</td>
                    <td><?= $b['check_in'] ?></td>
                    <td><?= $b['check_out'] ?></td>
                    <td><?= $b['guests'] ?></td>
                    <td>$<?= number_format($b['total_price'], 2) ?></td>
                    <td><span class="status-badge status-<?= $b['status'] ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

</body>
</html>
