<?php
// ============================================================
//  Grand Lake Hotel — Room Controller
//  controllers/roomController.php
//
//  Handles all room-related CRUD actions.
//  Called by pages/rooms.php, pages/add_room.php,
//            pages/edit_room.php, pages/delete_room.php
// ============================================================

require_once __DIR__ . '/../connection.php';
require_once __DIR__ . '/../models/Room.php';

class RoomController {

    private Room $model;

    public function __construct() {
        $this->model = new Room();
    }

    // ── List all rooms ────────────────────────────────────
    public function index(): array {
        return $this->model->getAll();
    }

    // ── Show single room ──────────────────────────────────
    public function show(int $id): ?array {
        return $this->model->getById($id);
    }

    // ── Handle Add Room form submission ───────────────────
    public function store(array $post): array {
        $errors = $this->validateRoom($post);
        if ($errors) return ['success' => false, 'errors' => $errors];

        $ok = $this->model->create($post);
        return $ok
            ? ['success' => true,  'message' => "Room {$post['room_no']} added successfully."]
            : ['success' => false, 'errors'  => ['Failed to add room. Please try again.']];
    }

    // ── Handle Edit Room form submission ──────────────────
    public function update(int $id, array $post): array {
        $errors = $this->validateRoom($post, false);
        if ($errors) return ['success' => false, 'errors' => $errors];

        $ok = $this->model->update($id, $post);
        return $ok
            ? ['success' => true,  'message' => 'Room updated successfully.']
            : ['success' => false, 'errors'  => ['Failed to update room.']];
    }

    // ── Handle Delete Room ────────────────────────────────
    public function destroy(int $id): array {
        // Check for active bookings first
        global $conn;
        $active = $conn->query(
            "SELECT COUNT(*) c FROM bookings
             WHERE room_id=$id AND status IN ('pending','confirmed','checked_in')"
        )->fetch_assoc()['c'];

        if ($active > 0) {
            return ['success' => false, 'errors' => ['Cannot delete room with active bookings.']];
        }

        $ok = $this->model->delete($id);
        return $ok
            ? ['success' => true,  'message' => 'Room deleted.']
            : ['success' => false, 'errors'  => ['Failed to delete room.']];
    }

    // ── Update room status ────────────────────────────────
    public function updateStatus(int $id, string $status): array {
        $allowed = ['available', 'booked', 'cleaning', 'maintenance'];
        if (!in_array($status, $allowed)) {
            return ['success' => false, 'errors' => ['Invalid status.']];
        }
        $ok = $this->model->setStatus($id, $status);
        return $ok
            ? ['success' => true,  'message' => 'Room status updated.']
            : ['success' => false, 'errors'  => ['Failed to update status.']];
    }

    // ── Room status counts for dashboard ──────────────────
    public function statusCounts(): array {
        return $this->model->countByStatus();
    }

    // ── Validation ───────────────────────────────────────
    private function validateRoom(array $data, bool $requireRoomNo = true): array {
        $errors = [];
        if ($requireRoomNo && empty(trim($data['room_no'] ?? ''))) {
            $errors[] = 'Room number is required.';
        }
        $validTypes = ['single', 'double', 'suite', 'deluxe'];
        if (!in_array($data['type'] ?? '', $validTypes)) {
            $errors[] = 'Invalid room type.';
        }
        if (!isset($data['floor']) || intval($data['floor']) < 1) {
            $errors[] = 'Floor must be at least 1.';
        }
        if (!isset($data['capacity']) || intval($data['capacity']) < 1) {
            $errors[] = 'Capacity must be at least 1.';
        }
        if (!isset($data['price']) || floatval($data['price']) <= 0) {
            $errors[] = 'Price must be greater than 0.';
        }
        return $errors;
    }
}
