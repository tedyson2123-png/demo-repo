<?php
// ============================================================
//  Grand Lake Hotel — Booking Controller
//  controllers/bookingController.php
//
//  Handles booking creation, status changes, check-in/out.
//  Called by pages/bookings.php, pages/create_booking.php,
//            pages/checkin.php, pages/checkout.php
// ============================================================

require_once __DIR__ . '/../connection.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/Room.php';

class BookingController {

    private Booking $bookingModel;
    private Room    $roomModel;

    public function __construct() {
        $this->bookingModel = new Booking();
        $this->roomModel    = new Room();
    }

    // ── List all bookings ─────────────────────────────────
    public function index(string $status = ''): array {
        return $this->bookingModel->getAll($status);
    }

    // ── Show single booking ───────────────────────────────
    public function show(int $id): ?array {
        return $this->bookingModel->getById($id);
    }

    // ── Create a new booking ──────────────────────────────
    public function store(array $post, int $userId): array {
        $errors = $this->validateBooking($post);
        if ($errors) return ['success' => false, 'errors' => $errors];

        $room = $this->roomModel->getById(intval($post['room_id']));
        if (!$room || $room['status'] !== 'available') {
            return ['success' => false, 'errors' => ['Selected room is not available.']];
        }

        $days  = (strtotime($post['check_out']) - strtotime($post['check_in'])) / 86400;
        $total = $days * $room['price'];

        $bookingId = $this->bookingModel->create([
            'user_id'         => $userId,
            'room_id'         => intval($post['room_id']),
            'check_in'        => $post['check_in'],
            'check_out'       => $post['check_out'],
            'guests'          => intval($post['guests']),
            'total_price'     => $total,
            'special_request' => $post['special_request'] ?? '',
        ]);

        if ($bookingId) {
            $this->roomModel->setStatus(intval($post['room_id']), 'booked');
            $this->notifyGuest($userId,
                "📋 Booking Received: Your booking #$bookingId for Room {$room['room_no']} " .
                "(Check-in: {$post['check_in']} — Check-out: {$post['check_out']}) has been submitted " .
                "and is pending confirmation."
            );
            return [
                'success'    => true,
                'message'    => "Booking #$bookingId created. Total: ETB " . number_format($total, 2),
                'booking_id' => $bookingId,
            ];
        }
        return ['success' => false, 'errors' => ['Failed to create booking.']];
    }

    // ── Confirm a booking ─────────────────────────────────
    public function confirm(int $id): array {
        $booking = $this->bookingModel->getById($id);
        if (!$booking || $booking['status'] !== 'pending') {
            return ['success' => false, 'errors' => ['Booking not found or already processed.']];
        }
        $this->bookingModel->setStatus($id, 'confirmed');
        $this->notifyGuest(
            (int) $booking['user_id'],
            "🎉 Booking Confirmed: Your booking #$id for Room {$booking['room_no']} has been confirmed! " .
            "Check-in: {$booking['check_in']} — Check-out: {$booking['check_out']}."
        );
        return ['success' => true, 'message' => "Booking #$id confirmed."];
    }

    // ── Cancel a booking ──────────────────────────────────
    public function cancel(int $id): array {
        $booking = $this->bookingModel->getById($id);
        if (!$booking || !in_array($booking['status'], ['pending', 'confirmed'])) {
            return ['success' => false, 'errors' => ['Cannot cancel this booking.']];
        }
        $this->bookingModel->setStatus($id, 'cancelled');
        $this->roomModel->setStatus((int) $booking['room_id'], 'available');
        $this->notifyGuest(
            (int) $booking['user_id'],
            "❌ Booking Cancelled: Your booking #$id for Room {$booking['room_no']} has been cancelled."
        );
        return ['success' => true, 'message' => "Booking #$id cancelled."];
    }

    // ── Check-in ──────────────────────────────────────────
    public function checkIn(int $id): array {
        $booking = $this->bookingModel->getById($id);
        if (!$booking || $booking['status'] !== 'confirmed') {
            return ['success' => false, 'errors' => ['Booking not found or not confirmed.']];
        }
        $this->bookingModel->setStatus($id, 'checked_in');
        $this->roomModel->setStatus((int) $booking['room_id'], 'booked');
        $this->notifyGuest(
            (int) $booking['user_id'],
            "✅ Check-in Complete: You have checked in to Room {$booking['room_no']} (Booking #$id). Enjoy your stay!"
        );
        return ['success' => true, 'message' => 'Guest checked in successfully.'];
    }

    // ── Check-out ─────────────────────────────────────────
    public function checkOut(int $id): array {
        $booking = $this->bookingModel->getById($id);
        if (!$booking || $booking['status'] !== 'checked_in') {
            return ['success' => false, 'errors' => ['Booking not found or guest not checked in.']];
        }
        $this->bookingModel->setStatus($id, 'checked_out');
        $this->roomModel->setStatus((int) $booking['room_id'], 'cleaning');
        $this->notifyGuest(
            (int) $booking['user_id'],
            "👋 Check-out Complete: You have checked out from Room {$booking['room_no']} (Booking #$id). Thank you!"
        );
        return ['success' => true, 'message' => 'Guest checked out. Room queued for cleaning.'];
    }

    // ── Today's arrivals & departures ────────────────────
    public function todayArrivals(): array   { return $this->bookingModel->getTodayArrivals(); }
    public function todayDepartures(): array { return $this->bookingModel->getTodayDepartures(); }

    // ── Revenue helpers ───────────────────────────────────
    public function totalRevenue(): float { return $this->bookingModel->getTotalRevenue(); }
    public function monthlyRevenue(int $months = 6): array {
        return $this->bookingModel->getMonthlyRevenue($months);
    }

    // ── Private: send notification to guest ──────────────
    private function notifyGuest(int $userId, string $message): void {
        global $conn;
        $safe = $conn->real_escape_string($message);
        $conn->query("INSERT INTO notifications (user_id, message, is_read) VALUES ($userId, '$safe', 0)");
    }

    // ── Validation ───────────────────────────────────────
    private function validateBooking(array $data): array {
        $errors = [];
        if (empty($data['room_id']))   $errors[] = 'Please select a room.';
        if (empty($data['check_in']))  $errors[] = 'Check-in date is required.';
        if (empty($data['check_out'])) $errors[] = 'Check-out date is required.';
        if (!empty($data['check_in']) && !empty($data['check_out'])) {
            if ($data['check_out'] <= $data['check_in']) {
                $errors[] = 'Check-out must be after check-in.';
            }
        }
        if (empty($data['guests']) || intval($data['guests']) < 1) {
            $errors[] = 'At least 1 guest is required.';
        }
        return $errors;
    }
}
