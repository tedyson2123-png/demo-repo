<?php
// ============================================================
//  Grand Lake Hotel — Customer Controller
//  controllers/customerController.php
//
//  Handles customer listing, search, profile updates.
//  Called by pages/customers.php
// ============================================================

require_once __DIR__ . '/../connection.php';
require_once __DIR__ . '/../models/Customer.php';

class CustomerController {

    private Customer $model;

    public function __construct() {
        $this->model = new Customer();
    }

    // ── List all customers ────────────────────────────────
    public function index(): array {
        return $this->model->getAll();
    }

    // ── Show single customer with stats ──────────────────
    public function show(int $id): ?array {
        return $this->model->getWithStats($id);
    }

    // ── Search customers ──────────────────────────────────
    public function search(string $q): array {
        return $this->model->search($q);
    }

    // ── Update customer profile ───────────────────────────
    public function update(int $id, array $post): array {
        $errors = [];
        if (empty(trim($post['full_name'] ?? ''))) $errors[] = 'Full name is required.';
        if (empty(trim($post['email'] ?? '')) || !filter_var($post['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Valid email is required.';
        }
        if ($errors) return ['success' => false, 'errors' => $errors];

        $ok = $this->model->update($id, $post);
        return $ok
            ? ['success' => true,  'message' => 'Customer profile updated.']
            : ['success' => false, 'errors'  => ['Update failed.']];
    }

    // ── Delete customer ───────────────────────────────────
    public function destroy(int $id): array {
        global $conn;
        // Prevent deleting customers with active bookings
        $active = $conn->query(
            "SELECT COUNT(*) c FROM bookings
             WHERE user_id=$id AND status IN ('pending','confirmed','checked_in')"
        )->fetch_assoc()['c'];

        if ($active > 0) {
            return ['success' => false, 'errors' => ['Cannot delete customer with active bookings.']];
        }

        $ok = $this->model->delete($id);
        return $ok
            ? ['success' => true,  'message' => 'Customer deleted.']
            : ['success' => false, 'errors'  => ['Failed to delete customer.']];
    }

    // ── Currently checked-in guests ───────────────────────
    public function checkedIn(): array {
        return $this->model->getCheckedIn();
    }

    // ── Total customer count ──────────────────────────────
    public function count(): int {
        return $this->model->count();
    }
}
