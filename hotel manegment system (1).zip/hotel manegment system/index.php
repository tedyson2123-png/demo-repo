<?php
// ============================================================
//  Grand Lake Hotel — index.php
//  Entry point: redirects logged-in users to their dashboard,
//  otherwise serves the public home page.
// ============================================================

require_once __DIR__ . '/connection.php';

if (isLoggedIn()) {
    $role = currentUser()['role'];
    $dashLinks = [
        'admin'       => 'admin/admin.php',
        'reception'   => 'reception/reception.php',
        'manager'     => 'manager/manager.php',
        'maintenance' => 'maintenance/maintenance.php',
        'housekeeper' => 'housekeeper/housekeeper.php',
        'customer'    => 'customer/customer.php',
    ];
    redirect($dashLinks[$role] ?? 'index.html');
}

// Not logged in — serve the public home page
header('Location: index.html');
exit;
