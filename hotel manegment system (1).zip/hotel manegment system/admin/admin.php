<?php
require_once '../connection.php';
requireRole('admin', '../login.php');
$user = currentUser();

// ── Database Backup (pure PHP — no mysqldump needed) ─────
if (isset($_GET['backup'])) {
    writeLog('db_backup', 'Admin triggered database backup download.');

    $filename = 'hotel_backup_' . date('Ymd_His') . '.sql';
    header('Content-Type: application/octet-stream');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header('Pragma: no-cache');
    header('Expires: 0');

    $nl = "\n";

    // ── Header comment ────────────────────────────────────
    echo "-- ============================================================$nl";
    echo "--  Grand Lake Hotel — Database Backup$nl";
    echo "--  Database : " . DB_NAME . "$nl";
    echo "--  Generated: " . date('Y-m-d H:i:s') . "$nl";
    echo "--  Server   : " . DB_HOST . "$nl";
    echo "-- ============================================================$nl$nl";
    echo "SET FOREIGN_KEY_CHECKS=0;$nl";
    echo "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';$nl";
    echo "SET NAMES utf8mb4;$nl$nl";

    // ── Get all tables ────────────────────────────────────
    $tables = [];
    $res = $conn->query("SHOW TABLES");
    while ($row = $res->fetch_row()) {
        $tables[] = $row[0];
    }

    foreach ($tables as $table) {
        $safeTable = "`$table`";

        // ── DROP + CREATE TABLE ───────────────────────────
        echo "-- ------------------------------------------------------------$nl";
        echo "-- Table: $table$nl";
        echo "-- ------------------------------------------------------------$nl";
        echo "DROP TABLE IF EXISTS $safeTable;$nl";

        $createRes = $conn->query("SHOW CREATE TABLE $safeTable");
        $createRow = $createRes->fetch_row();
        echo $createRow[1] . ";$nl$nl";

        // ── Row data ──────────────────────────────────────
        $dataRes = $conn->query("SELECT * FROM $safeTable");
        if ($dataRes && $dataRes->num_rows > 0) {
            // Get column names
            $fields = [];
            $fieldInfo = $conn->query("SHOW COLUMNS FROM $safeTable");
            while ($col = $fieldInfo->fetch_assoc()) {
                $fields[] = '`' . $col['Field'] . '`';
            }
            $colList = implode(', ', $fields);

            echo "INSERT INTO $safeTable ($colList) VALUES$nl";
            $rows = [];
            while ($row = $dataRes->fetch_row()) {
                $vals = [];
                foreach ($row as $val) {
                    if ($val === null) {
                        $vals[] = 'NULL';
                    } else {
                        $vals[] = "'" . $conn->real_escape_string($val) . "'";
                    }
                }
                $rows[] = '(' . implode(', ', $vals) . ')';
            }
            echo implode(",$nl", $rows) . ";$nl";
        }
        echo $nl;
    }

    echo "SET FOREIGN_KEY_CHECKS=1;$nl";
    echo "-- ============================================================$nl";
    echo "-- End of backup$nl";
    echo "-- ============================================================$nl";
    exit;
}

// ── Stats ─────────────────────────────────────────────────
$totalRooms    = $conn->query("SELECT COUNT(*) c FROM rooms")->fetch_assoc()['c'];
$availRooms    = $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='available'")->fetch_assoc()['c'];
$totalBookings = $conn->query("SELECT COUNT(*) c FROM bookings")->fetch_assoc()['c'];
$activeGuests  = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='checked_in'")->fetch_assoc()['c'];
$totalRevenue  = $conn->query("SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='paid'")->fetch_assoc()['r'];
$totalUsers    = $conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$openMaint     = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='open'")->fetch_assoc()['c'];
$pendingTasks  = $conn->query("SELECT COUNT(*) c FROM housekeeping_tasks WHERE status='pending'")->fetch_assoc()['c'];

// ── Handle Actions ────────────────────────────────────────
$success = $error = '';

// Add Room
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_room'])) {
    $room_no = escape($conn, $_POST['room_no']);
    $type    = escape($conn, $_POST['type']);
    $floor   = intval($_POST['floor']);
    $cap     = intval($_POST['capacity']);
    $price   = floatval($_POST['price']);
    $desc    = escape($conn, $_POST['description']);

    $stmt = $conn->prepare("INSERT INTO rooms (room_no,type,floor,capacity,price,description) VALUES (?,?,?,?,?,?)");
    $stmt->bind_param("ssiids", $room_no, $type, $floor, $cap, $price, $desc);
    $stmt->execute() ? $success = "Room $room_no added." : $error = "Failed: " . $conn->error;
    $stmt->close();
}

// Delete Room
if (isset($_GET['delete_room'])) {
    $id = intval($_GET['delete_room']);
    $conn->query("DELETE FROM rooms WHERE id=$id");
    $success = 'Room deleted.';
}

// Update booking status
if (isset($_GET['booking_status']) && isset($_GET['bid'])) {
    $bid    = intval($_GET['bid']);
    $status = escape($conn, $_GET['booking_status']);
    $conn->query("UPDATE bookings SET status='$status' WHERE id=$bid");
    $success = 'Booking updated.';
    writeLog('booking_update', "Booking #$bid set to $status");
}

// ── Edit User Role ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
    $uid      = intval($_POST['uid']);
    $role     = escape($conn, $_POST['role']);
    $fullname = escape($conn, $_POST['full_name']);
    $email    = escape($conn, $_POST['email']);
    $phone    = escape($conn, $_POST['phone'] ?? '');
    $allowed  = ['admin','customer','reception','manager','maintenance','housekeeper'];
    if (in_array($role, $allowed)) {
        $conn->query("UPDATE users SET full_name='$fullname', email='$email', phone='$phone', role='$role' WHERE id=$uid");
        $success = 'User updated.';
        writeLog('user_edit', "User #$uid updated: role=$role");
    }
}

// ── Delete User ───────────────────────────────────────────
if (isset($_GET['delete_user'])) {
    $uid = intval($_GET['delete_user']);
    if ($uid !== $user['id']) { // prevent self-delete
        $conn->query("DELETE FROM users WHERE id=$uid");
        $success = 'User deleted.';
        writeLog('user_delete', "User #$uid deleted.");
    } else {
        $error = 'You cannot delete your own account.';
    }
}

// ── System Settings Save ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $fields = ['hotel_name','hotel_email','hotel_phone','hotel_address','hotel_currency','checkin_time','checkout_time','max_guests'];
    foreach ($fields as $key) {
        $val = escape($conn, $_POST[$key] ?? '');
        $conn->query("INSERT INTO system_settings (setting_key, setting_val) VALUES ('$key','$val')
                      ON DUPLICATE KEY UPDATE setting_val='$val'");
    }
    $success = 'Settings saved.';
    writeLog('settings_save', 'System settings updated.');
}

// ── Data ──────────────────────────────────────────────────
$rooms    = $conn->query("SELECT * FROM rooms ORDER BY room_no");
$bookings = $conn->query(
    "SELECT b.*, u.full_name, u.email, r.room_no, r.type
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms r ON r.id=b.room_id
     ORDER BY b.created_at DESC LIMIT 20"
);
$users = $conn->query("SELECT * FROM users ORDER BY created_at DESC");

// Monthly revenue for chart
$monthlyRev = $conn->query(
    "SELECT DATE_FORMAT(paid_at,'%b') mo, SUM(amount) total
     FROM payments WHERE status='paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
     GROUP BY MONTH(paid_at) ORDER BY paid_at"
);
$chartLabels = $chartData = [];
while ($r = $monthlyRev->fetch_assoc()) {
    $chartLabels[] = $r['mo'];
    $chartData[]   = $r['total'];
}

// ── System Settings ───────────────────────────────────────
$settingsRaw = $conn->query("SELECT setting_key, setting_val FROM system_settings");
$settings = [];
if ($settingsRaw) {
    while ($s = $settingsRaw->fetch_assoc()) {
        $settings[$s['setting_key']] = $s['setting_val'];
    }
}

// ── System Logs ───────────────────────────────────────────
$systemLogs = $conn->query(
    "SELECT * FROM system_logs ORDER BY created_at DESC LIMIT 100"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard — Grand Lake Hotel</title>
  <link rel="stylesheet" href="admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body class="dashboard-body">

<!-- Sidebar Overlay -->
<div id="sidebarOverlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:199;" onclick="this.style.display='none';document.getElementById('sidebar').classList.remove('open');"></div>

<!-- ── Sidebar ─────────────────────────────────────────── -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div>
      <div class="brand-name">Grand Lake Hotel</div>
      <div class="brand-role">Admin Panel</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars($user['email']) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Main</div>
    <a href="#dashboard" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="#rooms"><i class="fas fa-bed"></i> Rooms</a>
    <a href="#bookings"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="#users"><i class="fas fa-users"></i> Users</a>
    <div class="nav-section-label">Operations</div>
    <a href="../reception/reception.php"><i class="fas fa-concierge-bell"></i> Reception</a>
    <a href="../housekeeper/housekeeper.php"><i class="fas fa-broom"></i> Housekeeping</a>
    <a href="../maintenance/maintenance.php"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="../manager/manager.php"><i class="fas fa-chart-line"></i> Reports</a>
    <div class="nav-section-label">System</div>
    <a href="#settings"><i class="fas fa-cog"></i> Settings</a>
    <a href="#logs"><i class="fas fa-list-alt"></i> System Logs</a>
    <a href="#" onclick="document.getElementById('backupConfirmModal').style.display='flex';return false;"><i class="fas fa-database"></i> DB Backup</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<!-- ── Main ────────────────────────────────────────────── -->
<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Admin Dashboard</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / Admin</p>
      </div>
    </div>
    <div class="topnav-right">
      <div class="topnav-icon" title="Notifications">
        <i class="fas fa-bell"></i>
        <?php if ($openMaint > 0): ?><span class="notif-dot"></span><?php endif; ?>
      </div>
      <a href="../profile.php" class="topnav-icon" title="Profile"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss="4000"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss="4000"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <style>
      .stat-card-link{text-decoration:none;color:inherit;display:block;border-radius:inherit;transition:transform .18s,box-shadow .18s;}
      .stat-card-link:hover .stat-card{transform:translateY(-4px);box-shadow:0 8px 28px rgba(0,0,0,.13);border-color:var(--primary);cursor:pointer;}
      .stat-card-link:hover .stat-value{color:var(--primary);}
    </style>
    <div class="stats-grid" id="dashboard">
      <a href="#rooms" class="stat-card-link" onclick="document.getElementById('rooms').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fas fa-bed"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $totalRooms ?></div><div class="stat-label">Total Rooms</div></div>
        </div>
      </a>
      <a href="#rooms" class="stat-card-link" onclick="document.getElementById('rooms').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $availRooms ?></div><div class="stat-label">Available Rooms</div></div>
        </div>
      </a>
      <a href="#bookings" class="stat-card-link" onclick="document.getElementById('bookings').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon yellow"><i class="fas fa-calendar-check"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $totalBookings ?></div><div class="stat-label">Total Bookings</div></div>
        </div>
      </a>
      <a href="#bookings" class="stat-card-link" onclick="document.getElementById('bookings').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon teal"><i class="fas fa-user-check"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $activeGuests ?></div><div class="stat-label">Checked In</div></div>
        </div>
      </a>
      <a href="#logs" class="stat-card-link" onclick="document.getElementById('logs').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon purple"><i class="fas fa-money-bill"></i></div>
          <div class="stat-info"><div class="stat-value">ETB <?= number_format($totalRevenue, 0) ?></div><div class="stat-label">Total Revenue</div></div>
        </div>
      </a>
      <a href="#users" class="stat-card-link" onclick="document.getElementById('users').scrollIntoView({behavior:'smooth'})">
        <div class="stat-card">
          <div class="stat-icon red"><i class="fas fa-tools"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $openMaint ?></div><div class="stat-label">Open Maintenance</div></div>
        </div>
      </a>
    </div>

    <!-- Charts Row -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;margin-bottom:1.5rem;">
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-bar"></i> Monthly Revenue</h3></div>
        <div class="card-body"><canvas id="revenueChart" height="120"></canvas></div>
      </div>
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-pie"></i> Room Status</h3></div>
        <div class="card-body"><canvas id="roomChart" height="180"></canvas></div>
      </div>
    </div>

    <!-- Rooms Table -->
    <div class="card" id="rooms">
      <div class="card-header">
        <h3><i class="fas fa-bed"></i> Manage Rooms</h3>
        <button class="btn btn-primary-d btn-sm" onclick="openModal('addRoomModal')">
          <i class="fas fa-plus"></i> Add Room
        </button>
      </div>
      <div class="card-body">
        <input type="text" id="tableSearch" placeholder="Search rooms..." style="padding:.5rem 1rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);margin-bottom:1rem;width:260px;" />
        <div class="table-wrap">
          <table class="data-table searchable-table">
            <thead><tr><th>#</th><th>Room No</th><th>Type</th><th>Floor</th><th>Capacity</th><th>Price/Night</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php $rooms->data_seek(0); while ($r = $rooms->fetch_assoc()): ?>
                <tr>
                  <td><?= $r['id'] ?></td>
                  <td><strong><?= htmlspecialchars($r['room_no']) ?></strong></td>
                  <td><?= ucfirst($r['type']) ?></td>
                  <td><?= $r['floor'] ?></td>
                  <td><?= $r['capacity'] ?></td>
                  <td>ETB <?= number_format($r['price'], 2) ?></td>
                  <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                  <td>
                    <a href="?delete_room=<?= $r['id'] ?>" class="btn btn-danger btn-sm" data-confirm="Delete room <?= htmlspecialchars($r['room_no']) ?>?">
                      <i class="fas fa-trash"></i>
                    </a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Bookings Table -->
    <div class="card" id="bookings">
      <div class="card-header"><h3><i class="fas fa-calendar-check"></i> Recent Bookings</h3></div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              <?php while ($b = $bookings->fetch_assoc()): ?>
                <tr>
                  <td><?= $b['id'] ?></td>
                  <td><?= htmlspecialchars($b['full_name']) ?><br><small style="color:var(--gray)"><?= htmlspecialchars($b['email']) ?></small></td>
                  <td><?= htmlspecialchars($b['room_no']) ?> (<?= ucfirst($b['type']) ?>)</td>
                  <td><?= $b['check_in'] ?></td>
                  <td><?= $b['check_out'] ?></td>
                  <td>ETB <?= number_format($b['total_price'], 2) ?></td>
                  <td><span class="badge badge-<?= $b['status'] ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
                  <td>
                    <?php if ($b['status'] === 'pending'): ?>
                      <a href="?bid=<?= $b['id'] ?>&booking_status=confirmed" class="btn btn-success btn-sm"><i class="fas fa-check"></i></a>
                    <?php endif; ?>
                    <a href="?bid=<?= $b['id'] ?>&booking_status=cancelled" class="btn btn-danger btn-sm" data-confirm="Cancel this booking?"><i class="fas fa-times"></i></a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Users Table -->
    <div class="card" id="users">
      <div class="card-header"><h3><i class="fas fa-users"></i> All Users</h3></div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>#</th><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
              <?php while ($u = $users->fetch_assoc()): ?>
                <tr>
                  <td><?= $u['id'] ?></td>
                  <td><?= htmlspecialchars($u['full_name']) ?></td>
                  <td><?= htmlspecialchars($u['username']) ?></td>
                  <td><?= htmlspecialchars($u['email']) ?></td>
                  <td><?= htmlspecialchars($u['phone'] ?? '—') ?></td>
                  <td><span class="badge badge-confirmed"><?= ucfirst($u['role']) ?></span></td>
                  <td><?= date('M d, Y', strtotime($u['created_at'])) ?></td>
                  <td>
                    <button class="btn btn-accent btn-sm"
                      onclick="openEditUser(<?= $u['id'] ?>, '<?= htmlspecialchars(addslashes($u['full_name'])) ?>', '<?= htmlspecialchars(addslashes($u['email'])) ?>', '<?= htmlspecialchars(addslashes($u['phone'] ?? '')) ?>', '<?= $u['role'] ?>')">
                      <i class="fas fa-edit"></i>
                    </button>
                    <?php if ($u['id'] !== $user['id']): ?>
                    <a href="?delete_user=<?= $u['id'] ?>" class="btn btn-danger btn-sm"
                       data-confirm="Delete user <?= htmlspecialchars($u['username']) ?>?">
                      <i class="fas fa-trash"></i>
                    </a>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ── System Settings ─────────────────────────────── -->
    <div class="card" id="settings">
      <div class="card-header"><h3><i class="fas fa-cog"></i> System Settings</h3></div>
      <div class="card-body">
        <form method="POST">
          <div class="form-grid-2">
            <?php
            $labels = [
              'hotel_name'    => 'Hotel Name',
              'hotel_email'   => 'Contact Email',
              'hotel_phone'   => 'Contact Phone',
              'hotel_address' => 'Address',
              'hotel_currency'=> 'Currency Code',
              'checkin_time'  => 'Check-in Time',
              'checkout_time' => 'Check-out Time',
              'max_guests'    => 'Max Guests per Room',
            ];
            foreach ($labels as $key => $label):
            ?>
            <div class="form-group">
              <label><?= $label ?></label>
              <input type="text" name="<?= $key ?>"
                     value="<?= htmlspecialchars($settings[$key] ?? '') ?>"
                     placeholder="<?= $label ?>" />
            </div>
            <?php endforeach; ?>
          </div>
          <button type="submit" name="save_settings" class="btn btn-primary-d">
            <i class="fas fa-save"></i> Save Settings
          </button>
        </form>
      </div>
    </div>

    <!-- ── System Logs ─────────────────────────────────── -->
    <div class="card" id="logs">
      <div class="card-header">
        <h3><i class="fas fa-list-alt"></i> System Logs</h3>
        <input type="text" id="logSearch" placeholder="Search logs..."
               style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;"
               oninput="filterLogs(this.value)" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table" id="logsTable">
            <thead><tr><th>#</th><th>User</th><th>Action</th><th>Detail</th><th>IP</th><th>Time</th></tr></thead>
            <tbody>
              <?php if ($systemLogs): while ($l = $systemLogs->fetch_assoc()): ?>
              <tr>
                <td><?= $l['id'] ?></td>
                <td><?= htmlspecialchars($l['username'] ?? '—') ?></td>
                <td><span class="badge badge-confirmed"><?= htmlspecialchars($l['action']) ?></span></td>
                <td style="max-width:300px;font-size:.82rem;"><?= htmlspecialchars($l['detail'] ?? '—') ?></td>
                <td><?= htmlspecialchars($l['ip_address'] ?? '—') ?></td>
                <td><?= $l['created_at'] ?></td>
              </tr>
              <?php endwhile; else: ?>
              <tr><td colspan="6" style="text-align:center;color:var(--gray);padding:2rem;">No logs yet.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div><!-- /page-content -->
</div><!-- /main-content -->

<!-- ── Add Room Modal ─────────────────────────────────── --><div class="modal-overlay" id="addRoomModal">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-plus-circle"></i> Add New Room</h3>
      <button class="modal-close" onclick="closeModal('addRoomModal')">&times;</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-grid-2">
          <div class="form-group">
            <label>Room Number</label>
            <input type="text" name="room_no" placeholder="e.g. 105" required />
          </div>
          <div class="form-group">
            <label>Type</label>
            <select name="type" required>
              <option value="single">Single</option>
              <option value="double">Double</option>
              <option value="suite">Suite</option>
              <option value="deluxe">Deluxe</option>
            </select>
          </div>
          <div class="form-group">
            <label>Floor</label>
            <input type="number" name="floor" min="1" value="1" required />
          </div>
          <div class="form-group">
            <label>Capacity</label>
            <input type="number" name="capacity" min="1" max="10" value="2" required />
          </div>
          <div class="form-group">
            <label>Price per Night (ETB)</label>
            <input type="number" name="price" step="0.01" min="0" placeholder="120.00" required />
          </div>
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea name="description" rows="3" placeholder="Room description..."></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-d" onclick="closeModal('addRoomModal')">Cancel</button>
        <button type="submit" name="add_room" class="btn btn-primary-d"><i class="fas fa-save"></i> Save Room</button>
      </div>
    </form>
  </div>
</div>

<script src="admin.js"></script>
<script>
// Revenue chart
drawBarChart('revenueChart',
  <?= json_encode($chartLabels) ?>,
  <?= json_encode($chartData) ?>,
  'Revenue (ETB)'
);
// Room status doughnut
drawDoughnut('roomChart',
  ['Available','Booked','Cleaning','Maintenance'],
  [
    <?= $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='available'")->fetch_assoc()['c'] ?>,
    <?= $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='booked'")->fetch_assoc()['c'] ?>,
    <?= $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='cleaning'")->fetch_assoc()['c'] ?>,
    <?= $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='maintenance'")->fetch_assoc()['c'] ?>
  ]
);

// Edit User modal
function openEditUser(id, name, email, phone, role) {
  document.getElementById('eu_uid').value   = id;
  document.getElementById('eu_name').value  = name;
  document.getElementById('eu_email').value = email;
  document.getElementById('eu_phone').value = phone;
  document.getElementById('eu_role').value  = role;
  openModal('editUserModal');
}

// Log search
function filterLogs(q) {
  q = q.toLowerCase();
  document.querySelectorAll('#logsTable tbody tr').forEach(r => {
    r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}
</script>

<!-- ── Edit User Modal ────────────────────────────────── -->
<div class="modal-overlay" id="editUserModal">
  <div class="modal">
    <div class="modal-header">
      <h3><i class="fas fa-user-edit"></i> Edit User</h3>
      <button class="modal-close" onclick="closeModal('editUserModal')">&times;</button>
    </div>
    <form method="POST">
      <input type="hidden" name="uid" id="eu_uid" />
      <div class="modal-body">
        <div class="form-grid-2">
          <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" id="eu_name" required />
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" id="eu_email" required />
          </div>
          <div class="form-group">
            <label>Phone</label>
            <input type="tel" name="phone" id="eu_phone" />
          </div>
          <div class="form-group">
            <label>Role</label>
            <select name="role" id="eu_role" required>
              <option value="admin">Admin</option>
              <option value="reception">Reception</option>
              <option value="manager">Manager</option>
              <option value="maintenance">Maintenance</option>
              <option value="housekeeper">Housekeeper</option>
              <option value="customer">Customer</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-d" onclick="closeModal('editUserModal')">Cancel</button>
        <button type="submit" name="edit_user" class="btn btn-primary-d"><i class="fas fa-save"></i> Save Changes</button>
      </div>
    </form>
  </div>
</div>

<!-- ── DB Backup Confirm Modal ────────────────────────── -->
<div id="backupConfirmModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:9999;align-items:center;justify-content:center;">
  <div style="background:#fff;border-radius:18px;padding:2.5rem 2rem;max-width:420px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,.25);text-align:center;">
    <div style="width:64px;height:64px;background:linear-gradient(135deg,#1a56db,#1e429f);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.25rem;">
      <i class="fas fa-database" style="color:#fff;font-size:1.6rem;"></i>
    </div>
    <h3 style="font-size:1.2rem;color:#1e293b;margin-bottom:.5rem;">Download Database Backup</h3>
    <p style="color:#64748b;font-size:.92rem;margin-bottom:.4rem;">
      This will export all tables and data from <strong><?= DB_NAME ?></strong> as a <code>.sql</code> file.
    </p>
    <p style="color:#64748b;font-size:.88rem;margin-bottom:1.75rem;">
      Generated: <strong><?= date('d M Y, H:i') ?></strong>
    </p>
    <div style="display:flex;gap:1rem;justify-content:center;">
      <button onclick="document.getElementById('backupConfirmModal').style.display='none'"
              style="padding:.7rem 1.75rem;border:2px solid #e2e8f0;border-radius:10px;background:#fff;color:#64748b;font-weight:600;cursor:pointer;font-size:.95rem;">
        Cancel
      </button>
      <a href="?backup=1"
         onclick="document.getElementById('backupConfirmModal').style.display='none'"
         style="padding:.7rem 1.75rem;border-radius:10px;background:linear-gradient(135deg,#1a56db,#1e429f);color:#fff;font-weight:700;text-decoration:none;font-size:.95rem;display:inline-flex;align-items:center;gap:.5rem;">
        <i class="fas fa-download"></i> Download Backup
      </a>
    </div>
  </div>
</div>
</body>
</html>
