// ── Sidebar Toggle ────────────────────────────────────────
const sidebar   = document.getElementById('sidebar');
const hamburger = document.getElementById('hamburgerDash');
const overlay   = document.getElementById('sidebarOverlay');

if (hamburger) {
  hamburger.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    if (overlay) overlay.classList.toggle('show');
  });
}
if (overlay) {
  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });
}

// ── Modal Helpers ─────────────────────────────────────────
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('open');
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('open');
}
// Close modal on overlay click
document.querySelectorAll('.modal-overlay').forEach(m => {
  m.addEventListener('click', e => {
    if (e.target === m) m.classList.remove('open');
  });
});

// ── Alert Auto-dismiss ────────────────────────────────────
document.querySelectorAll('.alert[data-dismiss]').forEach(el => {
  setTimeout(() => el.style.display = 'none', parseInt(el.dataset.dismiss) || 4000);
});

// ── Confirm Delete ────────────────────────────────────────
document.querySelectorAll('[data-confirm]').forEach(el => {
  el.addEventListener('click', e => {
    if (!confirm(el.dataset.confirm || 'Are you sure?')) e.preventDefault();
  });
});

// ── Table Search ──────────────────────────────────────────
const tableSearch = document.getElementById('tableSearch');
if (tableSearch) {
  tableSearch.addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.searchable-table tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

// ── Date defaults ─────────────────────────────────────────
const today = new Date().toISOString().split('T')[0];
document.querySelectorAll('input[type="date"]').forEach(i => {
  if (!i.min) i.min = today;
});

// ── Nights calculator ─────────────────────────────────────
const checkIn  = document.getElementById('check_in');
const checkOut = document.getElementById('check_out');
const nightsEl = document.getElementById('nights_display');
const totalEl  = document.getElementById('total_display');
const priceEl  = document.getElementById('room_price');

function calcNights() {
  if (!checkIn || !checkOut || !nightsEl) return;
  const d1 = new Date(checkIn.value);
  const d2 = new Date(checkOut.value);
  if (d2 > d1) {
    const nights = Math.ceil((d2 - d1) / 86400000);
    nightsEl.textContent = nights + ' night' + (nights > 1 ? 's' : '');
    if (totalEl && priceEl) {
      const price = parseFloat(priceEl.value) || 0;
      totalEl.textContent = 'ETB ' + (nights * price).toFixed(2);
    }
  }
}
if (checkIn)  checkIn.addEventListener('change',  calcNights);
if (checkOut) checkOut.addEventListener('change', calcNights);

// ── Room price auto-fill ──────────────────────────────────
const roomSelect = document.getElementById('room_id');
if (roomSelect && priceEl) {
  roomSelect.addEventListener('change', function () {
    const opt = this.options[this.selectedIndex];
    if (opt && opt.dataset.price) {
      priceEl.value = opt.dataset.price;
      calcNights();
    }
  });
}

// ── Charts (if Chart.js is loaded) ───────────────────────
function drawBarChart(canvasId, labels, data, label) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || typeof Chart === 'undefined') return;
  new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label,
        data,
        backgroundColor: 'rgba(0,53,128,.7)',
        borderRadius: 6,
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

function drawDoughnut(canvasId, labels, data) {
  const canvas = document.getElementById(canvasId);
  if (!canvas || typeof Chart === 'undefined') return;
  new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data,
        backgroundColor: ['#003580','#C8A951','#10B981','#EF4444','#6366F1'],
        borderWidth: 0,
      }]
    },
    options: { responsive: true, cutout: '65%' }
  });
}
