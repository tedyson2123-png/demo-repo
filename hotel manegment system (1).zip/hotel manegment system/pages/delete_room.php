<?php
// ============================================================
//  Grand Lake Hotel — Delete Room Page
//  pages/delete_room.php
//
//  Shows a confirmation page before deleting a room.
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: rooms.php'); exit; }

$room = $conn->query("SELECT * FROM rooms WHERE id=$id LIMIT 1")->fetch_assoc();
if (!$room) { header('Location: rooms.php'); exit; }

$error = '';

// Check for active bookings
$activeBookings = $conn->query(
    "SELECT COUNT(*) c FROM bookings WHERE room_id=$id AND status IN ('pending','confirmed','checked_in')"
)->fetch_assoc()['c'];

// Handle confirmed deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    if ($activeBookings > 0) {
        $error = 'Cannot delete room with active bookings. Please cancel or complete them first.';
    } else {
        $conn->query("DELETE FROM rooms WHERE id=$id");
        header('Location: rooms.php?deleted=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Delete Room — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Delete Room</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php" class="active"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Delete Room</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / <a href="rooms.php">Rooms</a> / Delete</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="rooms.php" class="btn btn-outline-d btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($error): ?>
      <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="card" style="max-width:560px;">
      <div class="card-header">
        <h3 style="color:var(--danger);"><i class="fas fa-exclamation-triangle"></i> Confirm Deletion</h3>
      </div>
      <div class="card-body">

        <!-- Room summary -->
        <div style="background:var(--light);border-radius:12px;padding:1.25rem;margin-bottom:1.5rem;border:2px solid var(--gray-l);">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.75rem;">
            <h4 style="color:var(--primary);font-size:1.1rem;">Room <?= htmlspecialchars($room['room_no']) ?></h4>
            <span class="badge badge-<?= $room['status'] ?>"><?= ucfirst($room['status']) ?></span>
          </div>
          <p style="color:var(--gray);font-size:.9rem;margin:0;">
            <strong>Type:</strong> <?= ucfirst($room['type']) ?> &nbsp;|&nbsp;
            <strong>Floor:</strong> <?= $room['floor'] ?> &nbsp;|&nbsp;
            <strong>Capacity:</strong> <?= $room['capacity'] ?> guests &nbsp;|&nbsp;
            <strong>Price:</strong> ETB <?= number_format($room['price'], 2) ?>/night
          </p>
        </div>

        <?php if ($activeBookings > 0): ?>
          <div class="alert alert-warning" style="display:flex;">
            <i class="fas fa-exclamation-triangle"></i>
            <span>This room has <strong><?= $activeBookings ?> active booking(s)</strong>. You must cancel or complete them before deleting this room.</span>
          </div>
          <a href="rooms.php" class="btn btn-outline-d"><i class="fas fa-arrow-left"></i> Back to Rooms</a>
        <?php else: ?>
          <div class="alert alert-error" style="display:flex;">
            <i class="fas fa-exclamation-circle"></i>
            <span>This action is <strong>permanent and cannot be undone</strong>. All data associated with this room will be deleted.</span>
          </div>
          <form method="POST" style="display:flex;gap:1rem;margin-top:1rem;">
            <button type="submit" name="confirm_delete" class="btn btn-danger">
              <i class="fas fa-trash"></i> Yes, Delete Room
            </button>
            <a href="rooms.php" class="btn btn-outline-d">Cancel</a>
          </form>
        <?php endif; ?>

      </div>
    </div>
  </div>
</div>

<script src="../admin/admin.js"></script>
</body>
</html>
