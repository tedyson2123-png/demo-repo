<?php
// ============================================================
//  Grand Lake Hotel — Bookings Management Page
//  pages/bookings.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';

// ── Handle status actions ─────────────────────────────────
if (isset($_GET['action'], $_GET['bid'])) {
    $bid    = intval($_GET['bid']);
    $action = escape($conn, $_GET['action']);

    $booking = $conn->query(
        "SELECT b.*, r.room_id, r.room_no, b.user_id
         FROM bookings b JOIN rooms r ON r.id=b.room_id
         WHERE b.id=$bid LIMIT 1"
    )->fetch_assoc();

    if ($booking) {
        $notifyGuest = function(int $uid, string $msg) use ($conn): void {
            $safe = $conn->real_escape_string($msg);
            $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ($uid,'$safe',0)");
        };

        switch ($action) {
            case 'confirm':
                if ($booking['status'] === 'pending') {
                    $conn->query("UPDATE bookings SET status='confirmed' WHERE id=$bid");
                    $notifyGuest((int)$booking['user_id'],
                        "🎉 Booking #$bid confirmed! Check-in: {$booking['check_in']}.");
                    $success = "Booking #$bid confirmed.";
                }
                break;
            case 'cancel':
                if (in_array($booking['status'], ['pending','confirmed'])) {
                    $conn->query("UPDATE bookings SET status='cancelled' WHERE id=$bid");
                    $conn->query("UPDATE rooms SET status='available' WHERE id={$booking['room_id']}");
                    $notifyGuest((int)$booking['user_id'],
                        "❌ Booking #$bid has been cancelled.");
                    $success = "Booking #$bid cancelled.";
                }
                break;
            case 'checkin':
                if ($booking['status'] === 'confirmed') {
                    $conn->query("UPDATE bookings SET status='checked_in' WHERE id=$bid");
                    $notifyGuest((int)$booking['user_id'],
                        "✅ Checked in to Room {$booking['room_no']} (Booking #$bid). Enjoy your stay!");
                    $success = 'Guest checked in.';
                }
                break;
            case 'checkout':
                if ($booking['status'] === 'checked_in') {
                    $conn->query("UPDATE bookings SET status='checked_out' WHERE id=$bid");
                    $conn->query("UPDATE rooms SET status='cleaning' WHERE id={$booking['room_id']}");
                    $notifyGuest((int)$booking['user_id'],
                        "👋 Checked out from Room {$booking['room_no']} (Booking #$bid). Thank you!");
                    $success = 'Guest checked out. Room queued for cleaning.';
                }
                break;
        }
    }
}

// ── Filter ────────────────────────────────────────────────
$filterStatus = escape($conn, $_GET['status'] ?? '');
$where = $filterStatus ? "WHERE b.status='$filterStatus'" : '';

$bookings = $conn->query(
    "SELECT b.*, u.full_name, u.email, u.phone, r.room_no, r.type
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     $where
     ORDER BY b.created_at DESC"
);

// Stats
$stats = [];
foreach (['pending','confirmed','checked_in','checked_out','cancelled'] as $s) {
    $stats[$s] = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='$s'")->fetch_assoc()['c'];
}
$totalRevenue = $conn->query("SELECT COALESCE(SUM(total_price),0) r FROM bookings WHERE status NOT IN ('cancelled')")->fetch_assoc()['r'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bookings — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Bookings</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php" class="active"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="create_booking.php"><i class="fas fa-calendar-plus"></i> New Booking</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="checkin.php"><i class="fas fa-sign-in-alt"></i> Check-in</a>
    <a href="checkout.php"><i class="fas fa-sign-out-alt"></i> Check-out</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Booking Management</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / Bookings</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="create_booking.php" class="btn btn-primary-d btn-sm"><i class="fas fa-plus"></i> New Booking</a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-clock"></i></div><div class="stat-info"><div class="stat-value"><?= $stats['pending'] ?></div><div class="stat-label">Pending</div></div></div>
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-check"></i></div><div class="stat-info"><div class="stat-value"><?= $stats['confirmed'] ?></div><div class="stat-label">Confirmed</div></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-sign-in-alt"></i></div><div class="stat-info"><div class="stat-value"><?= $stats['checked_in'] ?></div><div class="stat-label">Checked In</div></div></div>
      <div class="stat-card"><div class="stat-icon teal"><i class="fas fa-sign-out-alt"></i></div><div class="stat-info"><div class="stat-value"><?= $stats['checked_out'] ?></div><div class="stat-label">Checked Out</div></div></div>
      <div class="stat-card"><div class="stat-icon red"><i class="fas fa-times"></i></div><div class="stat-info"><div class="stat-value"><?= $stats['cancelled'] ?></div><div class="stat-label">Cancelled</div></div></div>
      <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-money-bill"></i></div><div class="stat-info"><div class="stat-value">ETB <?= number_format($totalRevenue, 0) ?></div><div class="stat-label">Total Revenue</div></div></div>
    </div>

    <!-- Filter Tabs -->
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem;">
      <?php
      $tabs = [''=> 'All', 'pending'=>'Pending', 'confirmed'=>'Confirmed', 'checked_in'=>'Checked In', 'checked_out'=>'Checked Out', 'cancelled'=>'Cancelled'];
      foreach ($tabs as $val => $label):
        $active = $filterStatus === $val ? 'background:var(--primary);color:#fff;border-color:var(--primary);' : '';
      ?>
        <a href="?status=<?= $val ?>"
           style="padding:.4rem 1rem;border:1.5px solid var(--gray-l);border-radius:20px;font-size:.82rem;font-weight:600;color:var(--primary);text-decoration:none;transition:all .2s;<?= $active ?>">
          <?= $label ?>
          <?php if ($val && $stats[$val] > 0): ?>
            <span style="background:rgba(255,255,255,.25);border-radius:10px;padding:0 5px;font-size:.7rem;"><?= $stats[$val] ?></span>
          <?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- Bookings Table -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-list"></i> Bookings (<?= $bookings->num_rows ?>)</h3>
        <input type="text" id="tableSearch" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table searchable-table">
            <thead>
              <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Guests</th><th>Total (ETB)</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php while ($b = $bookings->fetch_assoc()): ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td>
                  <strong><?= htmlspecialchars($b['full_name']) ?></strong><br>
                  <small style="color:var(--gray)"><?= htmlspecialchars($b['email']) ?></small>
                </td>
                <td><?= htmlspecialchars($b['room_no']) ?> <small>(<?= ucfirst($b['type']) ?>)</small></td>
                <td><?= $b['check_in'] ?></td>
                <td><?= $b['check_out'] ?></td>
                <td><?= $b['guests'] ?></td>
                <td><?= number_format($b['total_price'], 2) ?></td>
                <td><span class="badge badge-<?= $b['status'] ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
                <td style="white-space:nowrap;">
                  <?php if ($b['status'] === 'pending'): ?>
                    <a href="?action=confirm&bid=<?= $b['id'] ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i></a>
                    <a href="?action=cancel&bid=<?= $b['id'] ?>"  class="btn btn-danger  btn-sm" data-confirm="Cancel booking #<?= $b['id'] ?>?"><i class="fas fa-times"></i></a>
                  <?php elseif ($b['status'] === 'confirmed'): ?>
                    <a href="?action=checkin&bid=<?= $b['id'] ?>" class="btn btn-primary-d btn-sm"><i class="fas fa-sign-in-alt"></i></a>
                    <a href="?action=cancel&bid=<?= $b['id'] ?>"  class="btn btn-danger   btn-sm" data-confirm="Cancel booking #<?= $b['id'] ?>?"><i class="fas fa-times"></i></a>
                  <?php elseif ($b['status'] === 'checked_in'): ?>
                    <a href="?action=checkout&bid=<?= $b['id'] ?>" class="btn btn-accent btn-sm"><i class="fas fa-sign-out-alt"></i></a>
                  <?php else: ?>
                    <span style="color:var(--gray);font-size:.8rem;">—</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
</body>
</html>
