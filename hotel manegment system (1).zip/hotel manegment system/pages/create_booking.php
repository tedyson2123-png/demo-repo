<?php
// ============================================================
//  Grand Lake Hotel — Create Booking Page (Staff)
//  pages/create_booking.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';
$errors  = [];

// ── Handle form submission ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id  = intval($_POST['user_id']  ?? 0);
    $room_id  = intval($_POST['room_id']  ?? 0);
    $check_in = escape($conn, $_POST['check_in']  ?? '');
    $check_out= escape($conn, $_POST['check_out'] ?? '');
    $guests   = intval($_POST['guests']   ?? 1);
    $special  = escape($conn, $_POST['special_request'] ?? '');

    if (!$user_id)   $errors[] = 'Please select a customer.';
    if (!$room_id)   $errors[] = 'Please select a room.';
    if (!$check_in)  $errors[] = 'Check-in date is required.';
    if (!$check_out) $errors[] = 'Check-out date is required.';
    if ($check_out <= $check_in) $errors[] = 'Check-out must be after check-in.';

    if (!$errors) {
        $room = $conn->query("SELECT * FROM rooms WHERE id=$room_id AND status='available' LIMIT 1")->fetch_assoc();
        if (!$room) {
            $errors[] = 'Selected room is not available.';
        } else {
            $days  = (strtotime($check_out) - strtotime($check_in)) / 86400;
            $total = $days * $room['price'];

            $stmt = $conn->prepare(
                "INSERT INTO bookings (user_id,room_id,check_in,check_out,guests,total_price,special_request,status)
                 VALUES (?,?,?,?,?,?,'?','confirmed')"
            );
            // Use direct query for simplicity with confirmed status
            $safeSpecial = $conn->real_escape_string($special);
            $ok = $conn->query(
                "INSERT INTO bookings (user_id,room_id,check_in,check_out,guests,total_price,special_request,status)
                 VALUES ($user_id,$room_id,'$check_in','$check_out',$guests,$total,'$safeSpecial','confirmed')"
            );
            if ($ok) {
                $bid = $conn->insert_id;
                $conn->query("UPDATE rooms SET status='booked' WHERE id=$room_id");
                $safeMsg = $conn->real_escape_string(
                    "🎉 Booking #$bid confirmed for Room {$room['room_no']}. Check-in: $check_in — Check-out: $check_out."
                );
                $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ($user_id,'$safeMsg',0)");
                $success = "Booking #$bid created and confirmed. Total: ETB " . number_format($total, 2);
            } else {
                $errors[] = 'Failed to create booking: ' . $conn->error;
            }
        }
    }
}

// ── Data for form ─────────────────────────────────────────
$customers = $conn->query("SELECT id, full_name, email FROM users WHERE role='customer' ORDER BY full_name");
$availRooms = $conn->query("SELECT * FROM rooms WHERE status='available' ORDER BY type, room_no");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Create Booking — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">New Booking</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="create_booking.php" class="active"><i class="fas fa-calendar-plus"></i> New Booking</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Create New Booking</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / <a href="bookings.php">Bookings</a> / New</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="bookings.php" class="btn btn-outline-d btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?>
      <div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
      <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <ul style="margin:.5rem 0 0 1rem;">
          <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="card" style="max-width:700px;">
      <div class="card-header">
        <h3><i class="fas fa-calendar-plus"></i> Booking Details</h3>
      </div>
      <div class="card-body">
        <form method="POST">
          <div class="form-group">
            <label>Customer <span style="color:var(--danger)">*</span></label>
            <select name="user_id" required>
              <option value="">Select customer...</option>
              <?php while ($c = $customers->fetch_assoc()): ?>
                <option value="<?= $c['id'] ?>" <?= ($_POST['user_id'] ?? '')==$c['id']?'selected':'' ?>>
                  <?= htmlspecialchars($c['full_name']) ?> (<?= htmlspecialchars($c['email']) ?>)
                </option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="form-group">
            <label>Room <span style="color:var(--danger)">*</span></label>
            <select name="room_id" id="room_id" required onchange="updatePrice(this)">
              <option value="">Select available room...</option>
              <?php while ($r = $availRooms->fetch_assoc()): ?>
                <option value="<?= $r['id'] ?>" data-price="<?= $r['price'] ?>"
                        <?= ($_POST['room_id'] ?? '')==$r['id']?'selected':'' ?>>
                  Room <?= htmlspecialchars($r['room_no']) ?> — <?= ucfirst($r['type']) ?> — Floor <?= $r['floor'] ?> — ETB <?= number_format($r['price'],2) ?>/night
                </option>
              <?php endwhile; ?>
            </select>
          </div>
          <div class="form-grid-2">
            <div class="form-group">
              <label>Check-in Date <span style="color:var(--danger)">*</span></label>
              <input type="date" id="check_in" name="check_in" required
                     value="<?= htmlspecialchars($_POST['check_in'] ?? '') ?>" />
            </div>
            <div class="form-group">
              <label>Check-out Date <span style="color:var(--danger)">*</span></label>
              <input type="date" id="check_out" name="check_out" required
                     value="<?= htmlspecialchars($_POST['check_out'] ?? '') ?>" />
            </div>
            <div class="form-group">
              <label>Number of Guests <span style="color:var(--danger)">*</span></label>
              <input type="number" name="guests" min="1" max="10" value="<?= htmlspecialchars($_POST['guests'] ?? '1') ?>" required />
            </div>
            <div class="form-group">
              <label>Estimated Total</label>
              <div style="background:var(--light);padding:.7rem 1rem;border-radius:var(--radius);font-weight:700;color:var(--primary);" id="totalDisplay">
                Select room and dates
              </div>
            </div>
          </div>
          <div class="form-group">
            <label>Special Requests</label>
            <textarea name="special_request" rows="2" placeholder="e.g. early check-in, extra pillows..."><?= htmlspecialchars($_POST['special_request'] ?? '') ?></textarea>
          </div>
          <div style="display:flex;gap:1rem;margin-top:.5rem;">
            <button type="submit" class="btn btn-primary-d"><i class="fas fa-calendar-plus"></i> Create Booking</button>
            <a href="bookings.php" class="btn btn-outline-d">Cancel</a>
          </div>
        </form>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
<script>
const today = new Date().toISOString().split('T')[0];
document.getElementById('check_in').min  = today;
document.getElementById('check_out').min = today;

function updatePrice(sel) {
  calcTotal();
}

function calcTotal() {
  const sel = document.getElementById('room_id');
  const opt = sel.options[sel.selectedIndex];
  const price = parseFloat(opt?.dataset?.price || 0);
  const d1 = new Date(document.getElementById('check_in').value);
  const d2 = new Date(document.getElementById('check_out').value);
  const el = document.getElementById('totalDisplay');
  if (price > 0 && d2 > d1) {
    const nights = Math.ceil((d2 - d1) / 86400000);
    el.textContent = 'ETB ' + (nights * price).toFixed(2) + ' (' + nights + ' night' + (nights > 1 ? 's' : '') + ')';
  } else {
    el.textContent = 'Select room and dates';
  }
}

document.getElementById('check_in').addEventListener('change', calcTotal);
document.getElementById('check_out').addEventListener('change', calcTotal);
</script>
</body>
</html>
