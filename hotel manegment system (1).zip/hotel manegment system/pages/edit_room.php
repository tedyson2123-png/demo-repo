<?php
// ============================================================
//  Grand Lake Hotel — Edit Room Page
//  pages/edit_room.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user   = currentUser();
$errors = [];
$success = '';

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: rooms.php'); exit; }

$room = $conn->query("SELECT * FROM rooms WHERE id=$id LIMIT 1")->fetch_assoc();
if (!$room) { header('Location: rooms.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type    = escape($conn, $_POST['type']    ?? '');
    $floor   = intval($_POST['floor']    ?? 1);
    $cap     = intval($_POST['capacity'] ?? 1);
    $price   = floatval($_POST['price']  ?? 0);
    $desc    = escape($conn, $_POST['description'] ?? '');
    $status  = escape($conn, $_POST['status'] ?? 'available');

    if (!in_array($type, ['single','double','suite','deluxe'])) $errors[] = 'Invalid room type.';
    if ($floor < 1)  $errors[] = 'Floor must be at least 1.';
    if ($cap < 1)    $errors[] = 'Capacity must be at least 1.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';

    if (!$errors) {
        $stmt = $conn->prepare(
            "UPDATE rooms SET type=?, floor=?, capacity=?, price=?, description=?, status=? WHERE id=?"
        );
        $stmt->bind_param("siidssi", $type, $floor, $cap, $price, $desc, $status, $id);
        if ($stmt->execute()) {
            $success = 'Room updated successfully.';
            $room = $conn->query("SELECT * FROM rooms WHERE id=$id LIMIT 1")->fetch_assoc();
        } else {
            $errors[] = 'Update failed: ' . $conn->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Edit Room <?= htmlspecialchars($room['room_no']) ?> — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Edit Room</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php" class="active"><i class="fas fa-bed"></i> Rooms</a>
    <a href="add_room.php"><i class="fas fa-plus-circle"></i> Add Room</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Edit Room <?= htmlspecialchars($room['room_no']) ?></h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / <a href="rooms.php">Rooms</a> / Edit</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="rooms.php" class="btn btn-outline-d btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?>
      <div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
      <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <ul style="margin:.5rem 0 0 1rem;">
          <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="card" style="max-width:700px;">
      <div class="card-header">
        <h3><i class="fas fa-edit"></i> Room <?= htmlspecialchars($room['room_no']) ?> Details</h3>
        <span class="badge badge-<?= $room['status'] ?>"><?= ucfirst($room['status']) ?></span>
      </div>
      <div class="card-body">
        <form method="POST">
          <div class="form-grid-2">
            <div class="form-group">
              <label>Room Number</label>
              <input type="text" value="<?= htmlspecialchars($room['room_no']) ?>" readonly
                     style="background:var(--light);color:var(--gray);" />
            </div>
            <div class="form-group">
              <label>Room Type <span style="color:var(--danger)">*</span></label>
              <select name="type" required>
                <?php foreach (['single','double','suite','deluxe'] as $t): ?>
                  <option value="<?= $t ?>" <?= $room['type']===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Floor <span style="color:var(--danger)">*</span></label>
              <input type="number" name="floor" min="1" max="20" value="<?= $room['floor'] ?>" required />
            </div>
            <div class="form-group">
              <label>Capacity <span style="color:var(--danger)">*</span></label>
              <input type="number" name="capacity" min="1" max="10" value="<?= $room['capacity'] ?>" required />
            </div>
            <div class="form-group">
              <label>Price per Night (ETB) <span style="color:var(--danger)">*</span></label>
              <input type="number" name="price" step="0.01" min="1" value="<?= $room['price'] ?>" required />
            </div>
            <div class="form-group">
              <label>Status</label>
              <select name="status">
                <?php foreach (['available','booked','cleaning','maintenance'] as $s): ?>
                  <option value="<?= $s ?>" <?= $room['status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" rows="3"><?= htmlspecialchars($room['description'] ?? '') ?></textarea>
          </div>
          <div style="display:flex;gap:1rem;margin-top:.5rem;">
            <button type="submit" class="btn btn-primary-d"><i class="fas fa-save"></i> Save Changes</button>
            <a href="rooms.php" class="btn btn-outline-d">Cancel</a>
            <a href="delete_room.php?id=<?= $room['id'] ?>" class="btn btn-danger"
               data-confirm="Delete room <?= htmlspecialchars($room['room_no']) ?>? This cannot be undone.">
              <i class="fas fa-trash"></i> Delete Room
            </a>
          </div>
        </form>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
</body>
</html>
