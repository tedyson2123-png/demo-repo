<?php
// ============================================================
//  Grand Lake Hotel — Rooms Management Page
//  pages/rooms.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';

// ── Handle status update ──────────────────────────────────
if (isset($_GET['set_status'], $_GET['rid'])) {
    $rid    = intval($_GET['rid']);
    $status = escape($conn, $_GET['set_status']);
    $allowed = ['available','booked','cleaning','maintenance'];
    if (in_array($status, $allowed)) {
        $conn->query("UPDATE rooms SET status='$status' WHERE id=$rid");
        $success = 'Room status updated.';
    }
}

// ── Handle delete ─────────────────────────────────────────
if (isset($_GET['delete'])) {
    $rid = intval($_GET['delete']);
    $active = $conn->query("SELECT COUNT(*) c FROM bookings WHERE room_id=$rid AND status IN ('pending','confirmed','checked_in')")->fetch_assoc()['c'];
    if ($active > 0) {
        $error = 'Cannot delete room with active bookings.';
    } else {
        $conn->query("DELETE FROM rooms WHERE id=$rid");
        $success = 'Room deleted.';
    }
}

// ── Filter ────────────────────────────────────────────────
$filterStatus = escape($conn, $_GET['status'] ?? '');
$filterType   = escape($conn, $_GET['type']   ?? '');
$where = [];
if ($filterStatus) $where[] = "status='$filterStatus'";
if ($filterType)   $where[] = "type='$filterType'";
$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$rooms = $conn->query("SELECT * FROM rooms $whereSQL ORDER BY floor ASC, room_no ASC");

// Stats
$stats = [];
foreach (['available','booked','cleaning','maintenance'] as $s) {
    $stats[$s] = $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='$s'")->fetch_assoc()['c'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Rooms — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Room Management</div></div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars(ucfirst($user['role'])) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php" class="active"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Room Actions</div>
    <a href="add_room.php"><i class="fas fa-plus-circle"></i> Add Room</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Room Management</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / Rooms</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="add_room.php" class="btn btn-primary-d btn-sm"><i class="fas fa-plus"></i> Add Room</a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid">
      <?php foreach (['available'=>['green','check-circle'],'booked'=>['blue','user-check'],'cleaning'=>['yellow','broom'],'maintenance'=>['red','tools']] as $s=>[$color,$icon]): ?>
      <div class="stat-card">
        <div class="stat-icon <?= $color ?>"><i class="fas fa-<?= $icon ?>"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $stats[$s] ?></div><div class="stat-label"><?= ucfirst($s) ?></div></div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Filters -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-filter"></i> Filter Rooms</h3>
      </div>
      <div class="card-body">
        <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end;">
          <div class="form-group" style="margin:0;min-width:160px;">
            <label>Status</label>
            <select name="status">
              <option value="">All Statuses</option>
              <?php foreach (['available','booked','cleaning','maintenance'] as $s): ?>
                <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="margin:0;min-width:160px;">
            <label>Type</label>
            <select name="type">
              <option value="">All Types</option>
              <?php foreach (['single','double','suite','deluxe'] as $t): ?>
                <option value="<?= $t ?>" <?= $filterType===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <button type="submit" class="btn btn-primary-d"><i class="fas fa-search"></i> Filter</button>
          <a href="rooms.php" class="btn btn-outline-d">Clear</a>
        </form>
      </div>
    </div>

    <!-- Rooms Table -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-bed"></i> All Rooms (<?= $rooms->num_rows ?>)</h3>
        <input type="text" id="tableSearch" placeholder="Search rooms..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table searchable-table">
            <thead>
              <tr><th>#</th><th>Room No</th><th>Type</th><th>Floor</th><th>Capacity</th><th>Price/Night</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php while ($r = $rooms->fetch_assoc()): ?>
              <tr>
                <td><?= $r['id'] ?></td>
                <td><strong><?= htmlspecialchars($r['room_no']) ?></strong></td>
                <td><?= ucfirst($r['type']) ?></td>
                <td><?= $r['floor'] ?></td>
                <td><?= $r['capacity'] ?></td>
                <td>ETB <?= number_format($r['price'], 2) ?></td>
                <td><span class="badge badge-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                <td style="white-space:nowrap;">
                  <a href="edit_room.php?id=<?= $r['id'] ?>" class="btn btn-accent btn-sm"><i class="fas fa-edit"></i> Edit</a>
                  <a href="delete_room.php?id=<?= $r['id'] ?>" class="btn btn-danger btn-sm"
                     data-confirm="Delete room <?= htmlspecialchars($r['room_no']) ?>?">
                    <i class="fas fa-trash"></i>
                  </a>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
</body>
</html>
