<?php
// ============================================================
//  Grand Lake Hotel — Reports Page
//  pages/reports.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user = currentUser();

// ── KPI Stats ─────────────────────────────────────────────
$totalRevenue  = $conn->query("SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='paid'")->fetch_assoc()['r'];
$monthRevenue  = $conn->query("SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='paid' AND MONTH(paid_at)=MONTH(NOW()) AND YEAR(paid_at)=YEAR(NOW())")->fetch_assoc()['r'];
$totalBookings = $conn->query("SELECT COUNT(*) c FROM bookings")->fetch_assoc()['c'];
$totalRooms    = $conn->query("SELECT COUNT(*) c FROM rooms")->fetch_assoc()['c'];
$activeGuests  = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='checked_in'")->fetch_assoc()['c'];
$occupancyRate = $totalRooms > 0 ? round(($activeGuests / $totalRooms) * 100) : 0;
$avgStay       = $conn->query("SELECT ROUND(AVG(DATEDIFF(check_out,check_in)),1) a FROM bookings WHERE status='checked_out'")->fetch_assoc()['a'];
$cancelRate    = $conn->query("SELECT ROUND(SUM(status='cancelled')*100/COUNT(*),1) r FROM bookings")->fetch_assoc()['r'];
$totalCustomers= $conn->query("SELECT COUNT(*) c FROM users WHERE role='customer'")->fetch_assoc()['c'];

// ── Date range filter ─────────────────────────────────────
$dateFrom = escape($conn, $_GET['from'] ?? date('Y-m-01'));
$dateTo   = escape($conn, $_GET['to']   ?? date('Y-m-d'));

// ── Revenue in range ──────────────────────────────────────
$rangeRevenue = $conn->query(
    "SELECT COALESCE(SUM(amount),0) r FROM payments
     WHERE status='paid' AND DATE(paid_at) BETWEEN '$dateFrom' AND '$dateTo'"
)->fetch_assoc()['r'];

$rangeBookings = $conn->query(
    "SELECT COUNT(*) c FROM bookings WHERE DATE(created_at) BETWEEN '$dateFrom' AND '$dateTo'"
)->fetch_assoc()['c'];

$rangeCancelled = $conn->query(
    "SELECT COUNT(*) c FROM bookings WHERE status='cancelled' AND DATE(created_at) BETWEEN '$dateFrom' AND '$dateTo'"
)->fetch_assoc()['c'];

// ── Monthly Revenue (last 6 months) ──────────────────────
$monthlyRev = $conn->query(
    "SELECT DATE_FORMAT(paid_at,'%b %Y') mo, SUM(amount) total
     FROM payments WHERE status='paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
     GROUP BY YEAR(paid_at), MONTH(paid_at) ORDER BY paid_at"
);
$revLabels = $revData = [];
while ($row = $monthlyRev->fetch_assoc()) {
    $revLabels[] = $row['mo'];
    $revData[]   = round($row['total'], 2);
}

// ── Bookings by room type ─────────────────────────────────
$byType = $conn->query("SELECT r.type, COUNT(*) c FROM bookings b JOIN rooms r ON r.id=b.room_id GROUP BY r.type");
$typeLabels = $typeData = [];
while ($row = $byType->fetch_assoc()) {
    $typeLabels[] = ucfirst($row['type']);
    $typeData[]   = $row['c'];
}

// ── Bookings by status ────────────────────────────────────
$byStatus = $conn->query("SELECT status, COUNT(*) c FROM bookings GROUP BY status");
$statusLabels = $statusData = [];
while ($row = $byStatus->fetch_assoc()) {
    $statusLabels[] = ucfirst(str_replace('_',' ',$row['status']));
    $statusData[]   = $row['c'];
}

// ── Recent payments ───────────────────────────────────────
$payments = $conn->query(
    "SELECT p.*, u.full_name, r.room_no
     FROM payments p
     JOIN bookings b ON b.id=p.booking_id
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     ORDER BY p.created_at DESC LIMIT 20"
);

// ── Top rooms by revenue ──────────────────────────────────
$topRooms = $conn->query(
    "SELECT r.room_no, r.type, COUNT(b.id) bookings, COALESCE(SUM(b.total_price),0) revenue
     FROM rooms r LEFT JOIN bookings b ON b.room_id=r.id
     GROUP BY r.id ORDER BY revenue DESC LIMIT 10"
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Reports — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Reports</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php" class="active"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Reports &amp; Analytics</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / Reports</p>
      </div>
    </div>
    <div class="topnav-right">
      <span style="font-size:.82rem;color:var(--gray);"><?= date('D, d M Y') ?></span>
    </div>
  </div>

  <div class="page-content">

    <!-- KPI Cards -->
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-money-bill"></i></div><div class="stat-info"><div class="stat-value">ETB <?= number_format($totalRevenue, 0) ?></div><div class="stat-label">Total Revenue</div></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-calendar-alt"></i></div><div class="stat-info"><div class="stat-value">ETB <?= number_format($monthRevenue, 0) ?></div><div class="stat-label">This Month</div></div></div>
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-calendar-check"></i></div><div class="stat-info"><div class="stat-value"><?= $totalBookings ?></div><div class="stat-label">Total Bookings</div></div></div>
      <div class="stat-card"><div class="stat-icon teal"><i class="fas fa-percentage"></i></div><div class="stat-info"><div class="stat-value"><?= $occupancyRate ?>%</div><div class="stat-label">Occupancy Rate</div></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-moon"></i></div><div class="stat-info"><div class="stat-value"><?= $avgStay ?></div><div class="stat-label">Avg. Stay (nights)</div></div></div>
      <div class="stat-card"><div class="stat-icon red"><i class="fas fa-times-circle"></i></div><div class="stat-info"><div class="stat-value"><?= $cancelRate ?>%</div><div class="stat-label">Cancellation Rate</div></div></div>
    </div>

    <!-- Date Range Filter -->
    <div class="card">
      <div class="card-header"><h3><i class="fas fa-calendar-alt"></i> Date Range Report</h3></div>
      <div class="card-body">
        <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end;margin-bottom:1.5rem;">
          <div class="form-group" style="margin:0;">
            <label>From</label>
            <input type="date" name="from" value="<?= htmlspecialchars($dateFrom) ?>" />
          </div>
          <div class="form-group" style="margin:0;">
            <label>To</label>
            <input type="date" name="to" value="<?= htmlspecialchars($dateTo) ?>" />
          </div>
          <button type="submit" class="btn btn-primary-d"><i class="fas fa-search"></i> Generate</button>
        </form>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;">
          <div style="background:linear-gradient(135deg,#D1FAE5,#ECFDF5);border-radius:14px;padding:1.5rem;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:#065F46;">ETB <?= number_format($rangeRevenue, 0) ?></div>
            <div style="font-size:.82rem;color:var(--gray);">Revenue in Range</div>
          </div>
          <div style="background:linear-gradient(135deg,#DBEAFE,#EFF6FF);border-radius:14px;padding:1.5rem;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:#1D4ED8;"><?= $rangeBookings ?></div>
            <div style="font-size:.82rem;color:var(--gray);">New Bookings</div>
          </div>
          <div style="background:linear-gradient(135deg,#FEE2E2,#FFF5F5);border-radius:14px;padding:1.5rem;text-align:center;">
            <div style="font-size:1.8rem;font-weight:800;color:#991B1B;"><?= $rangeCancelled ?></div>
            <div style="font-size:.82rem;color:var(--gray);">Cancellations</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Charts -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1.5rem;margin-bottom:1.5rem;">
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-line"></i> Monthly Revenue (Last 6 Months)</h3></div>
        <div class="card-body"><canvas id="revChart" height="140"></canvas></div>
      </div>
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-bar"></i> Bookings by Room Type</h3></div>
        <div class="card-body"><canvas id="typeChart" height="140"></canvas></div>
      </div>
    </div>

    <!-- Payments Table -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-credit-card"></i> Recent Payments</h3>
        <input type="text" id="tableSearch" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table searchable-table">
            <thead><tr><th>#</th><th>Guest</th><th>Room</th><th>Amount (ETB)</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              <?php while ($p = $payments->fetch_assoc()): ?>
              <tr>
                <td><?= $p['id'] ?></td>
                <td><?= htmlspecialchars($p['full_name']) ?></td>
                <td><?= htmlspecialchars($p['room_no']) ?></td>
                <td><?= number_format($p['amount'], 2) ?></td>
                <td><?= ucfirst(str_replace('_',' ',$p['method'])) ?></td>
                <td><span class="badge badge-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                <td><?= $p['paid_at'] ? date('d M Y H:i', strtotime($p['paid_at'])) : '—' ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Room Performance -->
    <div class="card">
      <div class="card-header"><h3><i class="fas fa-bed"></i> Room Performance</h3></div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead><tr><th>Room No</th><th>Type</th><th>Total Bookings</th><th>Revenue Generated (ETB)</th></tr></thead>
            <tbody>
              <?php while ($r = $topRooms->fetch_assoc()): ?>
              <tr>
                <td><strong><?= htmlspecialchars($r['room_no']) ?></strong></td>
                <td><?= ucfirst($r['type']) ?></td>
                <td><?= $r['bookings'] ?></td>
                <td><?= number_format($r['revenue'], 2) ?></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
<script>
(function() {
  const c1 = document.getElementById('revChart');
  if (c1) new Chart(c1, {
    type: 'line',
    data: {
      labels: <?= json_encode($revLabels) ?>,
      datasets: [{ label: 'Revenue (ETB)', data: <?= json_encode($revData) ?>,
        borderColor: '#C8A951', backgroundColor: 'rgba(200,169,81,.1)', tension: .4, fill: true }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });

  const c2 = document.getElementById('typeChart');
  if (c2) new Chart(c2, {
    type: 'bar',
    data: {
      labels: <?= json_encode($typeLabels) ?>,
      datasets: [{ label: 'Bookings', data: <?= json_encode($typeData) ?>,
        backgroundColor: 'rgba(0,53,128,.7)', borderRadius: 6 }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });
})();
</script>
</body>
</html>
