<?php
// ============================================================
//  Grand Lake Hotel — Main Dashboard Page
//  pages/dashboard.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user = currentUser();

// ── KPI Stats ─────────────────────────────────────────────
$totalRooms    = $conn->query("SELECT COUNT(*) c FROM rooms")->fetch_assoc()['c'];
$availRooms    = $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='available'")->fetch_assoc()['c'];
$totalBookings = $conn->query("SELECT COUNT(*) c FROM bookings")->fetch_assoc()['c'];
$activeGuests  = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='checked_in'")->fetch_assoc()['c'];
$totalRevenue  = $conn->query("SELECT COALESCE(SUM(amount),0) r FROM payments WHERE status='paid'")->fetch_assoc()['r'];
$totalCustomers= $conn->query("SELECT COUNT(*) c FROM users WHERE role='customer'")->fetch_assoc()['c'];
$openMaint     = $conn->query("SELECT COUNT(*) c FROM maintenance_requests WHERE status='open'")->fetch_assoc()['c'];
$pendingTasks  = $conn->query("SELECT COUNT(*) c FROM housekeeping_tasks WHERE status='pending'")->fetch_assoc()['c'];
$pendingBookings = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='pending'")->fetch_assoc()['c'];
$todayArrivals = $conn->query("SELECT COUNT(*) c FROM bookings WHERE check_in=CURDATE() AND status='confirmed'")->fetch_assoc()['c'];
$todayDepartures = $conn->query("SELECT COUNT(*) c FROM bookings WHERE check_out=CURDATE() AND status='checked_in'")->fetch_assoc()['c'];
$occupancyRate = $totalRooms > 0 ? round(($activeGuests / $totalRooms) * 100) : 0;

// ── Monthly Revenue (last 6 months) ──────────────────────
$monthlyRev = $conn->query(
    "SELECT DATE_FORMAT(paid_at,'%b') mo, SUM(amount) total
     FROM payments WHERE status='paid' AND paid_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
     GROUP BY MONTH(paid_at) ORDER BY paid_at"
);
$chartLabels = $chartData = [];
while ($r = $monthlyRev->fetch_assoc()) {
    $chartLabels[] = $r['mo'];
    $chartData[]   = round($r['total'], 2);
}

// ── Recent bookings ───────────────────────────────────────
$recentBookings = $conn->query(
    "SELECT b.*, u.full_name, r.room_no, r.type
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     ORDER BY b.created_at DESC LIMIT 8"
);

// ── Room status counts ────────────────────────────────────
$roomCounts = [];
foreach (['available','booked','cleaning','maintenance'] as $s) {
    $roomCounts[$s] = $conn->query("SELECT COUNT(*) c FROM rooms WHERE status='$s'")->fetch_assoc()['c'];
}

$pageTitle  = 'Dashboard';
$activePage = 'dashboard';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div>
      <div class="brand-name">Grand Lake Hotel</div>
      <div class="brand-role">System Dashboard</div>
    </div>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><i class="fas fa-user-shield"></i></div>
    <div>
      <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
      <div class="user-email"><?= htmlspecialchars(ucfirst($user['role'])) ?></div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Overview</div>
    <a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings
      <?php if ($pendingBookings > 0): ?><span class="badge"><?= $pendingBookings ?></span><?php endif; ?>
    </a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Operations</div>
    <a href="checkin.php"><i class="fas fa-sign-in-alt"></i> Check-in
      <?php if ($todayArrivals > 0): ?><span class="badge"><?= $todayArrivals ?></span><?php endif; ?>
    </a>
    <a href="checkout.php"><i class="fas fa-sign-out-alt"></i> Check-out
      <?php if ($todayDepartures > 0): ?><span class="badge"><?= $todayDepartures ?></span><?php endif; ?>
    </a>
    <a href="add_room.php"><i class="fas fa-plus-circle"></i> Add Room</a>
    <a href="create_booking.php"><i class="fas fa-calendar-plus"></i> New Booking</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
    <a href="../index.html"><i class="fas fa-home"></i> Hotel Home</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>System Dashboard</h2>
        <p class="breadcrumb"><a href="../index.html">Home</a> / Dashboard</p>
      </div>
    </div>
    <div class="topnav-right">
      <span style="font-size:.82rem;color:var(--gray);"><?= date('D, d M Y') ?></span>
      <a href="../profile.php" class="topnav-icon"><i class="fas fa-user"></i></a>
    </div>
  </div>

  <div class="page-content">

    <!-- Welcome Banner -->
    <div style="background:linear-gradient(135deg,var(--primary-d),#1a4a8a);border-radius:18px;padding:2rem 2.5rem;margin-bottom:2rem;display:flex;align-items:center;justify-content:space-between;color:#fff;">
      <div>
        <h2 style="color:#fff;font-size:1.5rem;margin-bottom:.35rem;">
          Welcome back, <span style="color:var(--accent)"><?= htmlspecialchars(explode(' ', $user['full_name'])[0]) ?></span> 👋
        </h2>
        <p style="color:rgba(255,255,255,.7);font-size:.92rem;">
          Here's your hotel overview for <?= date('l, d F Y') ?>
        </p>
      </div>
      <div style="font-size:4rem;color:rgba(200,169,81,.3);"><i class="fas fa-hotel"></i></div>
    </div>

    <!-- KPI Stats -->
    <style>
      .stat-card-link {
        text-decoration: none;
        color: inherit;
        display: block;
        border-radius: inherit;
        transition: transform .18s, box-shadow .18s;
      }
      .stat-card-link:hover .stat-card {
        transform: translateY(-4px);
        box-shadow: 0 8px 28px rgba(0,0,0,.13);
        border-color: var(--primary);
        cursor: pointer;
      }
      .stat-card-link:hover .stat-value {
        color: var(--primary);
      }
    </style>
    <div class="stats-grid">
      <a href="rooms.php" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fas fa-bed"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $totalRooms ?></div><div class="stat-label">Total Rooms</div></div>
        </div>
      </a>
      <a href="rooms.php?status=available" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $availRooms ?></div><div class="stat-label">Available Rooms</div></div>
        </div>
      </a>
      <a href="bookings.php" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon yellow"><i class="fas fa-calendar-check"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $totalBookings ?></div><div class="stat-label">Total Bookings</div></div>
        </div>
      </a>
      <a href="checkin.php" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon teal"><i class="fas fa-user-check"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $activeGuests ?></div><div class="stat-label">Checked In</div></div>
        </div>
      </a>
      <a href="reports.php" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon purple"><i class="fas fa-money-bill"></i></div>
          <div class="stat-info"><div class="stat-value">ETB <?= number_format($totalRevenue, 0) ?></div><div class="stat-label">Total Revenue</div></div>
        </div>
      </a>
      <a href="customers.php" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon blue"><i class="fas fa-users"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $totalCustomers ?></div><div class="stat-label">Customers</div></div>
        </div>
      </a>
      <a href="bookings.php?status=open_maintenance" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon red"><i class="fas fa-tools"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $openMaint ?></div><div class="stat-label">Open Maintenance</div></div>
        </div>
      </a>
      <a href="rooms.php" class="stat-card-link">
        <div class="stat-card">
          <div class="stat-icon yellow"><i class="fas fa-percentage"></i></div>
          <div class="stat-info"><div class="stat-value"><?= $occupancyRate ?>%</div><div class="stat-label">Occupancy Rate</div></div>
        </div>
      </a>
    </div>

    <!-- Charts Row -->
    <div style="display:grid;grid-template-columns:2fr 1fr;gap:1.5rem;margin-bottom:1.5rem;">
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-bar"></i> Monthly Revenue (Last 6 Months)</h3></div>
        <div class="card-body"><canvas id="revenueChart" height="120"></canvas></div>
      </div>
      <div class="card">
        <div class="card-header"><h3><i class="fas fa-chart-pie"></i> Room Status</h3></div>
        <div class="card-body"><canvas id="roomChart" height="180"></canvas></div>
      </div>
    </div>

    <!-- Quick Actions -->
    <div class="card" style="margin-bottom:1.5rem;">
      <div class="card-header"><h3><i class="fas fa-bolt"></i> Quick Actions</h3></div>
      <div class="card-body">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:1rem;">
          <?php
          $actions = [
            ['checkin.php',        'fa-sign-in-alt',    'Check-in',      'blue'],
            ['checkout.php',       'fa-sign-out-alt',   'Check-out',     'yellow'],
            ['create_booking.php', 'fa-calendar-plus',  'New Booking',   'green'],
            ['add_room.php',       'fa-plus-circle',    'Add Room',      'teal'],
            ['customers.php',      'fa-users',          'Customers',     'purple'],
            ['reports.php',        'fa-chart-bar',      'Reports',       'red'],
          ];
          foreach ($actions as [$href, $icon, $label, $color]):
          ?>
          <a href="<?= $href ?>" style="display:flex;flex-direction:column;align-items:center;gap:.75rem;padding:1.5rem 1rem;background:var(--light);border-radius:14px;border:2px solid var(--gray-l);text-decoration:none;color:var(--primary);font-weight:700;font-size:.88rem;transition:all .2s;text-align:center;"
             onmouseover="this.style.background='var(--primary)';this.style.color='#fff';this.style.borderColor='var(--primary)'"
             onmouseout="this.style.background='var(--light)';this.style.color='var(--primary)';this.style.borderColor='var(--gray-l)'">
            <div class="stat-icon <?= $color ?>" style="margin:0;"><i class="fas <?= $icon ?>"></i></div>
            <?= $label ?>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Recent Bookings -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-history"></i> Recent Bookings</h3>
        <a href="bookings.php" class="btn btn-outline-d btn-sm">View All</a>
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Status</th></tr>
            </thead>
            <tbody>
              <?php while ($b = $recentBookings->fetch_assoc()): ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><?= htmlspecialchars($b['full_name']) ?></td>
                <td><?= htmlspecialchars($b['room_no']) ?> (<?= ucfirst($b['type']) ?>)</td>
                <td><?= $b['check_in'] ?></td>
                <td><?= $b['check_out'] ?></td>
                <td>ETB <?= number_format($b['total_price'], 2) ?></td>
                <td><span class="badge badge-<?= $b['status'] ?>"><?= ucfirst(str_replace('_',' ',$b['status'])) ?></span></td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
<script>
drawBarChart('revenueChart', <?= json_encode($chartLabels) ?>, <?= json_encode($chartData) ?>, 'Revenue (ETB)');
drawDoughnut('roomChart',
  ['Available','Booked','Cleaning','Maintenance'],
  [<?= $roomCounts['available'] ?>, <?= $roomCounts['booked'] ?>, <?= $roomCounts['cleaning'] ?>, <?= $roomCounts['maintenance'] ?>]
);
</script>
</body>
</html>
