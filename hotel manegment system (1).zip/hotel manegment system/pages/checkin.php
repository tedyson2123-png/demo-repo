<?php
// ============================================================
//  Grand Lake Hotel — Check-in Page
//  pages/checkin.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';

// ── Handle check-in ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $bid = intval($_POST['booking_id']);
    $b   = $conn->query(
        "SELECT b.*, r.room_no, r.id room_id FROM bookings b
         JOIN rooms r ON r.id=b.room_id
         WHERE b.id=$bid AND b.status='confirmed' LIMIT 1"
    )->fetch_assoc();

    if ($b) {
        $conn->query("UPDATE bookings SET status='checked_in' WHERE id=$bid");
        $conn->query("UPDATE rooms SET status='booked' WHERE id={$b['room_id']}");
        $safeMsg = $conn->real_escape_string(
            "✅ Check-in Complete: You have checked in to Room {$b['room_no']} (Booking #$bid). Enjoy your stay at Grand Lake Hotel!"
        );
        $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ({$b['user_id']},'$safeMsg',0)");
        $success = "Guest checked in to Room {$b['room_no']} (Booking #$bid).";
    } else {
        $error = 'Booking not found or not in confirmed status.';
    }
}

// ── Today's arrivals ──────────────────────────────────────
$todayArrivals = $conn->query(
    "SELECT b.*, u.full_name, u.phone, u.email, r.room_no, r.type, r.floor
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     WHERE b.check_in=CURDATE() AND b.status='confirmed'
     ORDER BY b.id ASC"
);

// ── All confirmed bookings ────────────────────────────────
$allConfirmed = $conn->query(
    "SELECT b.*, u.full_name, u.phone, r.room_no, r.type
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     WHERE b.status='confirmed'
     ORDER BY b.check_in ASC"
);

$todayCount = $todayArrivals->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Check-in — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Check-in</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="checkin.php" class="active"><i class="fas fa-sign-in-alt"></i> Check-in</a>
    <a href="checkout.php"><i class="fas fa-sign-out-alt"></i> Check-out</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Guest Check-in</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / Check-in</p>
      </div>
    </div>
    <div class="topnav-right">
      <span style="font-size:.82rem;color:var(--gray);"><?= date('D, d M Y') ?></span>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
      <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-calendar-day"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $todayCount ?></div><div class="stat-label">Today's Arrivals</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $allConfirmed->num_rows ?></div><div class="stat-label">Confirmed (Pending Check-in)</div></div>
      </div>
    </div>

    <!-- Today's Arrivals -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-calendar-day"></i> Today's Arrivals — <?= date('d M Y') ?></h3>
        <input type="text" class="tbl-search" data-table="tbl-today" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table" id="tbl-today">
            <thead>
              <tr><th>#</th><th>Guest</th><th>Phone</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Guests</th><th>Total</th><th>Special Request</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php $todayArrivals->data_seek(0); while ($b = $todayArrivals->fetch_assoc()): ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><strong><?= htmlspecialchars($b['full_name']) ?></strong><br><small style="color:var(--gray)"><?= htmlspecialchars($b['email']) ?></small></td>
                <td><?= htmlspecialchars($b['phone'] ?? '—') ?></td>
                <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?> · Fl.<?= $b['floor'] ?></td>
                <td><?= $b['check_in'] ?></td>
                <td><?= $b['check_out'] ?></td>
                <td><?= $b['guests'] ?></td>
                <td>ETB <?= number_format($b['total_price'], 2) ?></td>
                <td><?= htmlspecialchars($b['special_request'] ?? '—') ?></td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-sign-in-alt"></i> Check In</button>
                  </form>
                </td>
              </tr>
              <?php endwhile; ?>
              <?php if ($todayCount === 0): ?>
                <tr><td colspan="10" style="text-align:center;color:var(--gray);padding:2rem;">No arrivals scheduled for today.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- All Confirmed Bookings -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-list"></i> All Confirmed Bookings (Pending Check-in)</h3>
        <input type="text" class="tbl-search" data-table="tbl-confirmed" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table" id="tbl-confirmed">
            <thead>
              <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php $allConfirmed->data_seek(0); while ($b = $allConfirmed->fetch_assoc()): ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><?= htmlspecialchars($b['full_name']) ?></td>
                <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?></td>
                <td><?= $b['check_in'] ?></td>
                <td><?= $b['check_out'] ?></td>
                <td>ETB <?= number_format($b['total_price'], 2) ?></td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-sign-in-alt"></i> Check In</button>
                  </form>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
<script>
document.querySelectorAll('.tbl-search').forEach(input => {
  input.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    const table = document.getElementById(this.dataset.table);
    if (table) table.querySelectorAll('tbody tr').forEach(r => {
      r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
});
</script>
</body>
</html>
