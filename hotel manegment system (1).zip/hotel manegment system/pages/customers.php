<?php
// ============================================================
//  Grand Lake Hotel — Customers Management Page
//  pages/customers.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';

// ── Handle delete ─────────────────────────────────────────
if (isset($_GET['delete'])) {
    $cid = intval($_GET['delete']);
    $active = $conn->query(
        "SELECT COUNT(*) c FROM bookings WHERE user_id=$cid AND status IN ('pending','confirmed','checked_in')"
    )->fetch_assoc()['c'];
    if ($active > 0) {
        $error = 'Cannot delete customer with active bookings.';
    } else {
        $conn->query("DELETE FROM users WHERE id=$cid AND role='customer'");
        $success = 'Customer deleted.';
    }
}

// ── Search ────────────────────────────────────────────────
$search = escape($conn, $_GET['q'] ?? '');
$where  = $search
    ? "AND (u.full_name LIKE '%$search%' OR u.email LIKE '%$search%' OR u.username LIKE '%$search%' OR u.phone LIKE '%$search%')"
    : '';

$customers = $conn->query(
    "SELECT u.*,
            COUNT(b.id) AS total_bookings,
            SUM(b.status='checked_out') AS completed_stays,
            COALESCE(SUM(CASE WHEN b.status NOT IN ('cancelled') THEN b.total_price ELSE 0 END),0) AS total_spent
     FROM users u
     LEFT JOIN bookings b ON b.user_id=u.id
     WHERE u.role='customer' $where
     GROUP BY u.id
     ORDER BY u.created_at DESC"
);

$totalCustomers = $conn->query("SELECT COUNT(*) c FROM users WHERE role='customer'")->fetch_assoc()['c'];
$activeGuests   = $conn->query("SELECT COUNT(*) c FROM bookings WHERE status='checked_in'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Customers — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Customers</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="customers.php" class="active"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Customer Management</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / Customers</p>
      </div>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
      <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-users"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $totalCustomers ?></div><div class="stat-label">Total Customers</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-check"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $activeGuests ?></div><div class="stat-label">Currently In-house</div></div>
      </div>
    </div>

    <!-- Search -->
    <div class="card">
      <div class="card-header"><h3><i class="fas fa-search"></i> Search Customers</h3></div>
      <div class="card-body">
        <form method="GET" style="display:flex;gap:1rem;align-items:flex-end;">
          <div class="form-group" style="margin:0;flex:1;">
            <input type="text" name="q" placeholder="Search by name, email, username or phone..."
                   value="<?= htmlspecialchars($search) ?>" style="width:100%;" />
          </div>
          <button type="submit" class="btn btn-primary-d"><i class="fas fa-search"></i> Search</button>
          <?php if ($search): ?><a href="customers.php" class="btn btn-outline-d">Clear</a><?php endif; ?>
        </form>
      </div>
    </div>

    <!-- Customers Table -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-users"></i> Customers (<?= $customers->num_rows ?>)</h3>
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr><th>#</th><th>Name</th><th>Username</th><th>Email</th><th>Phone</th><th>Bookings</th><th>Stays</th><th>Total Spent</th><th>Joined</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php while ($c = $customers->fetch_assoc()): ?>
              <tr>
                <td><?= $c['id'] ?></td>
                <td><strong><?= htmlspecialchars($c['full_name']) ?></strong></td>
                <td><?= htmlspecialchars($c['username']) ?></td>
                <td><?= htmlspecialchars($c['email']) ?></td>
                <td><?= htmlspecialchars($c['phone'] ?? '—') ?></td>
                <td><?= $c['total_bookings'] ?></td>
                <td><?= $c['completed_stays'] ?></td>
                <td>ETB <?= number_format($c['total_spent'], 0) ?></td>
                <td><?= date('d M Y', strtotime($c['created_at'])) ?></td>
                <td>
                  <a href="?delete=<?= $c['id'] ?>" class="btn btn-danger btn-sm"
                     data-confirm="Delete customer <?= htmlspecialchars($c['full_name']) ?>?">
                    <i class="fas fa-trash"></i>
                  </a>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
</body>
</html>
