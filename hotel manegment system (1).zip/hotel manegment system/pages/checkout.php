<?php
// ============================================================
//  Grand Lake Hotel — Check-out Page
//  pages/checkout.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';

// ── Handle check-out ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $bid = intval($_POST['booking_id']);
    $b   = $conn->query(
        "SELECT b.*, r.room_no, r.id room_id FROM bookings b
         JOIN rooms r ON r.id=b.room_id
         WHERE b.id=$bid AND b.status='checked_in' LIMIT 1"
    )->fetch_assoc();

    if ($b) {
        $conn->query("UPDATE bookings SET status='checked_out' WHERE id=$bid");
        $conn->query("UPDATE rooms SET status='cleaning' WHERE id={$b['room_id']}");
        $safeMsg = $conn->real_escape_string(
            "👋 Check-out Complete: You have checked out from Room {$b['room_no']} (Booking #$bid). " .
            "Thank you for staying with us — we hope to see you again!"
        );
        $conn->query("INSERT INTO notifications (user_id,message,is_read) VALUES ({$b['user_id']},'$safeMsg',0)");
        $success = "Guest checked out from Room {$b['room_no']}. Room queued for cleaning.";
    } else {
        $error = 'Booking not found or guest not checked in.';
    }
}

// ── Today's departures ────────────────────────────────────
$todayDepartures = $conn->query(
    "SELECT b.*, u.full_name, u.phone, u.email, r.room_no, r.type, r.floor
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     WHERE b.check_out=CURDATE() AND b.status='checked_in'
     ORDER BY b.id ASC"
);

// ── All currently checked-in guests ──────────────────────
$inHouse = $conn->query(
    "SELECT b.*, u.full_name, u.phone, r.room_no, r.type
     FROM bookings b
     JOIN users u ON u.id=b.user_id
     JOIN rooms  r ON r.id=b.room_id
     WHERE b.status='checked_in'
     ORDER BY b.check_out ASC"
);

$todayCount = $todayDepartures->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Check-out — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Check-out</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="checkin.php"><i class="fas fa-sign-in-alt"></i> Check-in</a>
    <a href="checkout.php" class="active"><i class="fas fa-sign-out-alt"></i> Check-out</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Guest Check-out</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / Check-out</p>
      </div>
    </div>
    <div class="topnav-right">
      <span style="font-size:.82rem;color:var(--gray);"><?= date('D, d M Y') ?></span>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?><div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div><?php endif; ?>
    <?php if ($error):   ?><div class="alert alert-error"   data-dismiss><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
      <div class="stat-card">
        <div class="stat-icon yellow"><i class="fas fa-calendar-day"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $todayCount ?></div><div class="stat-label">Today's Departures</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-user-check"></i></div>
        <div class="stat-info"><div class="stat-value"><?= $inHouse->num_rows ?></div><div class="stat-label">Currently In-house</div></div>
      </div>
    </div>

    <!-- Today's Departures -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-calendar-day"></i> Today's Departures — <?= date('d M Y') ?></h3>
        <input type="text" class="tbl-search" data-table="tbl-today" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table" id="tbl-today">
            <thead>
              <tr><th>#</th><th>Guest</th><th>Phone</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Nights</th><th>Total (ETB)</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php $todayDepartures->data_seek(0); while ($b = $todayDepartures->fetch_assoc()):
                $nights = (strtotime($b['check_out']) - strtotime($b['check_in'])) / 86400;
              ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><strong><?= htmlspecialchars($b['full_name']) ?></strong><br><small style="color:var(--gray)"><?= htmlspecialchars($b['email']) ?></small></td>
                <td><?= htmlspecialchars($b['phone'] ?? '—') ?></td>
                <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?> · Fl.<?= $b['floor'] ?></td>
                <td><?= $b['check_in'] ?></td>
                <td><?= $b['check_out'] ?></td>
                <td><?= $nights ?></td>
                <td><?= number_format($b['total_price'], 2) ?></td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                    <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-sign-out-alt"></i> Check Out</button>
                  </form>
                </td>
              </tr>
              <?php endwhile; ?>
              <?php if ($todayCount === 0): ?>
                <tr><td colspan="9" style="text-align:center;color:var(--gray);padding:2rem;">No departures scheduled for today.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- All In-house Guests -->
    <div class="card">
      <div class="card-header">
        <h3><i class="fas fa-user-check"></i> All Currently Checked-in Guests</h3>
        <input type="text" class="tbl-search" data-table="tbl-inhouse" placeholder="Search..." style="padding:.4rem .8rem;border:1.5px solid var(--gray-l);border-radius:var(--radius);font-size:.85rem;" />
      </div>
      <div class="card-body">
        <div class="table-wrap">
          <table class="data-table" id="tbl-inhouse">
            <thead>
              <tr><th>#</th><th>Guest</th><th>Room</th><th>Check-in</th><th>Check-out</th><th>Total</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php $inHouse->data_seek(0); while ($b = $inHouse->fetch_assoc()): ?>
              <tr>
                <td><?= $b['id'] ?></td>
                <td><?= htmlspecialchars($b['full_name']) ?></td>
                <td><?= htmlspecialchars($b['room_no']) ?> · <?= ucfirst($b['type']) ?></td>
                <td><?= $b['check_in'] ?></td>
                <td><?= $b['check_out'] ?></td>
                <td>ETB <?= number_format($b['total_price'], 2) ?></td>
                <td>
                  <form method="POST">
                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>" />
                    <button type="submit" class="btn btn-accent btn-sm"><i class="fas fa-sign-out-alt"></i> Check Out</button>
                  </form>
                </td>
              </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
<script>
document.querySelectorAll('.tbl-search').forEach(input => {
  input.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    const table = document.getElementById(this.dataset.table);
    if (table) table.querySelectorAll('tbody tr').forEach(r => {
      r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
});
</script>
</body>
</html>
