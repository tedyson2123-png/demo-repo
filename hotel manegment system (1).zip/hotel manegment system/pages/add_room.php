<?php
// ============================================================
//  Grand Lake Hotel — Add Room Page
//  pages/add_room.php
// ============================================================

require_once __DIR__ . '/../connection.php';
requireLogin('../login.php');

$user    = currentUser();
$success = $error = '';
$errors  = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $room_no = escape($conn, $_POST['room_no'] ?? '');
    $type    = escape($conn, $_POST['type']    ?? '');
    $floor   = intval($_POST['floor']    ?? 1);
    $cap     = intval($_POST['capacity'] ?? 1);
    $price   = floatval($_POST['price']  ?? 0);
    $desc    = escape($conn, $_POST['description'] ?? '');

    // Validation
    if (!$room_no)  $errors[] = 'Room number is required.';
    if (!in_array($type, ['single','double','suite','deluxe'])) $errors[] = 'Invalid room type.';
    if ($floor < 1) $errors[] = 'Floor must be at least 1.';
    if ($cap < 1)   $errors[] = 'Capacity must be at least 1.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';

    // Check duplicate room number
    if (!$errors) {
        $exists = $conn->query("SELECT id FROM rooms WHERE room_no='$room_no' LIMIT 1")->num_rows;
        if ($exists) $errors[] = "Room number '$room_no' already exists.";
    }

    if (!$errors) {
        $stmt = $conn->prepare(
            "INSERT INTO rooms (room_no, type, floor, capacity, price, description) VALUES (?,?,?,?,?,?)"
        );
        $stmt->bind_param("ssiids", $room_no, $type, $floor, $cap, $price, $desc);
        if ($stmt->execute()) {
            $success = "Room $room_no added successfully!";
        } else {
            $errors[] = 'Failed to add room: ' . $conn->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Add Room — Grand Lake Hotel</title>
  <link rel="stylesheet" href="../admin/admin.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
</head>
<body class="dashboard-body">

<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><i class="fas fa-hotel"></i></div>
    <div><div class="brand-name">Grand Lake Hotel</div><div class="brand-role">Add Room</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">Pages</div>
    <a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="rooms.php"><i class="fas fa-bed"></i> Rooms</a>
    <a href="add_room.php" class="active"><i class="fas fa-plus-circle"></i> Add Room</a>
    <a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a>
    <a href="customers.php"><i class="fas fa-users"></i> Customers</a>
    <a href="reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
    <div class="nav-section-label">Account</div>
    <a href="../profile.php"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sidebar-footer">
    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
  </div>
</aside>

<div class="main-content">
  <div class="topnav">
    <div class="topnav-left">
      <button class="hamburger-dash" id="hamburgerDash"><i class="fas fa-bars"></i></button>
      <div>
        <h2>Add New Room</h2>
        <p class="breadcrumb"><a href="dashboard.php">Dashboard</a> / <a href="rooms.php">Rooms</a> / Add</p>
      </div>
    </div>
    <div class="topnav-right">
      <a href="rooms.php" class="btn btn-outline-d btn-sm"><i class="fas fa-arrow-left"></i> Back to Rooms</a>
    </div>
  </div>

  <div class="page-content">
    <?php if ($success): ?>
      <div class="alert alert-success" data-dismiss><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
      <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <ul style="margin:.5rem 0 0 1rem;">
          <?php foreach ($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="card" style="max-width:700px;">
      <div class="card-header">
        <h3><i class="fas fa-plus-circle"></i> Room Details</h3>
      </div>
      <div class="card-body">
        <form method="POST">
          <div class="form-grid-2">
            <div class="form-group">
              <label>Room Number <span style="color:var(--danger)">*</span></label>
              <input type="text" name="room_no" placeholder="e.g. 105" required
                     value="<?= htmlspecialchars($_POST['room_no'] ?? '') ?>" />
            </div>
            <div class="form-group">
              <label>Room Type <span style="color:var(--danger)">*</span></label>
              <select name="type" required>
                <option value="">Select type...</option>
                <?php foreach (['single','double','suite','deluxe'] as $t): ?>
                  <option value="<?= $t ?>" <?= ($_POST['type'] ?? '')===$t?'selected':'' ?>><?= ucfirst($t) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label>Floor <span style="color:var(--danger)">*</span></label>
              <input type="number" name="floor" min="1" max="20" value="<?= htmlspecialchars($_POST['floor'] ?? '1') ?>" required />
            </div>
            <div class="form-group">
              <label>Capacity (guests) <span style="color:var(--danger)">*</span></label>
              <input type="number" name="capacity" min="1" max="10" value="<?= htmlspecialchars($_POST['capacity'] ?? '2') ?>" required />
            </div>
            <div class="form-group">
              <label>Price per Night (ETB) <span style="color:var(--danger)">*</span></label>
              <input type="number" name="price" step="0.01" min="1" placeholder="120.00"
                     value="<?= htmlspecialchars($_POST['price'] ?? '') ?>" required />
            </div>
          </div>
          <div class="form-group">
            <label>Description</label>
            <textarea name="description" rows="3" placeholder="Describe the room amenities, view, features..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
          </div>
          <div style="display:flex;gap:1rem;margin-top:.5rem;">
            <button type="submit" class="btn btn-primary-d"><i class="fas fa-save"></i> Add Room</button>
            <a href="rooms.php" class="btn btn-outline-d">Cancel</a>
          </div>
        </form>
      </div>
    </div>

  </div>
</div>

<script src="../admin/admin.js"></script>
</body>
</html>
