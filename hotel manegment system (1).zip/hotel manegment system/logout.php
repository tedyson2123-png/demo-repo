<?php
require_once 'connection.php';
writeLog('logout', 'User logged out.');
session_destroy();
header("Location: login.php");
exit;
